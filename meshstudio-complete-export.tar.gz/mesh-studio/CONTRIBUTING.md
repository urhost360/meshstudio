# Contributing to MeshStudio

This guide helps you safely modify MeshStudio without breaking existing functionality.

---

## Before You Start

1. **Read [ARCHITECTURE.md](./ARCHITECTURE.md)** - Understand the system design
2. **Run tests** - Verify everything works: `pnpm test`
3. **Create a branch** - Never commit to `main` directly
4. **Test your changes** - Run tests and manual testing before submitting

---

## Code Style

### TypeScript

- Use strict mode (no `any` types without justification)
- Add type annotations for function parameters and returns
- Use interfaces for object shapes
- Prefer `const` over `let`, never use `var`

```typescript
// ✓ GOOD
interface UserData {
  id: string;
  email: string;
}

function getUserData(userId: string): Promise<UserData> {
  return db.query.users.findFirst({
    where: eq(users.id, userId),
  });
}

// ✗ BAD
function getUserData(userId) {
  return db.query.users.findFirst({
    where: eq(users.id, userId),
  });
}
```

### React Components

- Use functional components with hooks
- Prefer `useCallback` for event handlers
- Use `useMemo` for expensive computations
- Add JSDoc comments for complex components

```typescript
// ✓ GOOD
/**
 * Renders a 3D model in the viewport
 * @param model - THREE.Object3D to render
 * @param onSelect - Callback when model is clicked
 */
export function ModelViewer({ model, onSelect }: Props) {
  const handleClick = useCallback(() => {
    onSelect?.(model);
  }, [model, onSelect]);

  return <div onClick={handleClick}>{/* ... */}</div>;
}

// ✗ BAD
export function ModelViewer(props) {
  return (
    <div onClick={() => props.onSelect(props.model)}>
      {/* ... */}
    </div>
  );
}
```

### Naming Conventions

- Components: PascalCase (`MyComponent.tsx`)
- Functions: camelCase (`myFunction()`)
- Constants: UPPER_SNAKE_CASE (`MAX_OBJECTS = 100`)
- Private functions: prefix with `_` (`_internalHelper()`)
- Event handlers: prefix with `handle` (`handleClick()`)
- Boolean variables: prefix with `is` or `has` (`isLoading`, `hasError`)

```typescript
// ✓ GOOD
const MAX_HISTORY_SIZE = 50;
const isLoading = true;
const handleFileUpload = () => { /* ... */ };

// ✗ BAD
const max = 50;
const loading = true;
const upload = () => { /* ... */ };
```

---

## Commit Messages

Use clear, descriptive commit messages:

```
feat: Add vertex deletion tool
fix: Prevent memory leak in Three.js renderer
docs: Update architecture guide
test: Add tests for undo/redo
refactor: Simplify scene state management
chore: Update dependencies
```

**Format:** `<type>: <description>`

**Types:**
- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation
- `test` - Tests
- `refactor` - Code refactoring
- `chore` - Build, dependencies, etc.

---

## Testing

### Writing Tests

Every feature should have tests. Use Vitest:

```typescript
import { describe, it, expect, beforeEach } from "vitest";

describe("HistoryManager", () => {
  let history: HistoryManager;

  beforeEach(() => {
    history = new HistoryManager();
  });

  it("should save state", () => {
    const scene = new THREE.Scene();
    history.saveState(scene, "Test");
    expect(history.canUndo()).toBe(true);
  });

  it("should undo to previous state", () => {
    const scene = new THREE.Scene();
    history.saveState(scene, "State 1");
    history.saveState(scene, "State 2");
    history.undo();
    expect(history.canRedo()).toBe(true);
  });
});
```

### Running Tests

```bash
# Run all tests
pnpm test

# Run specific file
pnpm test server/routers.test.ts

# Watch mode
pnpm test --watch

# Coverage
pnpm test --coverage
```

**Requirement:** All tests must pass before submitting PR

---

## Dangerous Patterns

### ❌ DON'T: Mutate React State Directly

```typescript
// ✗ BAD - Direct mutation
sceneObjects.push(newObject);

// ✓ GOOD - Use setState
setSceneObjects(prev => [...prev, newObject]);
```

### ❌ DON'T: Forget History When Modifying Scene

```typescript
// ✗ BAD - No history saved
const success = vertexEditor.deleteSelected();
if (success) {
  refreshSceneObjects();
}

// ✓ GOOD - History saved
const success = vertexEditor.deleteSelected();
if (success) {
  historyRef.current.saveState(viewportRef.scene, "Delete selected");
  refreshSceneObjects();
}
```

### ❌ DON'T: Use Async Operations Without Handling Errors

```typescript
// ✗ BAD - No error handling
const model = await loadModelFromUrl(url);
viewportRef.addObject(model);

// ✓ GOOD - With error handling
try {
  const model = await loadModelFromUrl(url);
  if (!model) {
    toast.error("Failed to load model");
    return;
  }
  viewportRef.addObject(model);
} catch (error) {
  toast.error(`Error: ${error.message}`);
}
```

### ❌ DON'T: Create Event Listeners Without Cleanup

```typescript
// ✗ BAD - Memory leak
useEffect(() => {
  element.addEventListener("click", handler);
}, []);

// ✓ GOOD - With cleanup
useEffect(() => {
  element.addEventListener("click", handler);
  return () => element.removeEventListener("click", handler);
}, []);
```

### ❌ DON'T: Forget to Dispose Three.js Objects

```typescript
// ✗ BAD - Memory leak
const geometry = new THREE.BufferGeometry();
mesh.geometry = geometry;

// ✓ GOOD - Dispose old first
const oldGeometry = mesh.geometry;
mesh.geometry = geometry;
oldGeometry.dispose();
```

### ❌ DON'T: Bypass Selection Validation

```typescript
// ✗ BAD - selectedObject might not exist in scene
if (selectedObject) {
  deleteObject(selectedObject);
}

// ✓ GOOD - Validate it's in scene
if (selectedObject && sceneObjects.includes(selectedObject)) {
  deleteObject(selectedObject);
}
```

### ❌ DON'T: Create Unstable Query Dependencies

```typescript
// ✗ BAD - New array every render = infinite queries
const { data } = trpc.items.getByIds.useQuery({
  ids: [1, 2, 3],
});

// ✓ GOOD - Stable reference
const ids = useMemo(() => [1, 2, 3], []);
const { data } = trpc.items.getByIds.useQuery({ ids });
```

---

## Safe Modification Patterns

### Pattern 1: Adding a New Edit Tool

**Steps:**
1. Define tool in enum
2. Add UI button
3. Create tool component
4. Implement operation
5. Save to history
6. Add tests

**Example:**
```typescript
// 1. Define tool
type EditMode = "object" | "vertex" | "myTool";

// 2. Add button in Toolbar
<button onClick={() => setEditMode("myTool")}>My Tool</button>

// 3. Create component
export function MyToolPanel({ selectedObject, onApply }) {
  return <div>{/* UI */}</div>;
}

// 4. Implement in Editor
const handleMyTool = useCallback(() => {
  if (!selectedObject || !viewportRef) return;
  
  // Perform operation
  myOperation(selectedObject);
  
  // 5. Save to history
  historyRef.current.saveState(viewportRef.scene, "My Tool");
  
  // Update UI
  refreshSceneObjects();
}, [selectedObject, viewportRef]);

// 6. Test it
it("should apply my tool", () => {
  // ...
});
```

### Pattern 2: Adding a New API Endpoint

**Steps:**
1. Create database query
2. Add tRPC procedure
3. Call from frontend
4. Add tests

**Example:**
```typescript
// 1. Database query (server/db.ts)
export async function getMyData(userId: string) {
  return db.query.myTable.findMany({
    where: eq(myTable.userId, userId),
  });
}

// 2. tRPC procedure (server/routers.ts)
myFeature: {
  getData: protectedProcedure
    .query(async ({ ctx }) => {
      return getMyData(ctx.user.id);
    }),
}

// 3. Call from frontend
const { data } = trpc.myFeature.getData.useQuery();

// 4. Test it
it("should fetch my data", async () => {
  const data = await trpc.myFeature.getData.query();
  expect(data).toBeDefined();
});
```

### Pattern 3: Modifying Scene State Safely

**Steps:**
1. Save history first
2. Perform operation
3. Update React state
4. Refresh UI

**Example:**
```typescript
const handleDelete = useCallback(() => {
  if (!selectedObject || !viewportRef) return;
  
  // 1. Save history FIRST
  historyRef.current.saveState(viewportRef.scene, "Delete object");
  
  // 2. Perform operation
  viewportRef.scene.remove(selectedObject);
  
  // 3. Update React state
  setSceneObjects(prev => 
    prev.filter(obj => obj !== selectedObject)
  );
  setSelectedObject(null);
  
  // 4. Refresh UI
  refreshSceneObjects();
}, [selectedObject, viewportRef]);
```

---

## Common Mistakes

### Mistake 1: Forgetting to Handle Loading States

```typescript
// ✗ BAD - No loading state
const { data } = trpc.projects.get.useQuery({ id });
return <div>{data.name}</div>; // Crashes if data is undefined

// ✓ GOOD - Handle loading
const { data, isLoading } = trpc.projects.get.useQuery({ id });
if (isLoading) return <Skeleton />;
return <div>{data.name}</div>;
```

### Mistake 2: Not Validating User Input

```typescript
// ✗ BAD - No validation
const handleImport = async (files: File[]) => {
  for (const file of files) {
    const model = await loadModelFromFile(file);
    viewportRef.addObject(model);
  }
};

// ✓ GOOD - With validation
const handleImport = async (files: File[]) => {
  const validFormats = ["obj", "stl", "fbx", "gltf", "glb"];
  for (const file of files) {
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!ext || !validFormats.includes(ext)) {
      toast.error(`Invalid format: ${ext}`);
      continue;
    }
    const model = await loadModelFromFile(file);
    if (!model) {
      toast.error(`Failed to load ${file.name}`);
      continue;
    }
    viewportRef.addObject(model);
  }
};
```

### Mistake 3: Not Cleaning Up Effects

```typescript
// ✗ BAD - Memory leak
useEffect(() => {
  const interval = setInterval(() => {
    // ...
  }, 1000);
}, []);

// ✓ GOOD - With cleanup
useEffect(() => {
  const interval = setInterval(() => {
    // ...
  }, 1000);
  return () => clearInterval(interval);
}, []);
```

### Mistake 4: Hardcoding Values

```typescript
// ✗ BAD - Hardcoded
const MAX_OBJECTS = 100;
const API_URL = "https://api.example.com";

// ✓ GOOD - Use constants
const MAX_OBJECTS = 100; // At top of file
const API_URL = process.env.VITE_API_URL; // From env
```

---

## Performance Guidelines

### Do's

- ✅ Use `useMemo` for expensive computations
- ✅ Use `useCallback` for event handlers
- ✅ Cache scene object list
- ✅ Debounce frequent operations
- ✅ Lazy load components
- ✅ Profile with DevTools

### Don'ts

- ❌ Don't traverse scene on every mouse event
- ❌ Don't create new objects in render
- ❌ Don't serialize entire scene on every change
- ❌ Don't mount all components unconditionally
- ❌ Don't create new arrays/objects as dependencies

---

## Pull Request Checklist

Before submitting a PR:

- [ ] Code follows style guidelines
- [ ] All tests pass (`pnpm test`)
- [ ] Build succeeds (`pnpm build`)
- [ ] No console errors or warnings
- [ ] Tested manually in dev and production
- [ ] Commit messages are clear
- [ ] Documentation updated if needed
- [ ] No hardcoded values or secrets
- [ ] Memory leaks checked
- [ ] Undo/redo works if state changed

---

## Review Process

1. **Automated checks** - Tests, linting, build
2. **Code review** - Check for safety patterns
3. **Manual testing** - Verify functionality
4. **Approval** - Merge to main

---

## Questions?

- Check [ARCHITECTURE.md](./ARCHITECTURE.md)
- Review similar code in the codebase
- Ask in code comments
- Create an issue for discussion

---

## Resources

- [Three.js Documentation](https://threejs.org/docs/)
- [React Documentation](https://react.dev/)
- [tRPC Documentation](https://trpc.io/)
- [Drizzle ORM](https://orm.drizzle.team/)
- [Tailwind CSS](https://tailwindcss.com/)

---

**Happy coding! 🚀**
