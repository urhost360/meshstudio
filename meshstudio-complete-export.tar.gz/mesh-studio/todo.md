# MeshStudio - Project TODO

## Core Infrastructure
- [x] Database schema (projects, assets, shared links)
- [x] Server routes (tRPC procedures for CRUD)
- [x] S3 storage helpers for 3D files
- [x] Dark theme UI with professional design

## 3D Viewport
- [x] Three.js viewport with scene rendering
- [x] Orbit, pan, zoom camera controls
- [x] Grid floor and axis helpers
- [x] Lighting setup (ambient + directional)

## File Upload
- [x] File upload system (drag & drop + file picker)
- [x] OBJ file loader
- [x] STL file loader
- [x] FBX file loader
- [x] GLTF/GLB file loader
- [x] Upload progress indicator

## Transform Tools
- [x] Move (translate) tool
- [x] Rotate tool
- [x] Scale tool
- [x] Transform gizmo UI (TransformControls)

## Polygon Editing
- [x] Vertex selection and visualization
- [x] Face/polygon selection overlay
- [x] Edge selection overlay
- [x] Mesh subdivision
- [x] Mesh simplification (decimate)
- [ ] Extrude faces (complex geometry operation)
- [x] Delete selected elements

## Material & Color Editing
- [x] Color picker for object materials
- [x] Metalness/roughness controls
- [x] Opacity/transparency control
- [x] Wireframe toggle
- [x] Texture support (ZIP bundles with OBJ+MTL+textures)

## Asset Combination
- [x] Scene hierarchy panel (object list)
- [x] Import multiple assets into one scene
- [x] Merge/combine meshes
- [x] Duplicate objects
- [x] Delete objects from scene

## Project Save/Load
- [x] Save project to database + S3
- [x] Load project from database
- [x] Project list/gallery page
- [x] Auto-save functionality (every 30 seconds)
- [x] Project metadata (name, description, thumbnail)

## Sharing System
- [x] Generate unique shareable URLs
- [x] Public share view (read-only 3D viewer)
- [x] Share link management (enable/disable)
- [x] Copy link to clipboard

## Export
- [x] Export as OBJ
- [x] Export as STL
- [x] Export as GLTF/GLB
- [x] Export scene screenshot as PNG

## Testing
- [x] Server route tests (35 tests passing)
- [x] Auth tests

## Bug Fixes / New Requests
- [x] Support ZIP file import (extract and load OBJ/MTL/textures from ZIP bundles)
- [x] Lasso selection tool for quick polygon/vertex/edge selection
- [x] Box/rectangle selection tool
- [x] Quick delete shortcut (select with lasso, then Delete key to remove)
- [x] 3-point natural lighting system (key, fill, back lights)
- [x] Editable light positions for realistic ambience

## Enhanced Sharing & AR Features
- [x] QR code generation for mobile scanning of share links
- [x] Copy link button in share dialog
- [x] Privacy settings (Public/Private/Password) for shared links
- [x] Embed code option (iframe snippet)
- [x] Social sharing buttons (Twitter, Facebook, LinkedIn, etc.)
- [x] AR preview thumbnail in share dialog
- [x] Enable/disable comments toggle per shared link
- [x] Comments system on shared view page

## AR-Compatible Export
- [x] GLTF/GLB export (primary format for web AR)
- [x] USDZ export (for iOS AR Quick Look)
- [x] Maximum polygon count warnings before export
- [x] Texture size optimization warnings (recommend 2K max for mobile)

## AR Viewing on Shared Links
- [x] AR view button on shared view page
- [x] model-viewer integration for Android/WebXR AR
- [x] Apple AR Quick Look support for iOS (USDZ)
- [x] Server-side GLB export endpoint for AR model delivery
- [x] AR mode overlay with instructions

## Direct AR File Open
- [x] "Open in AR" button on shared link page that directly opens AR file on device
- [x] QR code popup for desktop users to scan and view AR on mobile (no desktop AR viewing)

## Bulletproofing & Robustness
- [x] Add comprehensive error handling to file upload/import flows
- [x] Add file size and format validation (500MB per file, 1GB total, 50 files max)
- [x] Add error handling to 3D viewport and scene management
- [x] Add error handling to AR generation and viewing
- [x] Add error handling to database operations and server routes
- [x] Add error handling to sharing, comments, and auth flows
- [x] Add user-friendly error messages and recovery suggestions

## Bug Fixes
- [x] Fix right-click pan/orbit controls in edit modes (Vertex, Face, Edge)
- [ ] Fix lasso/box selection to activate with L/B keyboard shortcuts instead of being always active
- [x] Change object selection to double-click (single-click shows properties only)
- [x] Add grid to shared view for realistic preview room
- [x] Fix AR model to stay anchored in physical location (ar-placement floor + xr-environment)
- [x] Auto-enable AR mode on mobile when opening shared link

## Critical Bugs to Fix
- [ ] Save button not persisting changes after lasso deletion - geometry disappears visually but doesn't save to database
- [x] Shared link always shows AR preview room on both desktop and mobile
- [x] Desktop shows QR code when clicking Place in Your Space
- [x] Mobile activates AR placement when clicking Place in Your Space


## In Progress
- [x] Implement undo/redo history system (Ctrl+Z / Ctrl+Y)
- [x] Fix save button to persist lasso-deleted geometry
- [x] Verify keyboard shortcuts (L, B, Delete, Ctrl+Z, Ctrl+Y, S for save)
- [x] Add asset update endpoint to backend
- [x] Integrate HistoryManager with Editor operations


## Current Issues to Fix
- [x] Fix right-click context menu blocking pan in vertex mode
- [x] Add visual undo/redo buttons to toolbar with state indicators
- [x] Fix shared link blank screen - auto-generate AR GLB and show preview room
- [x] Add keyboard help panel (press ? to show shortcuts)
- [x] Add export warnings for polygon count and texture size
- [x] Add auto-save functionality
- [x] Fix camera controls (pan/scroll) in vertex/face/edge modes
- [x] Implement face extrude feature


## Batch Operations
- [x] Multi-select objects with Ctrl+Click
- [x] Batch transform (move/rotate/scale) multiple objects with BatchTransformPanel
- [x] Batch delete selected objects
- [x] Align and distribute objects (center, distribute X/Y/Z)


## Shared Link Issues
- [x] Make AR preview room the main view on shared link
- [x] Remove back button from shared link header
- [x] Fix "Place in Your Space" button visibility with fixed positioning


## Current Bugs
- [x] Lasso selection not working in object mode - enabled in all modes
- [x] Shared link preview room showing blank screen - fixed scene loading order

- [x] Double-click object selection not working in editor - fixed function ordering

- [x] Hide Three.js grid room completely on shared link - set display: none
- [x] Make loading screen opaque with solid background - changed to bg-slate-950
- [x] Fix "Place in Your Space" button positioning on desktop - fixed bottom positioning


## New Features
- [x] Drag-and-drop model import to viewport
- [ ] Model duplication with Ctrl+D and automatic offset
- [ ] Viewport grid toggle button

## Current Bugs (Session 2)
- [x] Drag-and-drop overlay shows on hover instead of only when dragging file
- [x] Save button not persisting object deletions to database
- [x] Undo/Redo buttons on toolbar don't work
- [x] Undo/Redo keyboard shortcuts (Ctrl+Z/Ctrl+Y) don't work
- [x] Camera controls (right-click pan, scroll zoom) don't work in lasso selection mode

## New Features (Session 3)
- [ ] 3-axis rotation gizmo with circular handles (red/green/blue rings)
- [ ] Selective gizmo visibility (only show when object selected)
- [ ] Turntable camera mode with adjustable rotation speed
- [x] Fix preview room blank issue


## Session 4 - SEO & Social Media Preview
- [x] Add project name to shared link page title and meta tags
- [x] Add project description to meta description tag
- [x] Use project thumbnail as og:image for social media preview
- [x] Ensure proper SEO for shared links


## Session 5 - Mobile Layout Fixes
- [x] Fix mobile view scrolling issue
- [x] Ensure AR button is visible and accessible on mobile
- [x] Prevent header from scrolling out of view on mobile


## Session 6 - Mobile UX Improvements
- [x] Disable page scroll but allow 3D scene pan on mobile
- [x] Ensure AR button always visible on all device sizes
- [x] Hide Three.js viewport with loading overlay until AR ready


## Session 7 - AR Mode Mobile Fixes
- [x] Auto-activate AR mode after loading completes
- [x] Fix Place in Your Space button visibility on mobile
- [x] Remove Android WebXR and iOS AR Quick Look platform text


## Session 8 - Critical AR & Rendering Fixes
- [ ] AR mode activation - Three.js should show while loading, then switch to AR mode
- [ ] Model-viewer rendering quality - white spots/artifacts and low quality appearance
- [ ] Optimize GLB export for better texture quality in AR presentation

