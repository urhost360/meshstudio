import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  InsertProject, projects,
  InsertAsset, assets,
  InsertSharedLink, sharedLinks,
  InsertComment, comments,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── User helpers ───────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get user: database not available"); return undefined; }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Project helpers ────────────────────────────────────────────

export async function createProject(data: Omit<InsertProject, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(projects).values(data);
  const id = result[0].insertId;
  return getProjectById(id);
}

export async function getProjectById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getProjectsByUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(projects).where(eq(projects.userId, userId)).orderBy(desc(projects.updatedAt));
}

export async function updateProject(id: number, userId: number, data: Partial<Pick<InsertProject, "name" | "description" | "sceneData" | "thumbnailUrl">>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(projects).set(data).where(and(eq(projects.id, id), eq(projects.userId, userId)));
  return getProjectById(id);
}

export async function deleteProject(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(assets).where(eq(assets.projectId, id));
  await db.delete(sharedLinks).where(eq(sharedLinks.projectId, id));
  await db.delete(projects).where(and(eq(projects.id, id), eq(projects.userId, userId)));
}

// ─── Asset helpers ──────────────────────────────────────────────

export async function createAsset(data: Omit<InsertAsset, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(assets).values(data);
  const id = result[0].insertId;
  return getAssetById(id);
}

export async function getAssetById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(assets).where(eq(assets.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getAssetsByProject(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(assets).where(eq(assets.projectId, projectId)).orderBy(desc(assets.createdAt));
}

export async function updateAsset(id: number, userId: number, data: Partial<Pick<InsertAsset, "fileKey" | "fileUrl" | "fileSize">>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(assets).set(data).where(and(eq(assets.id, id), eq(assets.userId, userId)));
  return getAssetById(id);
}

export async function deleteAsset(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(assets).where(and(eq(assets.id, id), eq(assets.userId, userId)));
}

// ─── Shared link helpers ────────────────────────────────────────

export async function createSharedLink(data: Omit<InsertSharedLink, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(sharedLinks).values(data);
  const id = result[0].insertId;
  return getSharedLinkById(id);
}

export async function getSharedLinkById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(sharedLinks).where(eq(sharedLinks.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getSharedLinkByToken(token: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(sharedLinks).where(and(eq(sharedLinks.shareToken, token), eq(sharedLinks.isActive, true))).limit(1);
  return result[0] ?? null;
}

export async function getSharedLinksByProject(projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(sharedLinks).where(eq(sharedLinks.projectId, projectId));
}

export async function toggleSharedLink(id: number, userId: number, isActive: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(sharedLinks).set({ isActive }).where(and(eq(sharedLinks.id, id), eq(sharedLinks.userId, userId)));
  return getSharedLinkById(id);
}

export async function updateSharedLink(id: number, userId: number, data: Partial<Pick<InsertSharedLink, "privacy" | "passwordHash" | "commentsEnabled" | "isActive">>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(sharedLinks).set(data).where(and(eq(sharedLinks.id, id), eq(sharedLinks.userId, userId)));
  return getSharedLinkById(id);
}

export async function deleteSharedLink(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Delete associated comments first
  await db.delete(comments).where(eq(comments.sharedLinkId, id));
  await db.delete(sharedLinks).where(and(eq(sharedLinks.id, id), eq(sharedLinks.userId, userId)));
}

// ─── Comment helpers ────────────────────────────────────────────

export async function createComment(data: Omit<InsertComment, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(comments).values(data);
  const id = result[0].insertId;
  return getCommentById(id);
}

export async function getCommentById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(comments).where(eq(comments.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getCommentsBySharedLink(sharedLinkId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(comments).where(eq(comments.sharedLinkId, sharedLinkId)).orderBy(desc(comments.createdAt));
}

export async function deleteComment(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(comments).where(and(eq(comments.id, id), eq(comments.userId, userId)));
}
