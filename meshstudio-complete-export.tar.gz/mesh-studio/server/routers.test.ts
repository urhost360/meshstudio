import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

// Mock the database module
vi.mock("./db", () => {
  let projectIdCounter = 0;
  let assetIdCounter = 0;
  let linkIdCounter = 0;
  let commentIdCounter = 0;
  const projects: any[] = [];
  const assets: any[] = [];
  const sharedLinks: any[] = [];
  const comments: any[] = [];

  return {
    createProject: vi.fn(async (data: any) => {
      const project = { id: ++projectIdCounter, ...data, createdAt: new Date(), updatedAt: new Date() };
      projects.push(project);
      return project;
    }),
    getProjectById: vi.fn(async (id: number) => projects.find(p => p.id === id) ?? null),
    getProjectsByUser: vi.fn(async (userId: number) => projects.filter(p => p.userId === userId)),
    updateProject: vi.fn(async (id: number, userId: number, data: any) => {
      const project = projects.find(p => p.id === id && p.userId === userId);
      if (project) Object.assign(project, data);
      return project ?? null;
    }),
    deleteProject: vi.fn(async (id: number, userId: number) => {
      const idx = projects.findIndex(p => p.id === id && p.userId === userId);
      if (idx >= 0) projects.splice(idx, 1);
    }),
    createAsset: vi.fn(async (data: any) => {
      const asset = { id: ++assetIdCounter, ...data, createdAt: new Date() };
      assets.push(asset);
      return asset;
    }),
    getAssetById: vi.fn(async (id: number) => assets.find(a => a.id === id) ?? null),
    getAssetsByProject: vi.fn(async (projectId: number) => assets.filter(a => a.projectId === projectId)),
    deleteAsset: vi.fn(async (id: number, userId: number) => {
      const idx = assets.findIndex(a => a.id === id && a.userId === userId);
      if (idx >= 0) assets.splice(idx, 1);
    }),
    createSharedLink: vi.fn(async (data: any) => {
      const link = { id: ++linkIdCounter, ...data, createdAt: new Date() };
      sharedLinks.push(link);
      return link;
    }),
    getSharedLinkById: vi.fn(async (id: number) => sharedLinks.find(l => l.id === id) ?? null),
    getSharedLinkByToken: vi.fn(async (token: string) => sharedLinks.find(l => l.shareToken === token && l.isActive) ?? null),
    getSharedLinksByProject: vi.fn(async (projectId: number) => sharedLinks.filter(l => l.projectId === projectId)),
    toggleSharedLink: vi.fn(async (id: number, userId: number, isActive: boolean) => {
      const link = sharedLinks.find(l => l.id === id && l.userId === userId);
      if (link) link.isActive = isActive;
      return link ?? null;
    }),
    updateSharedLink: vi.fn(async (id: number, userId: number, data: any) => {
      const link = sharedLinks.find(l => l.id === id && l.userId === userId);
      if (link) Object.assign(link, data);
      return link ?? null;
    }),
    deleteSharedLink: vi.fn(async (id: number, userId: number) => {
      const idx = sharedLinks.findIndex(l => l.id === id && l.userId === userId);
      if (idx >= 0) sharedLinks.splice(idx, 1);
    }),
    createComment: vi.fn(async (data: any) => {
      const comment = { id: ++commentIdCounter, ...data, createdAt: new Date() };
      comments.push(comment);
      return comment;
    }),
    getCommentById: vi.fn(async (id: number) => comments.find(c => c.id === id) ?? null),
    getCommentsBySharedLink: vi.fn(async (sharedLinkId: number) => comments.filter(c => c.sharedLinkId === sharedLinkId)),
    deleteComment: vi.fn(async (id: number, userId: number) => {
      const idx = comments.findIndex(c => c.id === id && c.userId === userId);
      if (idx >= 0) comments.splice(idx, 1);
    }),
    upsertUser: vi.fn(),
    getUserByOpenId: vi.fn(),
  };
});

// Mock the storage module
vi.mock("./storage", () => ({
  storagePut: vi.fn(async (key: string) => ({
    key,
    url: `https://s3.example.com/${key}`,
  })),
  storageGet: vi.fn(async (key: string) => ({
    key,
    url: `https://s3.example.com/${key}`,
  })),
}));

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Auth ───────────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user data for authenticated users", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.auth.me();
    expect(result?.openId).toBe("user-1");
    expect(result?.name).toBe("User 1");
  });
});

describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
  });
});

// ─── Projects ───────────────────────────────────────────────────

describe("project routes", () => {
  it("creates a project", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Test Project", description: "A test" });
    expect(project).toBeDefined();
    expect(project?.name).toBe("Test Project");
    expect(project?.userId).toBe(1);
  });

  it("lists projects for user", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const projects = await caller.project.list();
    expect(Array.isArray(projects)).toBe(true);
  });

  it("gets a project by id", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const created = await caller.project.create({ name: "Get Test" });
    const project = await caller.project.get({ id: created!.id });
    expect(project?.name).toBe("Get Test");
  });

  it("updates a project", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const created = await caller.project.create({ name: "Update Test" });
    const updated = await caller.project.update({ id: created!.id, name: "Updated Name" });
    expect(updated?.name).toBe("Updated Name");
  });

  it("deletes a project", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const created = await caller.project.create({ name: "Delete Test" });
    const result = await caller.project.delete({ id: created!.id });
    expect(result).toEqual({ success: true });
  });

  it("rejects unauthenticated access", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(caller.project.list()).rejects.toThrow();
  });
});

// ─── Assets ─────────────────────────────────────────────────────

describe("asset routes", () => {
  it("uploads an asset", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Asset Test" });
    const asset = await caller.asset.upload({
      projectId: project!.id,
      name: "test-model",
      originalName: "test-model.obj",
      format: "obj",
      fileBase64: btoa("# OBJ file\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3"),
      fileSize: 100,
      contentType: "text/plain",
    });
    expect(asset?.name).toBe("test-model");
    expect(asset?.format).toBe("obj");
    expect(asset?.fileUrl).toContain("s3.example.com");
  });

  it("lists assets by project", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "List Assets" });
    const assets = await caller.asset.listByProject({ projectId: project!.id });
    expect(Array.isArray(assets)).toBe(true);
  });

  it("deletes an asset", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Delete Asset" });
    const asset = await caller.asset.upload({
      projectId: project!.id, name: "del", originalName: "del.stl",
      format: "stl", fileBase64: btoa("data"), fileSize: 50,
    });
    const result = await caller.asset.delete({ id: asset!.id });
    expect(result).toEqual({ success: true });
  });

  it("rejects unauthenticated upload", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(caller.asset.upload({
      projectId: 1, name: "t", originalName: "t.obj",
      format: "obj", fileBase64: "dGVzdA==", fileSize: 4,
    })).rejects.toThrow();
  });
});

// ─── Share routes ───────────────────────────────────────────────

describe("share routes", () => {
  it("creates a public share link", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Share Test" });
    const link = await caller.share.create({ projectId: project!.id });
    expect(link?.shareToken).toBeDefined();
    expect(link?.isActive).toBe(true);
    expect(link?.privacy).toBe("public");
    expect(link?.commentsEnabled).toBe(true);
  });

  it("creates a private share link", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Private Share" });
    const link = await caller.share.create({ projectId: project!.id, privacy: "private" });
    expect(link?.privacy).toBe("private");
  });

  it("creates a password-protected share link", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Password Share" });
    const link = await caller.share.create({
      projectId: project!.id,
      privacy: "password",
      password: "secret123",
    });
    expect(link?.privacy).toBe("password");
    expect(link?.passwordHash).toBeDefined();
    expect(link?.passwordHash).not.toBe("secret123"); // Should be hashed
  });

  it("creates a share link with comments disabled", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "No Comments" });
    const link = await caller.share.create({
      projectId: project!.id,
      commentsEnabled: false,
    });
    expect(link?.commentsEnabled).toBe(false);
  });

  it("lists share links by project", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "List Links" });
    await caller.share.create({ projectId: project!.id });
    const links = await caller.share.listByProject({ projectId: project!.id });
    expect(links.length).toBeGreaterThan(0);
  });

  it("toggles a share link", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Toggle Link" });
    const link = await caller.share.create({ projectId: project!.id });
    const toggled = await caller.share.toggle({ id: link!.id, isActive: false });
    expect(toggled?.isActive).toBe(false);
  });

  it("updates share link privacy settings", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Update Privacy" });
    const link = await caller.share.create({ projectId: project!.id });
    const updated = await caller.share.update({ id: link!.id, privacy: "private" });
    expect(updated?.privacy).toBe("private");
  });

  it("updates share link comments toggle", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Toggle Comments" });
    const link = await caller.share.create({ projectId: project!.id });
    const updated = await caller.share.update({ id: link!.id, commentsEnabled: false });
    expect(updated?.commentsEnabled).toBe(false);
  });

  it("gets project by share token (public)", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "Public View" });
    const link = await authCaller.share.create({ projectId: project!.id });

    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.share.getByToken({ token: link!.shareToken });
    expect(result.error).toBeNull();
    expect(result.project?.name).toBe("Public View");
  });

  it("returns password_required for password-protected links without password", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "PW View" });
    const link = await authCaller.share.create({
      projectId: project!.id,
      privacy: "password",
      password: "secret",
    });

    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.share.getByToken({ token: link!.shareToken });
    expect(result.error).toBe("password_required");
    expect(result.project).toBeNull();
  });

  it("returns not_found for invalid share token", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.share.getByToken({ token: "nonexistent" });
    expect(result.error).toBe("not_found");
  });

  it("deletes a share link", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const project = await caller.project.create({ name: "Delete Link" });
    const link = await caller.share.create({ projectId: project!.id });
    const result = await caller.share.delete({ id: link!.id });
    expect(result).toEqual({ success: true });
  });

  it("rejects unauthenticated share creation", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(caller.share.create({ projectId: 1 })).rejects.toThrow();
  });

  it("rejects invalid privacy enum", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(
      caller.share.create({ projectId: 1, privacy: "invalid" as any })
    ).rejects.toThrow();
  });
});

// ─── Comment routes ─────────────────────────────────────────────

describe("comment routes", () => {
  it("lists comments for a shared link (public)", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.comment.listByLink({ sharedLinkId: 999 });
    expect(Array.isArray(result)).toBe(true);
  });

  it("adds a comment (public / anonymous)", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "Comment Test" });
    const link = await authCaller.share.create({ projectId: project!.id });

    const publicCaller = appRouter.createCaller(createPublicContext());
    const comment = await publicCaller.comment.add({
      sharedLinkId: link!.id,
      authorName: "Anonymous",
      content: "Great model!",
    });
    expect(comment?.authorName).toBe("Anonymous");
    expect(comment?.content).toBe("Great model!");
  });

  it("adds a comment (authenticated user)", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "Auth Comment" });
    const link = await authCaller.share.create({ projectId: project!.id });

    const comment = await authCaller.comment.add({
      sharedLinkId: link!.id,
      authorName: "ignored",
      content: "Nice work!",
    });
    // Authenticated user's name should be used
    expect(comment?.authorName).toBe("User 1");
    expect(comment?.userId).toBe(1);
  });

  it("deletes own comment", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "Del Comment" });
    const link = await authCaller.share.create({ projectId: project!.id });
    const comment = await authCaller.comment.add({
      sharedLinkId: link!.id,
      authorName: "Me",
      content: "Delete me",
    });
    const result = await authCaller.comment.delete({ id: comment!.id });
    expect(result).toEqual({ success: true });
  });

  it("rejects empty comment content", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    await expect(
      publicCaller.comment.add({
        sharedLinkId: 1,
        authorName: "Test",
        content: "",
      })
    ).rejects.toThrow();
  });

  it("rejects empty author name", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    await expect(
      publicCaller.comment.add({
        sharedLinkId: 1,
        authorName: "",
        content: "Test comment",
      })
    ).rejects.toThrow();
  });

  it("rejects unauthenticated comment deletion", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    await expect(publicCaller.comment.delete({ id: 1 })).rejects.toThrow();
  });
});

// ─── AR routes ──────────────────────────────────────────────────

describe("ar routes", () => {
  it("returns not_found for invalid token", async () => {
    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.ar.getArModel({ token: "nonexistent-ar" });
    expect(result.error).toBe("not_found");
    expect(result.glbUrl).toBeNull();
    expect(result.assets).toBeNull();
  });

  it("returns asset data for valid public share token", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "AR Test Project" });
    await authCaller.asset.upload({
      projectId: project!.id,
      name: "ar-model",
      originalName: "model.glb",
      format: "glb",
      fileBase64: btoa("fake-glb-data"),
      fileSize: 1000,
      contentType: "model/gltf-binary",
    });
    const link = await authCaller.share.create({ projectId: project!.id });

    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.ar.getArModel({ token: link!.shareToken });
    expect(result.error).toBeNull();
    expect(result.glbUrl).toContain("s3.example.com");
    expect(result.assets).toBeDefined();
    expect(result.assets!.length).toBeGreaterThan(0);
  });

  it("returns password_required for password-protected links", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "AR PW Test" });
    const link = await authCaller.share.create({
      projectId: project!.id,
      privacy: "password",
      password: "arpass123",
    });

    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.ar.getArModel({ token: link!.shareToken });
    expect(result.error).toBe("password_required");
    expect(result.glbUrl).toBeNull();
  });

  it("returns assets list even without GLB format", async () => {
    const authCaller = appRouter.createCaller(createAuthContext());
    const project = await authCaller.project.create({ name: "AR OBJ Test" });
    await authCaller.asset.upload({
      projectId: project!.id,
      name: "obj-model",
      originalName: "model.obj",
      format: "obj",
      fileBase64: btoa("v 0 0 0"),
      fileSize: 50,
    });
    const link = await authCaller.share.create({ projectId: project!.id });

    const publicCaller = appRouter.createCaller(createPublicContext());
    const result = await publicCaller.ar.getArModel({ token: link!.shareToken });
    expect(result.error).toBeNull();
    expect(result.glbUrl).toBeNull(); // No GLB asset
    expect(result.assets!.length).toBeGreaterThan(0);
    expect(result.assets![0].format).toBe("obj");
  });
});
