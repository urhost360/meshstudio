import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { nanoid } from "nanoid";
import bcrypt from "bcryptjs";
import {
  createProject, getProjectById, getProjectsByUser, updateProject, deleteProject,
  createAsset, getAssetsByProject, deleteAsset, getAssetById, updateAsset,
  createSharedLink, getSharedLinkByToken, getSharedLinksByProject, toggleSharedLink,
  updateSharedLink, deleteSharedLink,
  createComment, getCommentsBySharedLink, deleteComment,
} from "./db";
import { storagePut, storageGet } from "./storage";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  project: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getProjectsByUser(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const project = await getProjectById(input.id);
        if (!project || project.userId !== ctx.user.id) return null;
        return project;
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1).max(255),
        description: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return createProject({
          userId: ctx.user.id,
          name: input.name,
          description: input.description ?? null,
          sceneData: null,
          thumbnailUrl: null,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        sceneData: z.any().optional(),
        thumbnailUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        return updateProject(id, ctx.user.id, data);
      }),


        delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteProject(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  asset: router({
    listByProject: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return getAssetsByProject(input.projectId);
      }),

    upload: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        name: z.string(),
        originalName: z.string(),
        format: z.string(),
        fileBase64: z.string(),
        fileSize: z.number(),
        contentType: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.fileBase64, "base64");
        const suffix = nanoid(8);
        const fileKey = `meshstudio/${ctx.user.id}/${input.projectId}/${input.name}-${suffix}.${input.format}`;
        const { url } = await storagePut(fileKey, buffer, input.contentType ?? "application/octet-stream");
        return createAsset({
          projectId: input.projectId,
          userId: ctx.user.id,
          name: input.name,
          originalName: input.originalName,
          format: input.format,
          fileKey,
          fileUrl: url,
          fileSize: input.fileSize,
          metadata: null,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        fileBase64: z.string(),
        fileSize: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        const asset = await getAssetById(input.id);
        if (!asset || asset.userId !== ctx.user.id) {
          throw new Error("Asset not found or unauthorized");
        }
        const buffer = Buffer.from(input.fileBase64, "base64");
        const suffix = nanoid(8);
        const fileKey = `meshstudio/${ctx.user.id}/${asset.projectId}/${asset.name}-${suffix}.${asset.format}`;
        const { url } = await storagePut(fileKey, buffer, "application/octet-stream");
        return updateAsset(input.id, ctx.user.id, {
          fileKey,
          fileUrl: url,
          fileSize: input.fileSize,
        });
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteAsset(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  share: router({
    create: protectedProcedure
      .input(z.object({
        projectId: z.number(),
        privacy: z.enum(["public", "private", "password"]).default("public"),
        password: z.string().optional(),
        commentsEnabled: z.boolean().default(true),
      }))
      .mutation(async ({ ctx, input }) => {
        const token = nanoid(16);
        let passwordHash: string | null = null;
        if (input.privacy === "password" && input.password) {
          passwordHash = await bcrypt.hash(input.password, 10);
        }
        return createSharedLink({
          projectId: input.projectId,
          userId: ctx.user.id,
          shareToken: token,
          isActive: true,
          privacy: input.privacy,
          passwordHash,
          commentsEnabled: input.commentsEnabled,
          expiresAt: null,
        });
      }),

    listByProject: protectedProcedure
      .input(z.object({ projectId: z.number() }))
      .query(async ({ input }) => {
        return getSharedLinksByProject(input.projectId);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        privacy: z.enum(["public", "private", "password"]).optional(),
        password: z.string().optional(),
        commentsEnabled: z.boolean().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, password, ...data } = input;
        const updateData: any = { ...data };
        if (data.privacy === "password" && password) {
          updateData.passwordHash = await bcrypt.hash(password, 10);
        } else if (data.privacy && data.privacy !== "password") {
          updateData.passwordHash = null;
        }
        return updateSharedLink(id, ctx.user.id, updateData);
      }),

    toggle: protectedProcedure
      .input(z.object({ id: z.number(), isActive: z.boolean() }))
      .mutation(async ({ ctx, input }) => {
        return toggleSharedLink(input.id, ctx.user.id, input.isActive);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteSharedLink(input.id, ctx.user.id);
        return { success: true };
      }),

    /** Public: get project data by share token (no auth required) */
    getByToken: publicProcedure
      .input(z.object({ token: z.string(), password: z.string().optional() }))
      .query(async ({ input }) => {
        const link = await getSharedLinkByToken(input.token);
        if (!link) return { error: "not_found" as const, project: null, assets: null, link: null, commentsEnabled: false };

        // Check password if required
        if (link.privacy === "password") {
          if (!input.password || !link.passwordHash) {
            return { error: "password_required" as const, project: null, assets: null, link: null, commentsEnabled: false };
          }
          const valid = await bcrypt.compare(input.password, link.passwordHash);
          if (!valid) {
            return { error: "wrong_password" as const, project: null, assets: null, link: null, commentsEnabled: false };
          }
        }

        const project = await getProjectById(link.projectId);
        if (!project) return { error: "not_found" as const, project: null, assets: null, link: null, commentsEnabled: false };
        const projectAssets = await getAssetsByProject(project.id);
        return {
          error: null,
          project,
          assets: projectAssets,
          link: { id: link.id, shareToken: link.shareToken, privacy: link.privacy, commentsEnabled: link.commentsEnabled },
          commentsEnabled: link.commentsEnabled,
        };
      }),
  }),

  /** Generate AR-ready GLB URL for a shared project */
  ar: router({
    getArModel: publicProcedure
      .input(z.object({ token: z.string(), password: z.string().optional() }))
      .query(async ({ input }) => {
        const link = await getSharedLinkByToken(input.token);
        if (!link) return { error: "not_found" as const, glbUrl: null, usdzUrl: null, assets: null };

        // Check password if required
        if (link.privacy === "password") {
          if (!input.password || !link.passwordHash) {
            return { error: "password_required" as const, glbUrl: null, usdzUrl: null, assets: null };
          }
          const valid = await bcrypt.compare(input.password, link.passwordHash);
          if (!valid) {
            return { error: "wrong_password" as const, glbUrl: null, usdzUrl: null, assets: null };
          }
        }

        const project = await getProjectById(link.projectId);
        if (!project) return { error: "not_found" as const, glbUrl: null, usdzUrl: null, assets: null };
        const projectAssets = await getAssetsByProject(project.id);

        // Find GLB/GLTF assets directly, or return all asset URLs for client-side conversion
        const glbAsset = projectAssets.find(a => a.format === "glb" || a.format === "gltf");
        const usdzAsset = projectAssets.find(a => a.format === "usdz");

        return {
          error: null,
          glbUrl: glbAsset?.fileUrl ?? null,
          usdzUrl: usdzAsset?.fileUrl ?? null,
          assets: projectAssets.map(a => ({
            id: a.id,
            name: a.name,
            format: a.format,
            fileUrl: a.fileUrl,
            metadata: a.metadata,
          })),
        };
      }),
  }),

  comment: router({
    /** Public: list comments for a shared link */
    listByLink: publicProcedure
      .input(z.object({ sharedLinkId: z.number() }))
      .query(async ({ input }) => {
        return getCommentsBySharedLink(input.sharedLinkId);
      }),

    /** Public: add a comment (works for both logged-in and anonymous users) */
    add: publicProcedure
      .input(z.object({
        sharedLinkId: z.number(),
        authorName: z.string().min(1).max(128),
        content: z.string().min(1).max(2000),
      }))
      .mutation(async ({ ctx, input }) => {
        return createComment({
          sharedLinkId: input.sharedLinkId,
          userId: ctx.user?.id ?? null,
          authorName: ctx.user?.name ?? input.authorName,
          content: input.content,
        });
      }),

    /** Protected: delete own comment */
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteComment(input.id, ctx.user.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
