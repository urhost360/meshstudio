# MeshStudio - 3D Asset Editor

A web-based 3D model editor similar to Blender, built with React, Three.js, and tRPC. Upload, edit, and share 3D models with AR preview capabilities.

**Status:** ✅ Production-ready (39 passing tests)

---

## Quick Start

### Prerequisites
- Node.js 18+ (tested on 22.13.0)
- pnpm (or npm/yarn)
- MySQL/TiDB database
- Manus account (for OAuth and S3 storage)

### Installation

```bash
# Clone repository
git clone https://github.com/urhost360/meshstudio.git
cd meshstudio

# Install dependencies
pnpm install

# Configure environment
cp .env.example .env.local
# Edit .env.local with your values (see Configuration below)

# Setup database
pnpm db:push

# Start development server
pnpm dev
```

**Server runs on:** `http://localhost:3000`

---

## Configuration

### Environment Variables

See `.env.example` for complete list. Key variables:

```bash
# Database
DATABASE_URL=mysql://user:password@localhost:3306/meshstudio

# Authentication
VITE_APP_ID=your_manus_app_id
JWT_SECRET=your_random_secret_key

# Manus APIs
BUILT_IN_FORGE_API_URL=https://forge.manus.im
BUILT_IN_FORGE_API_KEY=your_backend_key
VITE_FRONTEND_FORGE_API_KEY=your_frontend_key
```

### For Manus Platform

If deploying on Manus, environment variables are **automatically injected**. No manual configuration needed.

---

## Project Structure

```
meshstudio/
├── client/                          # React frontend
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Editor.tsx          # Main editor page (719 lines)
│   │   │   ├── SharedView.tsx      # Public share view with AR
│   │   │   └── Home.tsx            # Landing page
│   │   ├── components/
│   │   │   ├── ThreeViewport.tsx   # 3D viewport (258 lines)
│   │   │   ├── VertexEditor.tsx    # Polygon editing (411 lines)
│   │   │   ├── Toolbar.tsx         # Main toolbar
│   │   │   ├── PropertiesPanel.tsx # Material/transform editor
│   │   │   ├── SceneHierarchy.tsx  # Object tree
│   │   │   ├── BatchTransformPanel.tsx # Multi-select operations
│   │   │   ├── ShareDialog.tsx     # Sharing UI
│   │   │   ├── ExportDialog.tsx    # Export options
│   │   │   └── [other components]
│   │   ├── lib/
│   │   │   ├── trpc.ts             # tRPC client setup
│   │   │   ├── historyManager.ts   # Undo/redo (263 lines)
│   │   │   ├── fileLoader.ts       # 3D file parsing
│   │   │   ├── glbExporter.ts      # GLB export
│   │   │   └── meshOps.ts          # Geometry utilities
│   │   ├── App.tsx                 # Routes and layout
│   │   ├── main.tsx                # Entry point
│   │   └── index.css               # Global styles
│   ├── index.html                  # HTML template
│   └── public/                     # Static assets
│
├── server/                          # Express + tRPC backend
│   ├── routers.ts                  # tRPC procedures (API)
│   ├── db.ts                       # Database queries
│   ├── storage.ts                  # S3 file operations
│   ├── auth.logout.test.ts         # Example test
│   ├── routers.test.ts             # API tests
│   └── _core/                      # Framework (don't edit)
│       ├── index.ts                # Server entry point
│       ├── env.ts                  # Environment config
│       ├── context.ts              # tRPC context
│       ├── oauth.ts                # OAuth integration
│       ├── llm.ts                  # LLM integration
│       ├── imageGeneration.ts      # Image generation
│       ├── voiceTranscription.ts   # Voice-to-text
│       ├── map.ts                  # Google Maps proxy
│       ├── notification.ts         # Owner notifications
│       └── [other services]
│
├── drizzle/                         # Database schema
│   ├── schema.ts                   # Table definitions
│   └── migrations/                 # Migration files
│
├── shared/                          # Shared constants
│   └── constants.ts
│
├── storage/                         # S3 helpers
│   └── index.ts
│
├── package.json                     # Dependencies
├── tsconfig.json                    # TypeScript config
├── vite.config.ts                  # Vite build config
├── drizzle.config.ts               # Drizzle ORM config
├── vitest.config.ts                # Test config
│
├── ARCHITECTURE.md                 # System design (READ THIS!)
├── CONTRIBUTING.md                 # Contribution guidelines
├── .env.example                    # Environment template
├── .gitignore                      # Git ignore rules
└── README.md                       # This file
```

---

## Key Features

### ✅ Implemented

- **Multi-format import:** OBJ, STL, FBX, GLTF, GLB, ZIP
- **Polygon editing:** Lasso/box selection, delete, simplify, subdivide
- **Material editing:** Color, metalness, roughness, opacity
- **Transform tools:** Position, rotation, scale
- **Batch operations:** Multi-select, align, distribute
- **Undo/Redo:** Full history with Ctrl+Z/Ctrl+Y
- **Auto-save:** Every 30 seconds
- **Project management:** Create, save, load, delete
- **Sharing system:** Public links with privacy settings
- **AR preview:** Model-viewer integration for AR Quick Look (iOS) and WebXR (Android)
- **Social sharing:** QR codes, Twitter, Facebook, LinkedIn, Reddit
- **Comments:** On shared links
- **Mobile responsive:** Works on all device sizes

### 📋 Known Limitations

- **AR rendering quality:** White spots/artifacts in some cases
- **Large scenes:** Performance degrades with 100+ objects
- **Texture support:** Limited to basic material properties
- **Collaboration:** Single-user editing (no real-time sync)

---

## Development

### Running Tests

```bash
# Run all tests
pnpm test

# Run specific test file
pnpm test server/routers.test.ts

# Watch mode
pnpm test --watch

# Coverage
pnpm test --coverage
```

**Current Status:** 39 passing tests ✅

### Building

```bash
# Development build (with HMR)
pnpm dev

# Production build
pnpm build

# Preview production build
pnpm preview
```

### Database Migrations

```bash
# Push schema changes to database
pnpm db:push

# Generate migration files
pnpm db:generate

# View database UI
pnpm db:studio
```

### Code Quality

```bash
# Format code
pnpm format

# Lint
pnpm lint
```

---

## Architecture Overview

**For detailed architecture, see [ARCHITECTURE.md](./ARCHITECTURE.md)**

### High-Level Flow

```
User → React Editor → Three.js Viewport → tRPC Backend → MySQL + S3
```

### Key Components

| Component | Purpose | Lines |
|-----------|---------|-------|
| `Editor.tsx` | Main editor state & coordination | 719 |
| `ThreeViewport.tsx` | 3D rendering & camera controls | 258 |
| `VertexEditor.tsx` | Polygon selection & editing | 411 |
| `HistoryManager.ts` | Undo/redo system | 263 |
| `server/routers.ts` | tRPC API endpoints | ~400 |
| `drizzle/schema.ts` | Database schema | ~200 |

### Data Flow

1. **Import:** User uploads file → Server stores in S3 → Frontend loads from S3 → Scene updated
2. **Edit:** User modifies geometry → History saved → Scene re-rendered
3. **Save:** User clicks Save → Scene serialized → Server updates DB + S3
4. **Share:** User creates link → Server generates token → Public link created
5. **AR:** Recipient visits link → Scene loads → GLB generated → AR preview ready

---

## Common Tasks

### Add a New Edit Tool

1. Define in `EditMode` enum (`Editor.tsx` line 8)
2. Add button to Toolbar (`Toolbar.tsx`)
3. Create tool component (e.g., `MyToolPanel.tsx`)
4. Implement operation in `Editor.tsx`
5. Save to history after operation

**See [ARCHITECTURE.md](./ARCHITECTURE.md#adding-a-new-edit-tool) for detailed example**

### Add a New API Endpoint

1. Create database query in `server/db.ts`
2. Add tRPC procedure in `server/routers.ts`
3. Call from frontend with `trpc.*.useQuery/useMutation`

**See [ARCHITECTURE.md](./ARCHITECTURE.md#adding-a-new-api-endpoint) for detailed example**

### Add a New Material Property

1. Update schema in `drizzle/schema.ts`
2. Run `pnpm db:push`
3. Update UI in `PropertiesPanel.tsx`
4. Save to backend in `Editor.tsx`

**See [ARCHITECTURE.md](./ARCHITECTURE.md#adding-a-new-material-property) for detailed example**

---

## Deployment

### On Manus Platform

1. Create account at https://manus.im
2. Create new web project
3. Connect GitHub repository
4. Push code to `main` branch
5. Platform automatically deploys

**Environment variables are auto-injected by Manus.**

### On Other Platforms

Requires manual setup of:
- Node.js runtime
- MySQL database
- S3-compatible storage
- OAuth provider
- Environment variables

---

## Troubleshooting

### "Cannot find module" errors

```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Database connection fails

```bash
# Verify DATABASE_URL in .env.local
# Format: mysql://user:password@host:port/database
# Test connection:
pnpm db:studio
```

### Three.js errors in console

- Check that models are valid 3D files
- Verify file format is supported (OBJ, STL, FBX, GLTF, GLB)
- Check browser console for specific error messages

### AR not working

- iOS: Requires Safari browser
- Android: Requires Chrome with WebXR support
- Verify GLB file is valid (export and test locally)

### Performance issues

- Reduce polygon count (use Simplify tool)
- Limit scene to <100 objects
- Close other browser tabs
- Try different browser

---

## Testing Checklist

Before committing changes:

- [ ] Run `pnpm test` - all tests pass
- [ ] Run `pnpm build` - builds without errors
- [ ] Test in development: `pnpm dev`
- [ ] Test in production: `pnpm build && pnpm preview`
- [ ] Verify no console errors
- [ ] Test on mobile (if UI changes)
- [ ] Test undo/redo (if state changes)

---

## Safety Guidelines

### ⚠️ Critical Areas

**Don't bypass these patterns:**

1. **Scene State Sync**
   - Always call `refreshSceneObjects()` after adding/deleting objects
   - Never mutate `sceneObjects` directly
   - Verify `sceneObjects` matches `scene.children`

2. **Selection Management**
   - Validate selection exists before using
   - Clear selection when switching modes
   - Check `sceneObjects.includes(selectedObject)`

3. **History Capture**
   - Save history BEFORE operation completes
   - Include all state changes
   - Test undo/redo after changes

4. **Memory Management**
   - Dispose geometries before replacing
   - Dispose materials before replacing
   - Remove event listeners on unmount

5. **Performance**
   - Cache expensive computations
   - Debounce frequent operations
   - Profile with DevTools

**See [ARCHITECTURE.md](./ARCHITECTURE.md#dangerous-areas--guardrails) for detailed safety guidelines**

---

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for:
- Code style guidelines
- Commit message format
- Pull request process
- Testing requirements
- Common pitfalls

---

## Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Frontend | React | 18 |
| 3D Engine | Three.js | 0.170.0 |
| Styling | Tailwind CSS | 4 |
| Backend | Express | 4 |
| API | tRPC | 11 |
| Database | MySQL + Drizzle | Latest |
| Build | Vite | Latest |
| Testing | Vitest | Latest |
| Platform | Manus | Latest |

---

## Performance Metrics

- **Load time:** <2 seconds (empty project)
- **Import time:** 1-5 seconds (depending on file size)
- **Undo/redo:** <100ms
- **Scene limit:** 100+ objects (performance degrades)
- **Polygon limit:** 1M+ vertices (depends on device)

---

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

**Mobile:**
- iOS Safari 14+
- Android Chrome 90+

---

## License

[Add your license here]

---

## Support

- **Issues:** GitHub Issues
- **Discussions:** GitHub Discussions
- **Documentation:** See [ARCHITECTURE.md](./ARCHITECTURE.md)

---

## Roadmap

### Planned Features
- [ ] 3-axis rotation gizmo
- [ ] Turntable camera mode
- [ ] Model duplication shortcut
- [ ] Viewport grid toggle
- [ ] Face extrude feature
- [ ] Real-time collaboration
- [ ] Advanced texture support
- [ ] Animation timeline

### Known Issues
- AR rendering quality (white spots in some cases)
- Large scene performance
- Limited texture support

---

## Acknowledgments

Built with:
- [Three.js](https://threejs.org/) - 3D graphics
- [React](https://react.dev/) - UI framework
- [tRPC](https://trpc.io/) - Type-safe APIs
- [Tailwind CSS](https://tailwindcss.com/) - Styling
- [Manus](https://manus.im/) - Platform

---

**Last Updated:** February 2026  
**Status:** Production Ready ✅
