# MeshStudio Architecture Guide

**For future developers and AI agents:** This document explains the system design so you can understand, modify, and extend MeshStudio safely.

---

## System Overview

MeshStudio is a **web-based 3D model editor** similar to Blender. Users can:
- Upload 3D assets (OBJ, STL, FBX, GLTF, GLB, ZIP)
- Edit polygons (lasso/box selection, delete, simplify, subdivide)
- Edit materials (color, metalness, roughness, opacity)
- Combine multiple assets
- Share work via hosted web links with AR preview

**Tech Stack:**
- **Frontend:** React 18 + TypeScript + Three.js + Tailwind CSS
- **Backend:** Express + tRPC + Node.js
- **Database:** MySQL with Drizzle ORM
- **Platform:** Manus (OAuth, S3 storage, database hosting, deployment)
- **Testing:** Vitest (39 passing tests)

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Browser (Client)                        │
│  React 18 + Three.js + Tailwind CSS                        │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Editor Page (Editor.tsx)                             │  │
│  │ - Manages editor state (selected object, edit mode)  │  │
│  │ - Handles file import/export                         │  │
│  │ - Coordinates undo/redo                              │  │
│  │ - Manages UI panels (properties, hierarchy, etc.)    │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Three.js Viewport (ThreeViewport.tsx)                │  │
│  │ - 3D scene rendering                                 │  │
│  │ - Camera controls (orbit, pan, zoom)                 │  │
│  │ - Object picking (raycaster)                         │  │
│  │ - Transform controls                                 │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Vertex Editor (VertexEditor.tsx)                     │  │
│  │ - Polygon selection (lasso, box)                     │  │
│  │ - Vertex/face manipulation                           │  │
│  │ - Geometry operations (delete, simplify, subdivide)  │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ UI Components                                        │  │
│  │ - Toolbar (tools, undo/redo, save)                   │  │
│  │ - Properties Panel (material, transform)             │  │
│  │ - Scene Hierarchy (object tree)                      │  │
│  │ - Batch Transform Panel (multi-select)               │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                            ↕ tRPC
┌─────────────────────────────────────────────────────────────┐
│                   Backend (Server)                          │
│  Express + tRPC + Node.js                                  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ tRPC Router (server/routers.ts)                      │  │
│  │ - projects.* (CRUD operations)                       │  │
│  │ - assets.* (upload, delete, update)                  │  │
│  │ - sharing.* (create, get, update links)              │  │
│  │ - comments.* (add, get, delete)                      │  │
│  │ - auth.* (login, logout, me)                         │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Database Layer (server/db.ts)                        │  │
│  │ - Query helpers                                      │  │
│  │ - Drizzle ORM integration                            │  │
│  │ - Transaction support                                │  │
│  └──────────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Storage Layer (server/storage.ts)                    │  │
│  │ - S3 upload/download                                 │  │
│  │ - File management                                    │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                   External Services                         │
│  - MySQL Database (Manus-hosted)                           │
│  - S3 Storage (Manus-hosted)                               │
│  - OAuth (Manus platform)                                  │
│  - Model Viewer (Google - AR preview)                      │
│  - QR Code API (qrserver.com)                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Data Flow

### 1. Project Creation & Loading

```
User creates project
    ↓
Editor.tsx initializes with empty scene
    ↓
useEffect fetches project from server (trpc.projects.get)
    ↓
Server returns project metadata + asset list
    ↓
Frontend loads each asset (loadModelFromUrl)
    ↓
Three.js scene populated with objects
    ↓
React state (sceneObjects) updated
    ↓
UI renders object hierarchy
```

### 2. File Import

```
User drags files onto viewport
    ↓
handleDragOver/handleDrop triggers
    ↓
Files validated (OBJ, STL, FBX, GLTF, GLB, ZIP)
    ↓
handleFilesSelected processes each file
    ↓
File uploaded to server (trpc.assets.upload)
    ↓
Server stores in S3, returns URL
    ↓
Frontend loads model from URL (loadModelFromUrl)
    ↓
Model added to Three.js scene
    ↓
React state updated (setSceneObjects)
    ↓
History saved (historyRef.current.saveState)
```

### 3. Polygon Editing

```
User enters vertex/face edit mode
    ↓
VertexEditor initialized with selected object's geometry
    ↓
User selects vertices/faces (lasso or box)
    ↓
Selection stored in VertexEditor state
    ↓
User performs operation (delete, simplify, subdivide)
    ↓
Geometry modified directly in Three.js
    ↓
History saved with new geometry state
    ↓
Viewport re-renders with updated geometry
```

### 4. Save & Auto-Save

```
User clicks Save OR 30-second auto-save timer fires
    ↓
getCurrentSceneData() serializes scene state
    ↓
trpc.projects.update sends to server
    ↓
Server updates database + S3
    ↓
Toast notification shows success
```

### 5. Sharing

```
User clicks Share
    ↓
ShareDialog opens
    ↓
User sets privacy + generates link
    ↓
trpc.sharing.create called
    ↓
Server creates share record in database
    ↓
Returns share URL + QR code
    ↓
User shares link (copy/QR/social)
    ↓
Recipient visits SharedView.tsx
    ↓
Scene loads in Three.js viewport
    ↓
AR preview room auto-generated from GLB
    ↓
User can view in AR or 3D viewport
```

---

## Key Subsystems

### Editor State Management

**Location:** `Editor.tsx` (lines 29-719)

**Responsibilities:**
- Maintain current project state
- Track selected object/objects
- Manage edit mode (object/vertex/face/edge)
- Coordinate file import/export
- Trigger undo/redo
- Auto-save every 30 seconds

**Key State Variables:**
```typescript
const [selectedObject, setSelectedObject] = useState<THREE.Object3D | null>(null);
const [selectedObjects, setSelectedObjects] = useState<Set<THREE.Object3D>>(new Set());
const [editMode, setEditMode] = useState<EditMode>("object");
const [sceneObjects, setSceneObjects] = useState<THREE.Object3D[]>([]);
const [isDraggingFile, setIsDraggingFile] = useState(false);
```

**Critical Invariants:**
- `sceneObjects` must match `viewportRef.scene.children` (filtered)
- `selectedObject` must be in `sceneObjects` or null
- `editMode` determines which tools are available
- History must be saved after every state-changing operation

---

### Three.js Viewport

**Location:** `ThreeViewport.tsx` (lines 1-258)

**Responsibilities:**
- Render 3D scene
- Handle camera controls (orbit, pan, zoom)
- Detect object selection (raycaster)
- Display transform controls
- Manage lighting

**Key Components:**
- **Scene:** THREE.Scene() - contains all 3D objects
- **Camera:** THREE.PerspectiveCamera - viewpoint
- **Renderer:** THREE.WebGLRenderer - renders to canvas
- **OrbitControls:** Camera movement
- **TransformControls:** Object manipulation (position/rotation/scale)
- **Raycaster:** Object picking on mouse events

**Critical Invariants:**
- Renderer must be disposed on unmount
- Event listeners must be removed on unmount
- Objects added to scene must have unique names
- Transform controls must be detached before deletion

---

### Vertex Editor

**Location:** `VertexEditor.tsx` (lines 1-411)

**Responsibilities:**
- Select vertices/faces (lasso or box selection)
- Perform geometry operations (delete, simplify, subdivide)
- Display selection visualization
- Update geometry in real-time

**Key Methods:**
- `selectVerticesByLasso()` - lasso selection
- `selectVerticesByBox()` - box selection
- `deleteSelected()` - remove selected vertices/faces
- `simplifyGeometry()` - reduce polygon count
- `subdivideGeometry()` - increase polygon count

**Critical Invariants:**
- Selection must be cleared before changing objects
- Geometry must be updated before rendering
- Indices must be valid after deletion
- Normals must be recomputed after geometry changes

---

### History Manager (Undo/Redo)

**Location:** `client/src/lib/historyManager.ts` (lines 1-263)

**Responsibilities:**
- Capture scene state before operations
- Store history entries (max 50)
- Restore previous states on undo
- Restore next states on redo

**Key Methods:**
- `saveState(scene, description)` - save current state
- `undo()` - restore previous state
- `redo()` - restore next state
- `canUndo()` / `canRedo()` - check availability

**How It Works:**
1. Before operation: `historyRef.current.saveState(scene, "Operation name")`
2. Operation executes (geometry modified, objects added/deleted)
3. User presses Ctrl+Z
4. `undo()` restores previous scene state
5. Viewport re-renders with restored state

**Critical Invariants:**
- History saved BEFORE operation completes
- Only 50 states kept in memory (oldest discarded)
- Redo cleared when new operation performed after undo

---

### Backend API (tRPC)

**Location:** `server/routers.ts`

**Procedures:**

| Procedure | Type | Purpose |
|-----------|------|---------|
| `projects.get` | query | Fetch project by ID |
| `projects.list` | query | List user's projects |
| `projects.create` | mutation | Create new project |
| `projects.update` | mutation | Save project state |
| `projects.delete` | mutation | Delete project |
| `assets.upload` | mutation | Upload 3D file to S3 |
| `assets.delete` | mutation | Delete asset |
| `assets.update` | mutation | Update asset geometry |
| `sharing.create` | mutation | Create share link |
| `sharing.get` | query | Get share by token |
| `sharing.update` | mutation | Update share settings |
| `comments.add` | mutation | Add comment to share |
| `comments.get` | query | Get comments for share |
| `auth.me` | query | Get current user |
| `auth.logout` | mutation | Logout user |

**Authentication:**
- `publicProcedure` - no auth required
- `protectedProcedure` - requires logged-in user
- Context includes `ctx.user` with user ID, email, role

---

### Database Schema

**Location:** `drizzle/schema.ts`

**Key Tables:**

| Table | Purpose | Key Fields |
|-------|---------|-----------|
| `users` | User accounts | id, email, role, createdAt |
| `projects` | User projects | id, userId, name, description, createdAt, updatedAt |
| `assets` | 3D model files | id, projectId, filename, url, fileSize, format, createdAt |
| `shares` | Public share links | id, projectId, token, isPublic, expiresAt, createdAt |
| `comments` | Comments on shares | id, shareId, userId, content, createdAt |

**Relationships:**
- User → Projects (1:many)
- Project → Assets (1:many)
- Project → Shares (1:many)
- Share → Comments (1:many)

---

### File Import/Export

**Location:** `client/src/lib/fileLoader.ts`, `client/src/lib/glbExporter.ts`

**Supported Formats:**

| Format | Import | Export | Notes |
|--------|--------|--------|-------|
| OBJ | ✓ | ✓ | Wavefront OBJ |
| STL | ✓ | ✓ | Stereolithography |
| FBX | ✓ | ✗ | Autodesk FBX |
| GLTF | ✓ | ✓ | GL Transmission Format |
| GLB | ✓ | ✓ | Binary GLTF |
| ZIP | ✓ | ✗ | Multi-file archive |

**Import Process:**
1. File uploaded to server
2. Server stores in S3
3. Frontend fetches from S3
4. Three.js loaders parse format
5. Geometry added to scene
6. Material created with default properties

**Export Process:**
1. Scene serialized to GLB format
2. Geometry + materials + textures included
3. GLB uploaded to S3
4. URL returned to user

---

### Shared View & AR

**Location:** `client/src/pages/SharedView.tsx`

**Flow:**
1. User visits share link
2. `SharedView.tsx` loads
3. Fetches share metadata + project data
4. Loads 3D model into Three.js viewport
5. Auto-generates GLB for AR
6. Displays AR preview room with model-viewer
7. User can tap "Place in Your Space" to activate AR

**AR Implementation:**
- Uses `<model-viewer>` web component from Google
- Loads GLB file
- Provides AR Quick Look (iOS) + WebXR (Android)
- No app installation required

---

## Common Modification Patterns

### Adding a New Edit Tool

1. **Define tool in `EditMode` enum** (`Editor.tsx` line 8)
   ```typescript
   type EditMode = "object" | "vertex" | "face" | "edge" | "myNewTool";
   ```

2. **Add UI button to Toolbar** (`Toolbar.tsx`)
   ```typescript
   <button onClick={() => setEditMode("myNewTool")}>
     My Tool
   </button>
   ```

3. **Create tool component** (e.g., `MyToolPanel.tsx`)
   ```typescript
   export function MyToolPanel({ selectedObject, onApply }) {
     return (
       <div>
         {/* Tool UI */}
         <button onClick={() => onApply()}>Apply</button>
       </div>
     );
   }
   ```

4. **Add to Editor.tsx**
   ```typescript
   {editMode === "myNewTool" && (
     <MyToolPanel 
       selectedObject={selectedObject}
       onApply={handleMyToolApply}
     />
   )}
   ```

5. **Implement operation**
   ```typescript
   const handleMyToolApply = useCallback(() => {
     if (!selectedObject || !viewportRef) return;
     
     // Perform operation on selectedObject
     // ...
     
     // Save to history
     historyRef.current.saveState(viewportRef.scene, "My Tool Operation");
     
     // Update UI
     refreshSceneObjects();
   }, [selectedObject, viewportRef]);
   ```

### Adding a New API Endpoint

1. **Define database query** (`server/db.ts`)
   ```typescript
   export async function getMyData(userId: string) {
     return db.query.myTable.findMany({
       where: eq(myTable.userId, userId),
     });
   }
   ```

2. **Add tRPC procedure** (`server/routers.ts`)
   ```typescript
   myFeature: {
     getData: protectedProcedure
       .query(async ({ ctx }) => {
         return getMyData(ctx.user.id);
       }),
   }
   ```

3. **Call from frontend** (`Editor.tsx`)
   ```typescript
   const { data } = trpc.myFeature.getData.useQuery();
   ```

### Adding a New Material Property

1. **Update database schema** (`drizzle/schema.ts`)
   ```typescript
   export const assets = sqliteTable("assets", {
     // ... existing fields ...
     myProperty: real("my_property"),
   });
   ```

2. **Run migration** 
   ```bash
   pnpm db:push
   ```

3. **Update Material Editor** (`PropertiesPanel.tsx`)
   ```typescript
   <input
     type="range"
     value={material.myProperty}
     onChange={(e) => {
       material.myProperty = parseFloat(e.target.value);
       updateMaterial(material);
     }}
   />
   ```

4. **Save to backend** (`Editor.tsx`)
   ```typescript
   await trpc.assets.update.mutate({
     assetId: selectedObject.userData.assetId,
     myProperty: material.myProperty,
   });
   ```

---

## Dangerous Areas & Guardrails

### ⚠️ CRITICAL: Scene State Desynchronization

**Problem:** React state and Three.js scene can diverge

**Guardrails:**
- Always call `refreshSceneObjects()` after adding/deleting objects
- Never mutate `sceneObjects` directly - use `setSceneObjects()`
- Verify `sceneObjects.length === viewportRef.scene.children.filter(...).length`

**Safe Pattern:**
```typescript
// ✓ GOOD
viewportRef.addObject(model);
setSceneObjects(prev => [...prev, model]);

// ✗ BAD
sceneObjects.push(model); // Direct mutation
viewportRef.addObject(model); // No state update
```

### ⚠️ CRITICAL: Selection Ownership

**Problem:** Selection can be in React state but not in Three.js, or vice versa

**Guardrails:**
- Always validate selection exists in scene before using
- Clear selection when switching edit modes
- Verify selected object is in `sceneObjects`

**Safe Pattern:**
```typescript
// ✓ GOOD
if (selectedObject && sceneObjects.includes(selectedObject)) {
  // Safe to use selectedObject
}

// ✗ BAD
if (selectedObject) {
  // selectedObject might not be in scene anymore
}
```

### ⚠️ CRITICAL: Undo/Redo Completeness

**Problem:** Operations not saved to history become unrecoverable

**Guardrails:**
- Save history BEFORE operation completes
- Include all state changes in history
- Test undo/redo after adding new operations

**Safe Pattern:**
```typescript
// ✓ GOOD
historyRef.current.saveState(viewportRef.scene, "Delete vertices");
vertexEditor.deleteSelected();
refreshSceneObjects();

// ✗ BAD
vertexEditor.deleteSelected();
refreshSceneObjects();
// History never saved!
```

### ⚠️ HIGH: Memory Leaks

**Problem:** Three.js objects not disposed cause memory leaks

**Guardrails:**
- Dispose geometries before replacing
- Dispose materials before replacing
- Remove event listeners on unmount
- Dispose renderer on unmount

**Safe Pattern:**
```typescript
// ✓ GOOD
useEffect(() => {
  // ... setup ...
  return () => {
    renderer.dispose();
    geometry.dispose();
    material.dispose();
  };
}, []);

// ✗ BAD
useEffect(() => {
  // ... setup ...
  // No cleanup!
}, []);
```

### ⚠️ HIGH: Event Listener Stacking

**Problem:** Event listeners added multiple times cause multiple handlers

**Guardrails:**
- Remove listeners before adding new ones
- Use cleanup function in useEffect
- Don't add listeners in render

**Safe Pattern:**
```typescript
// ✓ GOOD
useEffect(() => {
  const handler = (e) => { /* ... */ };
  element.addEventListener("click", handler);
  return () => element.removeEventListener("click", handler);
}, []);

// ✗ BAD
element.addEventListener("click", handler); // Added every render!
```

### ⚠️ MEDIUM: Expensive Operations

**Problem:** Full scene traversals on every mouse event cause jank

**Guardrails:**
- Cache scene object list
- Use spatial indexing for raycasting
- Debounce expensive operations
- Profile performance with DevTools

**Safe Pattern:**
```typescript
// ✓ GOOD - Cache objects
const userObjects = useMemo(() => getUserObjects(), [sceneObjects]);
const intersects = raycaster.intersectObjects(userObjects);

// ✗ BAD - Traverse every event
const intersects = raycaster.intersectObjects(getUserObjects());
```

---

## Testing

**Location:** `server/*.test.ts`, `client/src/**/*.test.ts`

**Run Tests:**
```bash
pnpm test
```

**Current Coverage:** 39 passing tests

**Key Test Files:**
- `server/auth.logout.test.ts` - Authentication flow
- `server/routers.test.ts` - API endpoints
- `client/src/lib/historyManager.test.ts` - Undo/redo logic

**Testing Best Practices:**
1. Test each procedure independently
2. Mock database calls
3. Verify error handling
4. Test edge cases (empty arrays, null values, etc.)

---

## Deployment

**Platform:** Manus (https://manus.im)

**Environment Variables:** See `.env.example`

**Build:**
```bash
pnpm build
```

**Run Production:**
```bash
NODE_ENV=production pnpm start
```

**Database Migrations:**
```bash
pnpm db:push
```

---

## Resources

- **Three.js Docs:** https://threejs.org/docs/
- **React Docs:** https://react.dev/
- **tRPC Docs:** https://trpc.io/
- **Drizzle ORM:** https://orm.drizzle.team/
- **Tailwind CSS:** https://tailwindcss.com/
- **Manus Platform:** https://manus.im/

---

## Questions?

If you're modifying this codebase and have questions:
1. Check this architecture document first
2. Review existing code in similar areas
3. Run tests to verify your changes
4. Ask in code comments if behavior is non-obvious

Good luck! 🚀
