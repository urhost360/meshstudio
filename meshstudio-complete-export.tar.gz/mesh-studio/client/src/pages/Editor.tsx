import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useState, useCallback, useRef, useEffect } from "react";
import { useRoute } from "wouter";
import * as THREE from "three";
import ThreeViewport, { ViewportRef, TransformMode, EditMode } from "@/components/ThreeViewport";
import Toolbar from "@/components/Toolbar";
import SceneHierarchy from "@/components/SceneHierarchy";
import PropertiesPanel from "@/components/PropertiesPanel";
import MeshEditPanel from "@/components/MeshEditPanel";
import LightingPanel from "@/components/LightingPanel";
import ImportDialog from "@/components/ImportDialog";
import ExportDialog from "@/components/ExportDialog";
import ShareDialog from "@/components/ShareDialog";
import KeyboardHelpDialog from "@/components/KeyboardHelpDialog";
import BatchTransformPanel from "@/components/BatchTransformPanel";
import LassoSelector, { SelectionTool } from "@/components/LassoSelector";
import { VertexEditorManager } from "@/components/VertexEditor";
import { loadModelFromFile, loadModelFromUrl, getFormatFromFilename } from "@/lib/fileLoader";
import { exportModel, downloadBlob, ExportFormat, analyzeScene } from "@/lib/exporters";
import { mergeObjects, duplicateObject, batchDelete, batchTransform, getBatchCenter } from "@/lib/meshOps";
import { HistoryManager } from "@/lib/historyManager";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Layers, Settings2, Grid3x3, LogIn, Sun, Lasso, Square, Upload } from "lucide-react";

export default function Editor() {
  const { user, loading: authLoading } = useAuth();
  const [, params] = useRoute("/editor/:id");
  const projectId = params?.id ? parseInt(params.id) : null;

  const [viewportRef, setViewportRef] = useState<ViewportRef | null>(null);
  const [transformMode, setTransformMode] = useState<TransformMode>("translate");
  const [editMode, setEditMode] = useState<EditMode>("object");
  const [selectionTool, setSelectionTool] = useState<SelectionTool>("click");
  const [selectedObject, setSelectedObject] = useState<THREE.Object3D | null>(null);
  const [selectedObjects, setSelectedObjects] = useState<Set<THREE.Object3D>>(new Set());
  const [sceneObjects, setSceneObjects] = useState<THREE.Object3D[]>([]);
  const [importOpen, setImportOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [rightTab, setRightTab] = useState("properties");
  const [selectionCount, setSelectionCount] = useState(0);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  const vertexEditorRef = useRef<VertexEditorManager | null>(null);
  const historyRef = useRef<HistoryManager>(new HistoryManager(50));

  // Load project data
  const { data: project } = trpc.project.get.useQuery(
    { id: projectId! },
    { enabled: !!projectId && !!user }
  );

  const { data: projectAssets } = trpc.asset.listByProject.useQuery(
    { projectId: projectId! },
    { enabled: !!projectId && !!user }
  );

  const updateProject = trpc.project.update.useMutation({
    onSuccess: () => toast.success("Project saved"),
    onError: (e) => toast.error(e.message),
  });

  const uploadAsset = trpc.asset.upload.useMutation({
    onError: (e) => toast.error(e.message),
  });

  // Initialize vertex editor when viewport is ready
  const handleViewportReady = useCallback((ref: ViewportRef) => {
    setViewportRef(ref);
    vertexEditorRef.current = new VertexEditorManager(ref.scene);
  }, []);

  // Load project assets when they change
  useEffect(() => {
    if (!viewportRef || !projectAssets || projectAssets.length === 0) return;
    const existingNames = new Set(sceneObjects.map(o => o.userData.assetId));

    projectAssets.forEach(async (asset) => {
      if (existingNames.has(asset.id)) return;
      try {
        const format = asset.format as any;
        const model = await loadModelFromUrl(asset.fileUrl, format, asset.name);
        model.userData.assetId = asset.id;
        if (asset.metadata) {
          const meta = asset.metadata as any;
          if (meta.position) model.position.fromArray(meta.position);
          if (meta.rotation) model.rotation.fromArray(meta.rotation);
          if (meta.scale) model.scale.fromArray(meta.scale);
        }
        viewportRef.addObject(model);
        setSceneObjects(prev => [...prev, model]);
      } catch (e: any) {
        console.error("Failed to load asset:", asset.name, e);
      }
    });
  }, [projectAssets, viewportRef]);

  // Update vertex editor when edit mode or selection changes
  useEffect(() => {
    if (vertexEditorRef.current) {
      vertexEditorRef.current.showEditHelpers(selectedObject, editMode);
      setSelectionCount(0);
    }
  }, [selectedObject, editMode]);

  const handleObjectSelected = useCallback((obj: THREE.Object3D | null) => {
    setSelectedObject(obj);
  }, []);

  const handleTransformModeChange = useCallback((mode: TransformMode) => {
    setTransformMode(mode);
    viewportRef?.setTransformMode(mode);
  }, [viewportRef]);

  const handleEditModeChange = useCallback((mode: EditMode) => {
    setEditMode(mode);
    if (mode !== "object") {
      setRightTab("mesh");
      // Default to lasso tool when entering edit mode
      if (selectionTool === "click") setSelectionTool("lasso");
    } else {
      setSelectionTool("click");
    }
  }, [selectionTool]);

  const refreshSceneObjects = useCallback(() => {
    if (!viewportRef) return;
    const objs: THREE.Object3D[] = [];
    viewportRef.scene.children.forEach((child) => {
      if (child.name && !child.name.startsWith("__") && child.type !== "AmbientLight" && child.type !== "DirectionalLight") {
        objs.push(child);
      }
    });
    setSceneObjects(objs);
  }, [viewportRef]);

  // Lasso/box selection complete handler
  const handleSelectionComplete = useCallback((indices: Set<number>, mode: EditMode) => {
    if (!vertexEditorRef.current) return;
    vertexEditorRef.current.setSelection(indices, mode);
    setSelectionCount(indices.size);
    if (indices.size > 0) {
      toast.info(`Selected ${indices.size} ${mode === "vertex" ? "vertices" : mode === "face" ? "faces" : "edges"} — press Delete to remove`);
    }
  }, []);

  // Delete selected elements (vertices/faces from lasso)
  const handleDeleteSelected = useCallback(() => {
    if (!vertexEditorRef.current) return;
    const count = vertexEditorRef.current.getSelectionCount();
    if (count === 0) return;

    const success = vertexEditorRef.current.deleteSelected();
    if (success) {
      toast.success(`Deleted ${count} selected elements`);
      setSelectionCount(0);
      // Refresh the helpers
      vertexEditorRef.current.showEditHelpers(selectedObject, editMode);
      refreshSceneObjects();
    } else {
      toast.error("Delete failed — no elements to remove");
    }
  }, [selectedObject, editMode, refreshSceneObjects]);

  // File import
  const handleFilesSelected = useCallback(async (files: File[]) => {
    if (!viewportRef) return;
    setImporting(true);
    try {
      for (const file of files) {
        const model = await loadModelFromFile(file);
        viewportRef.addObject(model);

        if (projectId && user) {
          const format = getFormatFromFilename(file.name);
          if (format) {
            try {
              const arrayBuffer = await file.arrayBuffer();
              const bytes = new Uint8Array(arrayBuffer);
              let binary = "";
              for (let i = 0; i < bytes.byteLength; i++) {
                binary += String.fromCharCode(bytes[i]);
              }
              const base64 = btoa(binary);
              const asset = await uploadAsset.mutateAsync({
                projectId,
                name: file.name.replace(/\.[^.]+$/, ""),
                originalName: file.name,
                format,
                fileBase64: base64,
                fileSize: file.size,
              });
              if (asset) model.userData.assetId = asset.id;
            } catch (e: any) {
              console.error("Failed to upload asset:", e);
            }
          }
        }
      }
      refreshSceneObjects();
      setImportOpen(false);
      toast.success(`Imported ${files.length} file${files.length > 1 ? "s" : ""}`);
    } catch (e: any) {
      toast.error(e.message || "Import failed");
    } finally {
      setImporting(false);
    }
  }, [viewportRef, projectId, user, uploadAsset, refreshSceneObjects]);

  // Export
  const handleExport = useCallback(async (format: ExportFormat) => {
    if (!viewportRef) return;
    setExporting(true);
    try {
      const exportScene = new THREE.Scene();
      viewportRef.scene.children.forEach((child) => {
        if (child.name && !child.name.startsWith("__") && child.type !== "AmbientLight" && child.type !== "DirectionalLight") {
          exportScene.add(child.clone());
        }
      });

      const blob = await exportModel(
        format === "png" ? viewportRef.scene : exportScene,
        format,
        viewportRef.renderer,
        viewportRef.camera
      );
      const ext = format === "png" ? "png" : format;
      downloadBlob(blob, `meshstudio-export.${ext}`);
      setExportOpen(false);
      toast.success("Export complete");
    } catch (e: any) {
      toast.error(e.message || "Export failed");
    } finally {
      setExporting(false);
    }
  }, [viewportRef]);

  // Save project
  const handleSave = useCallback(async (silent = false) => {
    if (!projectId || !viewportRef || !user) {
      toast.error("Save your project first by creating one from the Projects page");
      return;
    }

    const sceneData: any = {
      objects: sceneObjects.map(obj => ({
        name: obj.userData.displayName || obj.name,
        assetId: obj.userData.assetId,
        position: obj.position.toArray(),
        rotation: [obj.rotation.x, obj.rotation.y, obj.rotation.z],
        scale: obj.scale.toArray(),
      })),
      camera: {
        position: viewportRef.camera.position.toArray(),
        target: viewportRef.orbitControls.target.toArray(),
      },
    };

    const thumbnailDataUrl = viewportRef.captureScreenshot();

    await updateProject.mutateAsync({
      id: projectId,
      sceneData,
      thumbnailUrl: thumbnailDataUrl,
    });
    
    if (!silent) {
      toast.success("Project saved");
    }
  }, [projectId, viewportRef, user, sceneObjects, updateProject]);

  // Auto-save every 30 seconds
  useEffect(() => {
    if (!projectId) return;
    
    const autoSaveTimer = setInterval(() => {
      handleSave(true); // Silent save
    }, 30000); // 30 seconds
    
    return () => clearInterval(autoSaveTimer);
  }, [projectId, handleSave]);

  // Object operations
  const handleDelete = useCallback(() => {
    // If in edit mode with selection, delete selected elements
    if (editMode !== "object" && selectionCount > 0) {
      handleDeleteSelected();
      // Save to history
      if (viewportRef) {
        historyRef.current.saveState(viewportRef.scene, "Delete selected vertices/faces");
      }
      return;
    }
    // Otherwise delete the whole object
    if (!selectedObject || !viewportRef) return;
    viewportRef.removeObject(selectedObject);
    refreshSceneObjects();
    // Save to history
    historyRef.current.saveState(viewportRef.scene, "Delete object");
    toast.success("Object deleted");
  }, [selectedObject, viewportRef, refreshSceneObjects, editMode, selectionCount, handleDeleteSelected]);

  const handleDuplicate = useCallback(() => {
    if (!selectedObject || !viewportRef) return;
    const clone = duplicateObject(selectedObject);
    viewportRef.addObject(clone);
    viewportRef.selectObject(clone);
    refreshSceneObjects();
    toast.success("Object duplicated");
  }, [selectedObject, viewportRef, refreshSceneObjects]);

  const handleUndo = useCallback(() => {
    const undoState = historyRef.current.undo();
    if (undoState && viewportRef) {
      HistoryManager.restoreScene(viewportRef.scene, undoState);
      refreshSceneObjects();
      toast.success("Undo: " + undoState.description);
    }
  }, [viewportRef, refreshSceneObjects]);

  const handleRedo = useCallback(() => {
    const redoState = historyRef.current.redo();
    if (redoState && viewportRef) {
      HistoryManager.restoreScene(viewportRef.scene, redoState);
      refreshSceneObjects();
      toast.success("Redo: " + redoState.description);
    }
  }, [viewportRef, refreshSceneObjects]);

  const canUndo = historyRef.current.canUndo();
  const canRedo = historyRef.current.canRedo();

  const handleMerge = useCallback(() => {
    if (!selectedObject || !viewportRef || sceneObjects.length < 2) {
      toast.error("Need at least 2 objects to merge");
      return;
    }
    try {
      const merged = mergeObjects(sceneObjects);
      sceneObjects.forEach(obj => viewportRef.removeObject(obj));
      viewportRef.addObject(merged);
      viewportRef.selectObject(merged);
      refreshSceneObjects();
      toast.success("Objects merged");
    } catch (e: any) {
      toast.error(e.message || "Merge failed");
    }
  }, [selectedObject, viewportRef, sceneObjects, refreshSceneObjects]);

  const handleToggleVisibility = useCallback((obj: THREE.Object3D) => {
    obj.visible = !obj.visible;
    refreshSceneObjects();
  }, [refreshSceneObjects]);

  // Handle multi-select with Ctrl+Click
  const handleObjectClick = useCallback((obj: THREE.Object3D | null, ctrlKey: boolean) => {
    if (ctrlKey && obj) {
      // Toggle object in selection set
      const newSelected = new Set(selectedObjects);
      if (newSelected.has(obj)) {
        newSelected.delete(obj);
      } else {
        newSelected.add(obj);
      }
      setSelectedObjects(newSelected);
      setSelectedObject(obj);
    } else {
      // Single select
      setSelectedObjects(new Set([obj || undefined].filter(Boolean) as THREE.Object3D[]));
      setSelectedObject(obj);
    }
  }, [selectedObjects]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      switch (e.key.toLowerCase()) {
        case "g": handleTransformModeChange("translate"); break;
        case "r": handleTransformModeChange("rotate"); break;
        case "s":
          if (e.ctrlKey || e.metaKey) { e.preventDefault(); handleSave(); }
          else handleTransformModeChange("scale");
          break;
        case "f": viewportRef?.focusSelected(); break;
        case "delete":
        case "backspace":
          e.preventDefault();
          handleDelete();
          break;
        case "i": setImportOpen(true); break;
        case "?":
          e.preventDefault();
          setHelpOpen(true);
          break;
        case "l":
          // Toggle lasso tool
          if (editMode !== "object") {
            setSelectionTool(prev => prev === "lasso" ? "click" : "lasso");
          }
          break;
        case "b":
          // Toggle box selection tool
          if (editMode !== "object") {
            setSelectionTool(prev => prev === "box" ? "click" : "box");
          }
          break;
        case "z":
          // Ctrl+Z for undo, Ctrl+Shift+Z for redo
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            if (e.shiftKey) {
              // Redo
              const redoState = historyRef.current.redo();
              if (redoState && viewportRef) {
                HistoryManager.restoreScene(viewportRef.scene, redoState);
                refreshSceneObjects();
                toast.success("Redo: " + redoState.description);
              }
            } else {
              // Undo
              const undoState = historyRef.current.undo();
              if (undoState && viewportRef) {
                HistoryManager.restoreScene(viewportRef.scene, undoState);
                refreshSceneObjects();
                toast.success("Undo: " + undoState.description);
              }
            }
          }
          break;
        case "y":
          // Ctrl+Y for redo
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            const redoState = historyRef.current.redo();
            if (redoState && viewportRef) {
              HistoryManager.restoreScene(viewportRef.scene, redoState);
              refreshSceneObjects();
              toast.success("Redo: " + redoState.description);
            }
          }
          break;
        case "escape":
          // Clear selection or exit edit mode
          if (selectionCount > 0 && vertexEditorRef.current) {
            vertexEditorRef.current.clearSelection();
            vertexEditorRef.current.refreshHelpers();
            setSelectionCount(0);
          } else if (editMode !== "object") {
            setEditMode("object");
            setSelectionTool("click");
          }
          break;
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleTransformModeChange, handleSave, handleDelete, viewportRef, selectedObject, editMode, selectionCount]);

  if (authLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <h2 className="text-xl font-semibold text-foreground">Sign in to use the editor</h2>
          <p className="text-sm text-muted-foreground">Create and edit 3D projects with MeshStudio</p>
          <Button onClick={() => { window.location.href = getLoginUrl(); }}>
            <LogIn className="h-4 w-4 mr-2" />
            Sign In
          </Button>
        </div>
      </div>
    );
  }


  // Handle drag-and-drop file import
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
    
    const files = Array.from(e.dataTransfer.files);
    const modelFiles = files.filter(f => 
      f.type === 'application/zip' || 
      f.name.endsWith('.zip') ||
      f.name.endsWith('.obj') ||
      f.name.endsWith('.gltf') ||
      f.name.endsWith('.glb') ||
      f.name.endsWith('.fbx')
    );
    
    if (modelFiles.length === 0) {
      toast.error("Please drop a model file (ZIP, OBJ, GLTF, GLB, or FBX)");
      return;
    }
    
    // Import all dropped files
    handleFilesSelected(modelFiles);
  };

    return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* Toolbar */}
      <Toolbar
        transformMode={transformMode}
        editMode={editMode}
        selectionTool={selectionTool}
        onTransformModeChange={handleTransformModeChange}
        onEditModeChange={handleEditModeChange}
        onSelectionToolChange={setSelectionTool}
        onFocusSelected={() => viewportRef?.focusSelected()}
        onResetCamera={() => viewportRef?.resetCamera()}
        onUpload={() => setImportOpen(true)}
        onSave={handleSave}
        onExport={() => setExportOpen(true)}
        onShare={() => setShareOpen(true)}
        hasSelection={!!selectedObject}
        onDelete={handleDelete}
        onDuplicate={handleDuplicate}
        onMerge={handleMerge}
        projectName={project?.name}
        selectionCount={selectionCount}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
      />

      {/* Main layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left panel - Scene hierarchy */}
        <div className="w-56 border-r border-border bg-card flex flex-col shrink-0">
          <SceneHierarchy
            objects={sceneObjects}
            selectedObject={selectedObject}
            onSelect={(obj) => viewportRef?.selectObject(obj)}
            onDelete={(obj) => { viewportRef?.removeObject(obj); refreshSceneObjects(); }}
            onToggleVisibility={handleToggleVisibility}
          />
        </div>

        {/* Center - 3D Viewport */}
        <div 
          className="flex-1 relative"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <ThreeViewport
            onReady={handleViewportReady}
            onObjectSelected={handleObjectSelected}
            editMode={editMode}
          />
          
          {/* Drag-and-drop overlay hint - only show when dragging file */}
          {isDraggingFile && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center bg-blue-500/10 border-2 border-dashed border-blue-400 rounded">
              <div className="text-center">
                <Upload className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                <p className="text-sm text-blue-300 font-medium">Drop model here to import</p>
              </div>
            </div>
          )}

          {/* Lasso/Box selection overlay */}
          <LassoSelector
            viewportRef={viewportRef}
            editMode={editMode}
            tool={selectionTool}
            onSelectionComplete={handleSelectionComplete}
            enabled={true}
          />

          {/* Viewport overlay info */}
          <div className="absolute bottom-3 left-3 flex items-center gap-3 text-[10px] text-muted-foreground font-mono">
            <span>Objects: {sceneObjects.length}</span>
            <span>Mode: {editMode}</span>
            <span>Transform: {transformMode}</span>
            {selectionCount > 0 && (
              <span className="text-orange-400 font-semibold">
                Selected: {selectionCount}
              </span>
            )}
          </div>

          {/* Edit mode indicator */}
          {editMode !== "object" && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 flex items-center gap-2">
              <div className="px-3 py-1 bg-primary/90 text-primary-foreground rounded-full text-xs font-medium">
                {editMode.charAt(0).toUpperCase() + editMode.slice(1)} Edit Mode
              </div>
              {selectionTool !== "click" && (
                <div className="px-2 py-1 bg-orange-500/90 text-white rounded-full text-[10px] font-medium flex items-center gap-1">
                  {selectionTool === "lasso" ? <Lasso className="h-3 w-3" /> : <Square className="h-3 w-3" />}
                  {selectionTool === "lasso" ? "Lasso" : "Box"} Select
                </div>
              )}
            </div>
          )}

          {/* Selection action bar */}
          {selectionCount > 0 && editMode !== "object" && (
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-card/95 backdrop-blur border border-border rounded-lg px-3 py-2 shadow-lg">
              <span className="text-xs text-orange-400 font-medium">{selectionCount} selected</span>
              <Button
                size="sm"
                variant="destructive"
                className="h-6 px-2 text-[10px]"
                onClick={handleDeleteSelected}
              >
                Delete (Del)
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="h-6 px-2 text-[10px] border-border"
                onClick={() => {
                  if (vertexEditorRef.current) {
                    vertexEditorRef.current.clearSelection();
                    vertexEditorRef.current.refreshHelpers();
                    setSelectionCount(0);
                  }
                }}
              >
                Clear (Esc)
              </Button>
            </div>
          )}
        </div>

        {/* Right panel - Properties / Mesh / Lighting */}
        <div className="w-64 border-l border-border bg-card flex flex-col shrink-0">
          <Tabs value={rightTab} onValueChange={setRightTab} className="flex flex-col h-full">
            <TabsList className="h-9 w-full rounded-none border-b border-border bg-transparent justify-start px-1 shrink-0">
              <TabsTrigger value="properties" className="text-xs h-7 data-[state=active]:bg-accent">
                <Settings2 className="h-3 w-3 mr-1" />
                Properties
              </TabsTrigger>
              <TabsTrigger value="mesh" className="text-xs h-7 data-[state=active]:bg-accent">
                <Grid3x3 className="h-3 w-3 mr-1" />
                Mesh
              </TabsTrigger>
              <TabsTrigger value="lighting" className="text-xs h-7 data-[state=active]:bg-accent">
                <Sun className="h-3 w-3 mr-1" />
                Light
              </TabsTrigger>
            </TabsList>
            <TabsContent value="properties" className="flex-1 mt-0 overflow-hidden">
              <PropertiesPanel
                selectedObject={selectedObject}
                onPropertyChange={refreshSceneObjects}
              />
            </TabsContent>
            <TabsContent value="mesh" className="flex-1 mt-0 overflow-hidden">
              <MeshEditPanel
                selectedObject={selectedObject}
                onMeshModified={refreshSceneObjects}
              />
            </TabsContent>
            <TabsContent value="lighting" className="flex-1 mt-0 overflow-hidden">
              <LightingPanel viewportRef={viewportRef} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Dialogs */}
      <ImportDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        onFilesSelected={handleFilesSelected}
        loading={importing}
      />
      <ExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        onExport={handleExport}
        loading={exporting}
        hasObjects={sceneObjects.length > 0}
        sceneStats={exportOpen && viewportRef ? analyzeScene(viewportRef.scene) : null}
      />
      <ShareDialog
        open={shareOpen}
        onOpenChange={setShareOpen}
        projectId={projectId}
        thumbnailUrl={project?.thumbnailUrl}
      />
    </div>
  );
}
