import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import {
  Box, Upload, Combine, Share2, Layers, Palette,
  Move, Download, ArrowRight, LogIn, ChevronRight, Hexagon
} from "lucide-react";

export default function Home() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  const features = [
    { icon: Upload, title: "Import 3D Files", desc: "Upload OBJ, STL, FBX, GLTF, and GLB files with drag & drop" },
    { icon: Move, title: "Transform Tools", desc: "Move, rotate, and scale objects with precision gizmos" },
    { icon: Layers, title: "Polygon Editing", desc: "Edit vertices, faces, and edges with subdivision and decimation" },
    { icon: Combine, title: "Combine Assets", desc: "Merge multiple 3D models into a single unified scene" },
    { icon: Palette, title: "Material Editor", desc: "Adjust colors, metalness, roughness, opacity, and more" },
    { icon: Share2, title: "Share & Export", desc: "Generate shareable links and export in multiple formats" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Hexagon className="h-4.5 w-4.5 text-primary" />
            </div>
            <span className="font-semibold text-foreground tracking-tight">MeshStudio</span>
          </div>
          <div className="flex items-center gap-3">
            {loading ? null : user ? (
              <>
                <Button variant="ghost" size="sm" onClick={() => setLocation("/projects")} className="text-muted-foreground hover:text-foreground">
                  My Projects
                </Button>
                <Button size="sm" onClick={() => setLocation("/projects")}>
                  Open Editor
                  <ArrowRight className="h-3.5 w-3.5 ml-1.5" />
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={() => { window.location.href = getLoginUrl(); }}>
                <LogIn className="h-3.5 w-3.5 mr-1.5" />
                Sign In
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
        <div className="max-w-6xl mx-auto px-6 pt-20 pb-16 relative">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-6">
              <Box className="h-3 w-3" />
              Web-based 3D Editor
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-foreground leading-tight tracking-tight">
              Edit, combine, and share
              <span className="text-primary"> 3D assets</span> in your browser
            </h1>
            <p className="text-lg text-muted-foreground mt-5 leading-relaxed max-w-xl">
              A powerful 3D modeling workspace. Upload your models, edit polygons, combine assets, and share your work with anyone through a simple link.
            </p>
            <div className="flex items-center gap-3 mt-8">
              {user ? (
                <>
                  <Button size="lg" onClick={() => setLocation("/projects")}>
                    Go to Projects
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                  <Button size="lg" variant="outline" onClick={() => setLocation("/editor/new")} className="border-border">
                    Quick Start
                  </Button>
                </>
              ) : (
                <Button size="lg" onClick={() => { window.location.href = getLoginUrl(); }}>
                  Get Started
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 border-t border-border">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-foreground">Everything you need for 3D editing</h2>
            <p className="text-muted-foreground mt-2">Professional tools, right in your browser</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => (
              <div
                key={i}
                className="group p-5 rounded-xl border border-border bg-card hover:border-primary/30 hover:bg-card/80 transition-all"
              >
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
                  <f.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-sm font-semibold text-foreground">{f.title}</h3>
                <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Supported formats */}
      <section className="py-16 border-t border-border bg-card/50">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <h2 className="text-2xl font-bold text-foreground mb-3">Supported Formats</h2>
          <p className="text-muted-foreground mb-8">Import and export in popular 3D file formats</p>
          <div className="flex flex-wrap justify-center gap-3">
            {["OBJ", "STL", "FBX", "GLTF", "GLB"].map((fmt) => (
              <div key={fmt} className="px-5 py-2.5 rounded-lg bg-secondary border border-border">
                <span className="text-sm font-mono font-medium text-foreground">.{fmt.toLowerCase()}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Hexagon className="h-4 w-4 text-primary" />
            <span className="text-sm text-muted-foreground">MeshStudio</span>
          </div>
          <p className="text-xs text-muted-foreground">Built with Three.js</p>
        </div>
      </footer>
    </div>
  );
}
