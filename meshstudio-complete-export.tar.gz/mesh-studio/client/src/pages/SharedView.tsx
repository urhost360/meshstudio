import { useEffect, useState, useRef, useCallback } from "react";
import { useRoute } from "wouter";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { loadModelFromUrl } from "@/lib/fileLoader";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Box, Loader2, AlertCircle, RotateCw, Lock, Send, MessageSquare,
  User, Trash2, Smartphone, X, Cuboid, ExternalLink
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";



export default function SharedView() {
  const [, params] = useRoute("/view/:token");
  const token = params?.token ?? "";
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const [loadingModels, setLoadingModels] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [submittedPassword, setSubmittedPassword] = useState<string | undefined>(undefined);
  const [showComments, setShowComments] = useState(false);
  const [commentName, setCommentName] = useState("");
  const [commentText, setCommentText] = useState("");

  // AR state - show Three.js viewport first, then AR mode
  const [arMode, setArMode] = useState(false); // Start with Three.js viewport
  const [arGlbUrl, setArGlbUrl] = useState<string | null>(null);
  const [generatingAr, setGeneratingAr] = useState(false);
  const [modelViewerLoaded, setModelViewerLoaded] = useState(false);
  const [showQrPopup, setShowQrPopup] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);

  const { user } = useAuth();

  const { data, isLoading, error: queryError, refetch } = trpc.share.getByToken.useQuery(
    { token, password: submittedPassword },
    { enabled: !!token }
  );

  const sharedLinkId = data?.link?.id;

  const { data: commentsData, refetch: refetchComments } = trpc.comment.listByLink.useQuery(
    { sharedLinkId: sharedLinkId! },
    { enabled: !!sharedLinkId && data?.commentsEnabled === true }
  );

  const addComment = trpc.comment.add.useMutation({
    onSuccess: () => {
      refetchComments();
      setCommentText("");
      toast.success("Comment posted");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteComment = trpc.comment.delete.useMutation({
    onSuccess: () => {
      refetchComments();
      toast.success("Comment deleted");
    },
    onError: (e: any) => toast.error(e.message),
  });

  // Update meta tags for social media preview
  useEffect(() => {
    if (data && data.project) {
      const projectName = data.project.name || "3D Model";
      const description = data.project.description || "View this 3D model in your browser";
      const thumbnailUrl = data.project.thumbnailUrl || "";
      const currentUrl = window.location.href;

      document.getElementById("page-title")!.textContent = projectName + " - MeshStudio";
      const metaDesc = document.getElementById("meta-description") as HTMLMetaElement;
      if (metaDesc) metaDesc.content = description;
      const ogTitle = document.getElementById("og-title") as HTMLMetaElement;
      if (ogTitle) ogTitle.content = projectName;
      const ogDesc = document.getElementById("og-description") as HTMLMetaElement;
      if (ogDesc) ogDesc.content = description;
      const ogImage = document.getElementById("og-image") as HTMLMetaElement;
      if (ogImage && thumbnailUrl) ogImage.content = thumbnailUrl;
      const ogUrl = document.getElementById("og-url") as HTMLMetaElement;
      if (ogUrl) ogUrl.content = currentUrl;
    }
  }, [data]);

  // Load model-viewer web component
  useEffect(() => {
    if (modelViewerLoaded) return;
    const script = document.createElement("script");
    script.type = "module";
    script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js";
    script.onload = () => setModelViewerLoaded(true);
    document.head.appendChild(script);
    // Also set loaded after a timeout in case onload doesn't fire
    const timer = setTimeout(() => setModelViewerLoaded(true), 3000);
    return () => clearTimeout(timer);
  }, [modelViewerLoaded]);



  // Build the Three.js viewport
  useEffect(() => {
    if (!containerRef.current || !data || data.error || !data.project || !data.assets) return;
    if (arMode) return; // Don't render Three.js when in AR mode
    const container = containerRef.current;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 10000);
    camera.position.set(5, 4, 5);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Grid and lights for realistic preview room
    scene.add(new THREE.GridHelper(20, 20, 0x444466, 0x2a2a3e));
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(8, 12, 8);
    scene.add(dirLight);
    const fillLight = new THREE.DirectionalLight(0x8888ff, 0.3);
    fillLight.position.set(-5, 3, -5);
    scene.add(fillLight);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;

    const loadAssets = async () => {
      setLoadingModels(true);
      try {
        for (const asset of data.assets!) {
          try {
            const model = await loadModelFromUrl(asset.fileUrl, asset.format as any, asset.name);
            if (asset.metadata) {
              const meta = asset.metadata as any;
              if (meta.position) model.position.fromArray(meta.position);
              if (meta.rotation) model.rotation.fromArray(meta.rotation);
              if (meta.scale) model.scale.fromArray(meta.scale);
            }
            scene.add(model);
          } catch (e) {
            console.error("Failed to load asset:", asset.name, e);
          }
        }
        if (data.project!.sceneData) {
          const sd = data.project!.sceneData as any;
          if (sd.camera?.position) camera.position.fromArray(sd.camera.position);
          if (sd.camera?.target) controls.target.fromArray(sd.camera.target);
        }
      } catch (e: any) {
        setError(e.message);
      } finally {
        setLoadingModels(false);
      }
    };
    loadAssets();

    let animFrame: number;;
    const animate = () => {
      animFrame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animFrame);
      resizeObserver.disconnect();
      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      sceneRef.current = null;
    };
  }, [data, arMode]);

  // Generate GLB from the loaded scene for AR viewing
  const generateArGlb = useCallback(async (): Promise<string | null> => {
    if (arGlbUrl) return arGlbUrl;

    const scene = sceneRef.current;
    if (!scene) {
      // Scene not ready yet, will retry
      return null;
    }

    setGeneratingAr(true);
    try {
      // Create a clean scene with just the meshes (no grid/helpers)
      const exportScene = new THREE.Scene();
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
      exportScene.add(ambientLight);
      const keyLight = new THREE.DirectionalLight(0xffffff, 1.0);
      keyLight.position.set(5, 8, 5);
      exportScene.add(keyLight);

      scene.traverse((child) => {
        if ((child as any).isMesh) {
          const clone = child.clone();
          exportScene.add(clone);
        }
      });

      const exporter = new GLTFExporter();
      const glbBuffer = await new Promise<ArrayBuffer>((resolve, reject) => {
        exporter.parse(
          exportScene,
          (result) => resolve(result as ArrayBuffer),
          reject,
          { binary: true }
        );
      });

      const blob = new Blob([glbBuffer], { type: "model/gltf-binary" });
      const blobUrl = URL.createObjectURL(blob);
      setArGlbUrl(blobUrl);
      return blobUrl;
    } catch (e: any) {
      console.error("AR export failed:", e);
      toast.error("Failed to generate AR model: " + e.message);
      return null;
    } finally {
      setGeneratingAr(false);
    }
  }, [arGlbUrl]);

  // Auto-generate AR GLB once scene is loaded
  useEffect(() => {
    if (!loadingModels && sceneRef.current && !arGlbUrl && !generatingAr) {
      const timer = setTimeout(() => {
        generateArGlb().then(url => {
          if (url) {
            setArMode(true);
          }
        });
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [loadingModels, arGlbUrl, generatingAr, generateArGlb]);

  // Open AR file directly on the user's device
  const handleOpenArFile = useCallback(async () => {
    const url = await generateArGlb();
    if (!url) return;

    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAndroid = /Android/.test(navigator.userAgent);
    const isMobile = isIOS || isAndroid;

    if (isMobile) {
      // Mobile: Go directly to AR mode
      setArMode(true);
      if (isIOS) {
        // iOS: Try to activate AR Quick Look
        setTimeout(() => {
          const modelViewerEl = document.querySelector("model-viewer") as any;
          if (modelViewerEl && modelViewerEl.activateAR) {
            modelViewerEl.activateAR();
          }
        }, 1000);
      } else if (isAndroid) {
        // Android: Try to activate Scene Viewer
        setTimeout(() => {
          const modelViewerEl = document.querySelector("model-viewer") as any;
          if (modelViewerEl && modelViewerEl.activateAR) {
            modelViewerEl.activateAR();
          }
        }, 1000);
      }
      toast.success("AR mode activated! Tap Place in Your Space to position the model on your table.");
    } else {
      // Desktop: Show QR code popup for scanning on mobile
      try {
        // Generate QR code URL using qrserver.com
        const arUrl = window.location.href;
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(arUrl)}`;
        setQrCodeUrl(qrUrl);
        setShowQrPopup(true);
      } catch (e) {
        toast.error("Failed to generate QR code");
      }
    }
  }, [generateArGlb]);

  // Loading state
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Password required
  if (data?.error === "password_required" || data?.error === "wrong_password") {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4 max-w-sm mx-auto p-6">
          <div className="h-16 w-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
            <Lock className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-lg font-semibold text-foreground">Password Protected</h2>
          <p className="text-sm text-muted-foreground">This shared project requires a password to view.</p>
          {data?.error === "wrong_password" && (
            <p className="text-sm text-destructive">Incorrect password. Please try again.</p>
          )}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSubmittedPassword(password);
              setTimeout(() => refetch(), 100);
            }}
            className="space-y-3"
          >
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              className="bg-secondary border-border"
            />
            <Button type="submit" className="w-full" disabled={!password}>
              <Lock className="h-4 w-4 mr-1.5" />
              Unlock
            </Button>
          </form>
        </div>
      </div>
    );
  }

  // Not found / error
  if (queryError || !data || data.error) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-3">
          <AlertCircle className="h-10 w-10 mx-auto text-destructive" />
          <h2 className="text-lg font-semibold text-foreground">Link not found</h2>
        </div>
      </div>
    );
  }

  const handleAddComment = () => {
    if (!sharedLinkId || !commentText.trim()) return;
    const authorName = user?.name || commentName.trim() || "Anonymous";
    addComment.mutate({
      sharedLinkId,
      authorName,
      content: commentText.trim(),
    });
  };

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-background overflow-hidden" style={{ touchAction: 'none', position: 'fixed' }}>
      {/* Header */}
      <div className="h-12 px-4 flex items-center justify-between bg-card border-b border-border shrink-0">
        <div className="flex items-center gap-2">
          <Box className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-foreground">{data.project?.name}</span>
          <span className="text-xs text-muted-foreground">· Shared View</span>
        </div>
        <div className="flex items-center gap-2">
          {/* No buttons needed - always in AR mode */}

          {data.commentsEnabled && (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={() => setShowComments(!showComments)}
            >
              <MessageSquare className="h-3.5 w-3.5" />
              {commentsData ? `${commentsData.length}` : ""}
            </Button>
          )}
          <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground">
            <RotateCw className="h-3 w-3" />
            <span>Orbit · Pan · Zoom</span>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Three.js Viewport - shown while loading and before AR mode */}
        {!arMode && (
          <div className="flex-1 relative" ref={containerRef} />
        )}

        {/* AR Mode - model-viewer */}
        {arMode && arGlbUrl && (
          <div className="flex-1 relative bg-gradient-to-b from-slate-900 to-slate-800">
            <model-viewer
              src={arGlbUrl}
              alt={data.project?.name || "3D Model"}
              ar
              ar-modes="webxr scene-viewer quick-look"
              ar-scale="auto"
              ar-placement="floor"
              xr-environment
              camera-controls
              auto-rotate
              shadow-intensity="1"
              exposure="1"
              touch-action="pan-y"
              interaction-prompt="auto"
              style={{
                width: "100%",
                height: "100%",
                backgroundColor: "transparent",
                "--poster-color": "transparent",
              } as any}
            >
              {/* AR button slot */}
              <button
                slot="ar-button"
                style={{
                  position: "absolute",
                  bottom: "20px",
                  left: "50%",
                  transform: "translateX(-50%)",
                  background: "linear-gradient(135deg, #059669, #14b8a6)",
                  color: "white",
                  border: "none",
                  borderRadius: "9999px",
                  padding: "14px 32px",
                  fontSize: "15px",
                  fontWeight: "600",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  boxShadow: "0 8px 32px rgba(5, 150, 105, 0.4), 0 0 0 1px rgba(255,255,255,0.1)",
                  zIndex: 40,
                  letterSpacing: "0.01em",
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                  <path d="M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12z" />
                  <path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
                </svg>
                Place in Your Space
              </button>

              {/* Loading indicator */}
              <div slot="progress-bar" style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                width: "100%",
                height: "4px",
                background: "linear-gradient(90deg, #059669, #14b8a6)",
              }} />
            </model-viewer>

            {/* AR Instructions Overlay */}
            <div className="absolute top-4 left-4 right-4 pointer-events-none">
              <div className="bg-black/60 backdrop-blur-md rounded-xl p-4 max-w-md mx-auto border border-white/10">
                <div className="flex items-start gap-3">
                  <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shrink-0">
                    <Smartphone className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">AR View Ready</h3>
                    <p className="text-xs text-white/70 mt-0.5 leading-relaxed">
                      Tap <strong>Place in Your Space</strong> to view this model in augmented reality.
                      Move your phone around to position the model on your table or floor.
                    </p>

                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Standard 3D Viewport */}
        {!arMode && (
          <div ref={containerRef} className="flex-1 relative viewport-canvas">
            {loadingModels && (
              <div className="absolute inset-0 flex items-center justify-center bg-background z-50 backdrop-blur-sm">
                <div className="text-center space-y-4">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">Loading 3D Model</p>
                    <p className="text-xs text-muted-foreground mt-1">Preparing your model for AR...</p>
                  </div>
                </div>
              </div>
            )}

            {/* AR button - always visible */}
            {!loadingModels && (
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 px-4">
                <Button
                  size="lg"
                  className="rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-xl shadow-emerald-500/30 gap-2 px-6"
                  onClick={handleOpenArFile}
                  disabled={generatingAr}
                >
                  {generatingAr ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <ExternalLink className="h-4 w-4" />
                  )}
                  {generatingAr ? "Preparing..." : "View in AR"}
                </Button>
              </div>
            )}
          </div>
        )}

        {/* QR Code Popup for Desktop Users */}
        {showQrPopup && qrCodeUrl && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-card rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl border border-border">
              <div className="text-center space-y-4">
                <div className="h-12 w-12 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center mx-auto">
                  <Smartphone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground">View in AR</h3>
                  <p className="text-sm text-muted-foreground mt-1">Scan this QR code with your phone to view the 3D model in augmented reality</p>
                </div>
                <div className="bg-white p-4 rounded-lg flex items-center justify-center">
                  <img src={qrCodeUrl} alt="AR QR Code" className="w-64 h-64" />
                </div>
                <div className="pt-2 space-y-2">
                  <p className="text-xs text-muted-foreground">Or open this link on your phone:</p>
                  <p className="text-xs font-mono text-foreground bg-secondary/50 p-2 rounded break-all">{window.location.href}</p>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowQrPopup(false)}
                >
                  <X className="h-4 w-4 mr-2" />
                  Close
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Comments Panel */}
        {showComments && data.commentsEnabled && (
          <div className="w-80 bg-card border-l border-border flex flex-col shrink-0">
            <div className="p-3 border-b border-border flex items-center justify-between">
              <h3 className="text-sm font-medium text-foreground flex items-center gap-1.5">
                <MessageSquare className="h-4 w-4 text-primary" />
                Comments
              </h3>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setShowComments(false)}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>

            <ScrollArea className="flex-1 p-3">
              <div className="space-y-3">
                {commentsData && commentsData.length > 0 ? (
                  commentsData.map((comment) => (
                    <div key={comment.id} className="bg-secondary/50 rounded-lg p-2.5 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center">
                            <User className="h-3 w-3 text-primary" />
                          </div>
                          <span className="text-xs font-medium text-foreground">{comment.authorName}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] text-muted-foreground">{formatDate(comment.createdAt)}</span>
                          {user && comment.userId === user.id && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-5 w-5 p-0 text-muted-foreground hover:text-destructive"
                              onClick={() => deleteComment.mutate({ id: comment.id })}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{comment.content}</p>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <MessageSquare className="h-6 w-6 mx-auto text-muted-foreground/30 mb-2" />
                    <p className="text-xs text-muted-foreground">No comments yet</p>
                    <p className="text-[10px] text-muted-foreground/60">Be the first to leave feedback</p>
                  </div>
                )}
              </div>
            </ScrollArea>

            <div className="p-3 border-t border-border space-y-2">
              {!user && (
                <Input
                  value={commentName}
                  onChange={(e) => setCommentName(e.target.value)}
                  placeholder="Your name (optional)"
                  className="h-7 text-xs bg-secondary border-border"
                />
              )}
              <div className="flex gap-1.5">
                <Input
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Add a comment..."
                  className="h-8 text-xs bg-secondary border-border flex-1"
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleAddComment(); } }}
                />
                <Button
                  size="sm"
                  className="h-8 w-8 p-0 shrink-0"
                  onClick={handleAddComment}
                  disabled={!commentText.trim() || addComment.isPending}
                >
                  <Send className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
