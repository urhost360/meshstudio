import "react";

declare module "react" {
  namespace JSX {
    interface IntrinsicElements {
      "model-viewer": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement> & {
          src?: string;
          "ios-src"?: string;
          alt?: string;
          ar?: boolean | string;
          "ar-modes"?: string;
          "ar-scale"?: string;
          "camera-controls"?: boolean | string;
          "auto-rotate"?: boolean | string;
          "shadow-intensity"?: string;
          "environment-image"?: string;
          exposure?: string;
          "touch-action"?: string;
          poster?: string;
          loading?: string;
          "camera-orbit"?: string;
          "interaction-prompt"?: string;
        },
        HTMLElement
      >;
    }
  }
}
