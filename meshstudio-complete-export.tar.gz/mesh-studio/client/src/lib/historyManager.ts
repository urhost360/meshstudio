import * as THREE from "three";

export interface HistoryState {
  timestamp: number;
  description: string;
  sceneSnapshot: {
    objects: Array<{
      uuid: string;
      name: string;
      position: [number, number, number];
      rotation: [number, number, number];
      scale: [number, number, number];
      geometry?: {
        positions: number[];
        indices: number[];
      };
      material?: {
        color: string;
        metalness: number;
        roughness: number;
        opacity: number;
        wireframe: boolean;
      };
    }>;
  };
}

export class HistoryManager {
  private history: HistoryState[] = [];
  private currentIndex: number = -1;
  private maxStates: number = 50;

  constructor(maxStates: number = 50) {
    this.maxStates = maxStates;
  }

  /**
   * Save current scene state to history
   */
  saveState(scene: THREE.Scene, description: string): void {
    // Remove any states after current index (for branching history)
    this.history = this.history.slice(0, this.currentIndex + 1);

    const state: HistoryState = {
      timestamp: Date.now(),
      description,
      sceneSnapshot: this.captureScene(scene),
    };

    this.history.push(state);
    this.currentIndex++;

    // Limit history size
    if (this.history.length > this.maxStates) {
      this.history.shift();
      this.currentIndex--;
    }
  }

  /**
   * Undo to previous state
   */
  undo(): HistoryState | null {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      return this.history[this.currentIndex];
    }
    return null;
  }

  /**
   * Redo to next state
   */
  redo(): HistoryState | null {
    if (this.currentIndex < this.history.length - 1) {
      this.currentIndex++;
      return this.history[this.currentIndex];
    }
    return null;
  }

  /**
   * Get current state
   */
  getCurrentState(): HistoryState | null {
    if (this.currentIndex >= 0 && this.currentIndex < this.history.length) {
      return this.history[this.currentIndex];
    }
    return null;
  }

  /**
   * Check if undo is available
   */
  canUndo(): boolean {
    return this.currentIndex > 0;
  }

  /**
   * Check if redo is available
   */
  canRedo(): boolean {
    return this.currentIndex < this.history.length - 1;
  }

  /**
   * Clear history
   */
  clear(): void {
    this.history = [];
    this.currentIndex = -1;
  }

  /**
   * Get history size
   */
  getSize(): number {
    return this.history.length;
  }

  /**
   * Capture scene state
   */
  private captureScene(scene: THREE.Scene): HistoryState["sceneSnapshot"] {
    const objects: HistoryState["sceneSnapshot"]["objects"] = [];

    scene.traverse((child) => {
      if (
        child.name &&
        !child.name.startsWith("__") &&
        child.type !== "AmbientLight" &&
        child.type !== "DirectionalLight" &&
        child.type !== "GridHelper"
      ) {
        const obj: HistoryState["sceneSnapshot"]["objects"][0] = {
          uuid: child.uuid,
          name: child.name,
          position: child.position.toArray() as [number, number, number],
          rotation: child.rotation.toArray().slice(0, 3) as [number, number, number],
          scale: child.scale.toArray() as [number, number, number],
        };

        // Capture geometry if it's a mesh
        if ((child as any).isMesh) {
          const mesh = child as THREE.Mesh;
          if (mesh.geometry) {
            const posAttr = mesh.geometry.getAttribute("position");
            const indexAttr = mesh.geometry.getIndex();
            if (posAttr) {
              obj.geometry = {
                positions: Array.from(posAttr.array as ArrayLike<number>),
                indices: indexAttr
                  ? Array.from(indexAttr.array as ArrayLike<number>)
                  : [],
              };
            }
          }

          // Capture material
          if (mesh.material && (mesh.material as any).isMaterial) {
            const mat = mesh.material as THREE.MeshStandardMaterial;
            obj.material = {
              color: mat.color?.getHexString() ?? "#ffffff",
              metalness: mat.metalness ?? 0,
              roughness: mat.roughness ?? 0.5,
              opacity: mat.opacity ?? 1,
              wireframe: mat.wireframe ?? false,
            };
          }
        }

        objects.push(obj);
      }
    });

    return { objects };
  }

  /**
   * Restore scene from state
   */
  static restoreScene(scene: THREE.Scene, state: HistoryState): void {
    // Create a map of current objects by UUID
    const currentObjects = new Map<string, THREE.Object3D>();
    scene.traverse((child) => {
      if (child.uuid) {
        currentObjects.set(child.uuid, child);
      }
    });

    // Update or create objects from snapshot
    state.sceneSnapshot.objects.forEach((objData) => {
      let obj = currentObjects.get(objData.uuid);

      if (!obj) {
        // Create new mesh if it doesn't exist
        const geometry = new THREE.BufferGeometry();
        if (objData.geometry) {
          geometry.setAttribute(
            "position",
            new THREE.BufferAttribute(new Float32Array(objData.geometry.positions), 3)
          );
          if (objData.geometry.indices.length > 0) {
            geometry.setIndex(
              new THREE.BufferAttribute(new Uint32Array(objData.geometry.indices), 1)
            );
          }
          geometry.computeVertexNormals();
        }

        const material = new THREE.MeshStandardMaterial();
        if (objData.material) {
          material.color.setHex(parseInt(objData.material.color.replace("#", ""), 16));
          material.metalness = objData.material.metalness;
          material.roughness = objData.material.roughness;
          material.opacity = objData.material.opacity;
          material.wireframe = objData.material.wireframe;
          material.transparent = objData.material.opacity < 1;
        }

        obj = new THREE.Mesh(geometry, material);
        obj.uuid = objData.uuid;
        obj.name = objData.name;
        scene.add(obj);
      } else if ((obj as any).isMesh && objData.geometry) {
        // Update existing mesh geometry
        const mesh = obj as THREE.Mesh;
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute(
          "position",
          new THREE.BufferAttribute(new Float32Array(objData.geometry.positions), 3)
        );
        if (objData.geometry.indices.length > 0) {
          geometry.setIndex(
            new THREE.BufferAttribute(new Uint32Array(objData.geometry.indices), 1)
          );
        }
        geometry.computeVertexNormals();
        mesh.geometry.dispose();
        mesh.geometry = geometry;
      }

      // Update transforms
      obj.position.fromArray(objData.position);
      obj.rotation.fromArray(objData.rotation);
      obj.scale.fromArray(objData.scale);

      // Update material
      if ((obj as any).isMesh && objData.material) {
        const mesh = obj as THREE.Mesh;
        if (mesh.material && (mesh.material as any).isMaterial) {
          const mat = mesh.material as THREE.MeshStandardMaterial;
          mat.color.setHex(parseInt(objData.material.color.replace("#", ""), 16));
          mat.metalness = objData.material.metalness;
          mat.roughness = objData.material.roughness;
          mat.opacity = objData.material.opacity;
          mat.wireframe = objData.material.wireframe;
          mat.transparent = objData.material.opacity < 1;
        }
      }
    });
  }
}
