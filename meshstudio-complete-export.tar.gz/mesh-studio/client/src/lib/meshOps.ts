import * as THREE from "three";

/**
 * Merge multiple meshes from different objects into a single mesh.
 * Returns a new THREE.Group containing the merged mesh.
 */
export function mergeObjects(objects: THREE.Object3D[]): THREE.Group {
  const geometries: THREE.BufferGeometry[] = [];

  for (const obj of objects) {
    obj.traverse((child) => {
      if ((child as any).isMesh) {
        const mesh = child as THREE.Mesh;
        const geo = mesh.geometry.clone();
        // Apply world transform to geometry
        geo.applyMatrix4(mesh.matrixWorld);
        geometries.push(geo);
      }
    });
  }

  if (geometries.length === 0) {
    throw new Error("No meshes found to merge");
  }

  // Merge all geometries
  const merged = mergeBufferGeometries(geometries);
  merged.computeVertexNormals();

  const material = new THREE.MeshStandardMaterial({
    color: 0x8888cc,
    metalness: 0.3,
    roughness: 0.6,
  });

  const mesh = new THREE.Mesh(merged, material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;

  const group = new THREE.Group();
  group.name = "Merged";
  group.userData.displayName = "Merged Object";
  group.add(mesh);

  return group;
}

/**
 * Simple buffer geometry merge (concatenate vertex data)
 */
function mergeBufferGeometries(geometries: THREE.BufferGeometry[]): THREE.BufferGeometry {
  let totalVertices = 0;
  let totalIndices = 0;
  const hasIndex = geometries.every(g => g.index !== null);

  for (const geo of geometries) {
    totalVertices += geo.attributes.position.count;
    if (geo.index) totalIndices += geo.index.count;
  }

  const positions = new Float32Array(totalVertices * 3);
  const normals = new Float32Array(totalVertices * 3);
  let indices: Uint32Array | null = hasIndex ? new Uint32Array(totalIndices) : null;

  let vertexOffset = 0;
  let indexOffset = 0;

  for (const geo of geometries) {
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      positions[(vertexOffset + i) * 3] = pos.getX(i);
      positions[(vertexOffset + i) * 3 + 1] = pos.getY(i);
      positions[(vertexOffset + i) * 3 + 2] = pos.getZ(i);
    }

    if (geo.attributes.normal) {
      const norm = geo.attributes.normal;
      for (let i = 0; i < norm.count; i++) {
        normals[(vertexOffset + i) * 3] = norm.getX(i);
        normals[(vertexOffset + i) * 3 + 1] = norm.getY(i);
        normals[(vertexOffset + i) * 3 + 2] = norm.getZ(i);
      }
    }

    if (indices && geo.index) {
      for (let i = 0; i < geo.index.count; i++) {
        indices[indexOffset + i] = geo.index.getX(i) + vertexOffset;
      }
      indexOffset += geo.index.count;
    }

    vertexOffset += pos.count;
  }

  const merged = new THREE.BufferGeometry();
  merged.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  merged.setAttribute("normal", new THREE.BufferAttribute(normals, 3));
  if (indices) merged.setIndex(new THREE.BufferAttribute(indices, 1));

  return merged;
}

/**
 * Duplicate a Three.js object (deep clone)
 */
export function duplicateObject(obj: THREE.Object3D): THREE.Object3D {
  const clone = obj.clone(true);
  clone.name = obj.name + "_copy";
  clone.userData = { ...obj.userData, displayName: (obj.userData.displayName || obj.name) + " (Copy)" };
  // Offset slightly so it's visible
  clone.position.x += 1;
  return clone;
}

/**
 * Simple mesh subdivision - splits each triangle into 4
 */
export function subdivideMesh(object: THREE.Object3D): void {
  object.traverse((child) => {
    if (!(child as any).isMesh) return;
    const mesh = child as THREE.Mesh;
    const geometry = mesh.geometry;
    const positions = geometry.attributes.position;
    const index = geometry.index;

    if (!positions) return;

    // Simple midpoint subdivision
    const newPositions: number[] = [];
    const getVertex = (i: number) => new THREE.Vector3(positions.getX(i), positions.getY(i), positions.getZ(i));

    const triCount = index ? index.count / 3 : positions.count / 3;

    for (let t = 0; t < triCount; t++) {
      const i0 = index ? index.getX(t * 3) : t * 3;
      const i1 = index ? index.getX(t * 3 + 1) : t * 3 + 1;
      const i2 = index ? index.getX(t * 3 + 2) : t * 3 + 2;

      const v0 = getVertex(i0);
      const v1 = getVertex(i1);
      const v2 = getVertex(i2);

      const m01 = new THREE.Vector3().addVectors(v0, v1).multiplyScalar(0.5);
      const m12 = new THREE.Vector3().addVectors(v1, v2).multiplyScalar(0.5);
      const m20 = new THREE.Vector3().addVectors(v2, v0).multiplyScalar(0.5);

      // 4 new triangles
      pushTriangle(newPositions, v0, m01, m20);
      pushTriangle(newPositions, m01, v1, m12);
      pushTriangle(newPositions, m20, m12, v2);
      pushTriangle(newPositions, m01, m12, m20);
    }

    const newGeo = new THREE.BufferGeometry();
    newGeo.setAttribute("position", new THREE.Float32BufferAttribute(newPositions, 3));
    newGeo.computeVertexNormals();
    mesh.geometry.dispose();
    mesh.geometry = newGeo;
  });
}

/**
 * Simple mesh decimation - reduces triangle count by merging close vertices
 */
export function decimateMesh(object: THREE.Object3D, ratio: number = 0.5): void {
  object.traverse((child) => {
    if (!(child as any).isMesh) return;
    const mesh = child as THREE.Mesh;
    const geometry = mesh.geometry;
    const positions = geometry.attributes.position;
    if (!positions) return;

    // Simple decimation: skip every other triangle
    const index = geometry.index;
    const triCount = index ? index.count / 3 : positions.count / 3;
    const keepCount = Math.max(1, Math.floor(triCount * ratio));

    const newPositions: number[] = [];
    const getVertex = (i: number) => new THREE.Vector3(positions.getX(i), positions.getY(i), positions.getZ(i));

    for (let t = 0; t < keepCount; t++) {
      const srcT = Math.floor(t * (triCount / keepCount));
      const i0 = index ? index.getX(srcT * 3) : srcT * 3;
      const i1 = index ? index.getX(srcT * 3 + 1) : srcT * 3 + 1;
      const i2 = index ? index.getX(srcT * 3 + 2) : srcT * 3 + 2;

      const v0 = getVertex(i0);
      const v1 = getVertex(i1);
      const v2 = getVertex(i2);

      pushTriangle(newPositions, v0, v1, v2);
    }

    const newGeo = new THREE.BufferGeometry();
    newGeo.setAttribute("position", new THREE.Float32BufferAttribute(newPositions, 3));
    newGeo.computeVertexNormals();
    mesh.geometry.dispose();
    mesh.geometry = newGeo;
  });
}

function pushTriangle(arr: number[], v0: THREE.Vector3, v1: THREE.Vector3, v2: THREE.Vector3) {
  arr.push(v0.x, v0.y, v0.z, v1.x, v1.y, v1.z, v2.x, v2.y, v2.z);
}


/**
 * Extrude selected faces on a mesh.
 * Simplified implementation that extrudes all faces outward along their normals.
 */
export function extrudeFaces(object: THREE.Object3D, amount: number = 0.1): void {
  object.traverse((child) => {
    if ((child as any).isMesh) {
      const mesh = child as THREE.Mesh;
      const geometry = mesh.geometry;
      
      if (!geometry.index) {
        console.warn("Cannot extrude non-indexed geometry");
        return;
      }

      // Clone geometry to avoid modifying original
      const newGeo = geometry.clone() as THREE.BufferGeometry;
      const positions = newGeo.attributes.position.array as Float32Array;
      
      // Compute vertex normals if not present
      if (!newGeo.attributes.normal) {
        newGeo.computeVertexNormals();
      }
      const normals = newGeo.attributes.normal.array as Float32Array;
      
      // Extrude each vertex along its normal
      for (let i = 0; i < positions.length; i += 3) {
        const nx = normals[i];
        const ny = normals[i + 1];
        const nz = normals[i + 2];
        
        positions[i] += nx * amount;
        positions[i + 1] += ny * amount;
        positions[i + 2] += nz * amount;
      }
      
      newGeo.attributes.position.needsUpdate = true;
      newGeo.computeVertexNormals();
      
      mesh.geometry = newGeo;
    }
  });
}



/**
 * Apply batch transforms to multiple objects.
 * All objects are transformed relative to their current position/rotation/scale.
 */
export function batchTransform(
  objects: THREE.Object3D[],
  position?: [number, number, number],
  rotation?: [number, number, number],
  scale?: [number, number, number]
): void {
  objects.forEach((obj) => {
    if (position) {
      obj.position.x += position[0];
      obj.position.y += position[1];
      obj.position.z += position[2];
    }
    if (rotation) {
      obj.rotation.x += rotation[0];
      obj.rotation.y += rotation[1];
      obj.rotation.z += rotation[2];
    }
    if (scale) {
      obj.scale.x *= scale[0];
      obj.scale.y *= scale[1];
      obj.scale.z *= scale[2];
    }
  });
}

/**
 * Get the center point of multiple objects (bounding box center).
 */
export function getBatchCenter(objects: THREE.Object3D[]): THREE.Vector3 {
  if (objects.length === 0) return new THREE.Vector3();
  
  const box = new THREE.Box3();
  objects.forEach((obj) => {
    const objBox = new THREE.Box3().setFromObject(obj);
    box.union(objBox);
  });
  
  return box.getCenter(new THREE.Vector3());
}

/**
 * Delete multiple objects from a scene.
 */
export function batchDelete(scene: THREE.Scene, objects: THREE.Object3D[]): void {
  objects.forEach((obj) => {
    scene.remove(obj);
  });
}
