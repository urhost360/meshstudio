import * as THREE from "three";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { MTLLoader } from "three/examples/jsm/loaders/MTLLoader.js";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader.js";
import JSZip from "jszip";

export type SupportedFormat = "obj" | "stl" | "gltf" | "glb" | "fbx" | "zip";

const SUPPORTED_EXTENSIONS: Record<string, SupportedFormat> = {
  ".obj": "obj",
  ".stl": "stl",
  ".gltf": "gltf",
  ".glb": "glb",
  ".fbx": "fbx",
  ".zip": "zip",
};

const MODEL_EXTENSIONS = [".obj", ".stl", ".gltf", ".glb", ".fbx"];

export function getFormatFromFilename(filename: string): SupportedFormat | null {
  if (!filename || typeof filename !== "string") return null;
  const ext = filename.toLowerCase().substring(filename.lastIndexOf("."));
  return SUPPORTED_EXTENSIONS[ext] ?? null;
}

export function getSupportedExtensions(): string[] {
  return Object.keys(SUPPORTED_EXTENSIONS);
}

export function getAcceptString(): string {
  return Object.keys(SUPPORTED_EXTENSIONS).map(e => e).join(",") + ",.zip,application/zip";
}

export async function loadModelFromFile(file: File): Promise<THREE.Group> {
  try {
    if (!file || !file.name) throw new Error("Invalid file object");
    if (file.size === 0) throw new Error(`${file.name}: File is empty`);
    if (file.size > 500 * 1024 * 1024) throw new Error(`${file.name}: File exceeds 500MB limit`);

    const format = getFormatFromFilename(file.name);
    if (!format) throw new Error(`Unsupported file format: ${file.name}. Supported: ${getSupportedExtensions().join(", ")}`);

    if (format === "zip") {
      return await loadModelFromZip(file);
    }

    const arrayBuffer = await file.arrayBuffer();
    if (!arrayBuffer || arrayBuffer.byteLength === 0) throw new Error(`${file.name}: Failed to read file`);
    return await loadModelFromBuffer(arrayBuffer, format, file.name);
  } catch (e: any) {
    const message = e?.message || "Unknown error loading model";
    throw new Error(`Failed to load ${file?.name || "file"}: ${message}`);
  }
}

export async function loadModelFromUrl(url: string, format: SupportedFormat, name: string): Promise<THREE.Group> {
  try {
    if (!url || typeof url !== "string") throw new Error("Invalid URL");
    if (!format) throw new Error("Invalid format");
    if (!name) throw new Error("Invalid name");

    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    
    const arrayBuffer = await response.arrayBuffer();
    if (!arrayBuffer || arrayBuffer.byteLength === 0) throw new Error("Empty response");

    if (format === "zip") {
      const blob = new Blob([arrayBuffer], { type: "application/zip" });
      const file = new File([blob], name + ".zip");
      return await loadModelFromZip(file);
    }

    return await loadModelFromBuffer(arrayBuffer, format, name);
  } catch (e: any) {
    const message = e?.message || "Unknown error";
    throw new Error(`Failed to load model from URL: ${message}`);
  }
}

async function loadModelFromZip(file: File): Promise<THREE.Group> {
  try {
    if (!file || !file.name) throw new Error("Invalid ZIP file");
    if (file.size === 0) throw new Error("ZIP file is empty");

    const arrayBuffer = await file.arrayBuffer();
    if (!arrayBuffer || arrayBuffer.byteLength === 0) throw new Error("Failed to read ZIP file");

    let zip: JSZip;
    try {
      zip = await JSZip.loadAsync(arrayBuffer);
    } catch (e: any) {
      throw new Error(`Invalid ZIP file: ${e?.message || "corrupted"}`);
    }

    const files: Record<string, JSZip.JSZipObject> = {};
    const fileNames: string[] = [];
    
    try {
      zip.forEach((relativePath, zipEntry) => {
        if (!zipEntry.dir && relativePath && typeof relativePath === "string") {
          files[relativePath] = zipEntry;
          fileNames.push(relativePath);
        }
      });
    } catch (e: any) {
      throw new Error(`Failed to read ZIP contents: ${e?.message}`);
    }

    if (fileNames.length === 0) throw new Error("ZIP file is empty");

    const modelFile = fileNames.find(f => {
      const ext = f.toLowerCase().substring(f.lastIndexOf("."));
      return MODEL_EXTENSIONS.includes(ext);
    });

    if (!modelFile) {
      throw new Error(`No 3D model found in ZIP. Looking for: ${MODEL_EXTENSIONS.join(", ")}. Found: ${fileNames.slice(0, 5).join(", ")}${fileNames.length > 5 ? "..." : ""}`);
    }

    const modelExt = modelFile.toLowerCase().substring(modelFile.lastIndexOf("."));
    const modelFormat = SUPPORTED_EXTENSIONS[modelExt];
    if (!modelFormat || modelFormat === "zip") {
      throw new Error(`Unsupported model format inside ZIP: ${modelExt}`);
    }

    if (modelFormat === "obj") {
      return await loadObjFromZip(files, modelFile, file.name);
    }

    const modelBuffer = await files[modelFile].async("arraybuffer");
    if (!modelBuffer || modelBuffer.byteLength === 0) throw new Error("Failed to extract model from ZIP");
    return await loadModelFromBuffer(modelBuffer, modelFormat, file.name.replace(/\.zip$/i, ""));
  } catch (e: any) {
    const message = e?.message || "Unknown error";
    throw new Error(`Failed to load ZIP file: ${message}`);
  }
}

async function loadObjFromZip(
  files: Record<string, JSZip.JSZipObject>,
  objPath: string,
  zipName: string
): Promise<THREE.Group> {
  try {
    if (!files || !objPath) throw new Error("Invalid parameters");

    const fileNames = Object.keys(files);
    let objText: string;
    try {
      objText = await files[objPath].async("text");
    } catch (e: any) {
      throw new Error(`Failed to read OBJ file: ${e?.message}`);
    }

    if (!objText || objText.trim().length === 0) throw new Error("OBJ file is empty");

    let mtlPath: string | null = null;
    const mtlMatch = objText.match(/^mtllib\s+(.+)$/m);
    if (mtlMatch) {
      const mtlRef = mtlMatch[1].trim();
      const objDir = objPath.includes("/") ? objPath.substring(0, objPath.lastIndexOf("/") + 1) : "";
      const candidates = [
        objDir + mtlRef,
        mtlRef,
        mtlRef.substring(mtlRef.lastIndexOf("/") + 1),
      ];
      for (const candidate of candidates) {
        const found = fileNames.find(f => f === candidate || f.endsWith("/" + candidate) || f.toLowerCase() === candidate.toLowerCase());
        if (found) { mtlPath = found; break; }
      }
    }

    if (!mtlPath) {
      mtlPath = fileNames.find(f => f.toLowerCase().endsWith(".mtl")) ?? null;
    }

    const textureUrls: Record<string, string> = {};
    const imageExtensions = [".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga", ".webp"];

    for (const fname of fileNames) {
      const ext = fname.toLowerCase().substring(fname.lastIndexOf("."));
      if (imageExtensions.includes(ext)) {
        try {
          const blob = await files[fname].async("blob");
          const mimeType = ext === ".png" ? "image/png" :
                           ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" :
                           ext === ".bmp" ? "image/bmp" :
                           ext === ".gif" ? "image/gif" :
                           ext === ".webp" ? "image/webp" : "image/png";
          const blobUrl = URL.createObjectURL(new Blob([blob], { type: mimeType }));
          textureUrls[fname] = blobUrl;
          const baseName = fname.substring(fname.lastIndexOf("/") + 1);
          textureUrls[baseName] = blobUrl;
        } catch (e: any) {
          console.warn(`Failed to load texture ${fname}:`, e?.message);
        }
      }
    }

    const group = new THREE.Group();
    const displayName = zipName.replace(/\.zip$/i, "");
    group.name = displayName;
    group.userData.displayName = displayName;
    group.userData.format = "obj";

    if (mtlPath) {
      let mtlText: string;
      try {
        mtlText = await files[mtlPath].async("text");
      } catch (e: any) {
        console.warn(`Failed to read MTL file: ${e?.message}`);
        mtlText = "";
      }

      if (mtlText && mtlText.trim().length > 0) {
        const manager = new THREE.LoadingManager();

        const loadingComplete = new Promise<void>((resolve) => {
          manager.onLoad = () => resolve();
          manager.onError = () => resolve();
        });

        manager.setURLModifier((url: string) => {
          const cleanUrl = url.replace(/^\.\//,  "");
          if (textureUrls[cleanUrl]) return textureUrls[cleanUrl];
          const basename = cleanUrl.substring(cleanUrl.lastIndexOf("/") + 1);
          if (textureUrls[basename]) return textureUrls[basename];
          for (const [key, blobUrl] of Object.entries(textureUrls)) {
            if (key.endsWith(basename) || key.endsWith(cleanUrl)) return blobUrl;
          }
          return url;
        });

        try {
          const mtlLoaderWithManager = new MTLLoader(manager);
          const materials = mtlLoaderWithManager.parse(mtlText, "");
          materials.preload();
          await loadingComplete;

          const objLoader = new OBJLoader(manager);
          objLoader.setMaterials(materials);
          const obj = objLoader.parse(objText);

          obj.traverse((child) => {
            if ((child as any).isMesh) {
              const mesh = child as THREE.Mesh;
              mesh.castShadow = true;
              mesh.receiveShadow = true;

              const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
              for (const mat of materials) {
                if (mat && (mat as any).map) {
                  (mat as any).map.colorSpace = THREE.SRGBColorSpace;
                  (mat as any).map.needsUpdate = true;
                }
                if (mat) {
                  (mat as any).needsUpdate = true;
                }
              }
            }
          });

          while (obj.children.length > 0) {
            group.add(obj.children[0]);
          }
        } catch (e: any) {
          console.warn(`Failed to parse OBJ with MTL: ${e?.message}, falling back to OBJ only`);
          const objLoader = new OBJLoader();
          const obj = objLoader.parse(objText);
          applyDefaultMaterial(obj);
          while (obj.children.length > 0) {
            group.add(obj.children[0]);
          }
        }
      } else {
        const objLoader = new OBJLoader();
        const obj = objLoader.parse(objText);
        applyDefaultMaterial(obj);
        while (obj.children.length > 0) {
          group.add(obj.children[0]);
        }
      }
    } else {
      const objLoader = new OBJLoader();
      const obj = objLoader.parse(objText);
      applyDefaultMaterial(obj);
      while (obj.children.length > 0) {
        group.add(obj.children[0]);
      }
    }

    return group;
  } catch (e: any) {
    const message = e?.message || "Unknown error";
    throw new Error(`Failed to load OBJ from ZIP: ${message}`);
  }
}

async function loadModelFromBuffer(buffer: ArrayBuffer, format: SupportedFormat, name: string): Promise<THREE.Group> {
  try {
    if (!buffer || buffer.byteLength === 0) throw new Error("Empty buffer");
    if (!format) throw new Error("Invalid format");

    const group = new THREE.Group();
    group.name = name;
    group.userData.displayName = name;
    group.userData.format = format;

    if (format === "stl") {
      try {
        const geometry = new STLLoader().parse(buffer);
        if (!geometry || geometry.attributes.position.count === 0) throw new Error("STL geometry is empty");
        const material = new THREE.MeshPhongMaterial({ color: 0xcccccc });
        const mesh = new THREE.Mesh(geometry, material);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        group.add(mesh);
      } catch (e: any) {
        throw new Error(`Failed to parse STL: ${e?.message}`);
      }
    } else if (format === "gltf" || format === "glb") {
      try {
        const gltf = await new GLTFLoader().parseAsync(buffer, "");
        if (!gltf || !gltf.scene) throw new Error("Invalid GLTF/GLB file");
        gltf.scene.traverse((child) => {
          if ((child as any).isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
          }
        });
        while (gltf.scene.children.length > 0) {
          group.add(gltf.scene.children[0]);
        }
      } catch (e: any) {
        throw new Error(`Failed to parse GLTF/GLB: ${e?.message}`);
      }
    } else if (format === "fbx") {
      try {
        const fbx = new FBXLoader().parse(buffer, "");
        if (!fbx) throw new Error("Invalid FBX file");
        fbx.traverse((child) => {
          if ((child as any).isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
          }
        });
        while (fbx.children.length > 0) {
          group.add(fbx.children[0]);
        }
      } catch (e: any) {
        throw new Error(`Failed to parse FBX: ${e?.message}`);
      }
    } else {
      throw new Error(`Unsupported format: ${format}`);
    }

    if (group.children.length === 0) throw new Error("No geometry loaded from model");
    return group;
  } catch (e: any) {
    const message = e?.message || "Unknown error";
    throw new Error(`Failed to load ${format.toUpperCase()} model: ${message}`);
  }
}

function applyDefaultMaterial(obj: THREE.Group): void {
  const material = new THREE.MeshPhongMaterial({ color: 0xcccccc });
  obj.traverse((child) => {
    if ((child as any).isMesh) {
      const mesh = child as THREE.Mesh;
      mesh.material = material;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
  });
}
