import * as THREE from "three";
import { OBJExporter } from "three/examples/jsm/exporters/OBJExporter.js";
import { STLExporter } from "three/examples/jsm/exporters/STLExporter.js";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { USDZExporter } from "three/examples/jsm/exporters/USDZExporter.js";

export type ExportFormat = "obj" | "stl" | "glb" | "gltf" | "usdz" | "png";

export interface SceneStats {
  totalPolygons: number;
  totalVertices: number;
  meshCount: number;
  textureCount: number;
  maxTextureSize: number;
  textureSizes: { name: string; width: number; height: number }[];
  warnings: string[];
}

/**
 * Analyze a scene/object for polygon count, texture sizes, and AR readiness.
 */
export function analyzeScene(target: THREE.Object3D): SceneStats {
  let totalPolygons = 0;
  let totalVertices = 0;
  let meshCount = 0;
  let textureCount = 0;
  let maxTextureSize = 0;
  const textureSizes: { name: string; width: number; height: number }[] = [];
  const warnings: string[] = [];
  const seenTextures = new Set<string>();

  target.traverse((child) => {
    if ((child as any).isMesh) {
      const mesh = child as THREE.Mesh;
      meshCount++;

      const geometry = mesh.geometry;
      if (geometry) {
        if (geometry.index) {
          totalPolygons += geometry.index.count / 3;
        } else if (geometry.attributes.position) {
          totalPolygons += geometry.attributes.position.count / 3;
        }
        if (geometry.attributes.position) {
          totalVertices += geometry.attributes.position.count;
        }
      }

      // Check textures
      const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const mat of materials) {
        if (!mat) continue;
        const textureProps = ["map", "normalMap", "roughnessMap", "metalnessMap", "aoMap", "emissiveMap"] as const;
        for (const prop of textureProps) {
          const tex = (mat as any)[prop] as THREE.Texture | undefined;
          if (tex && tex.image && !seenTextures.has(tex.uuid)) {
            seenTextures.add(tex.uuid);
            textureCount++;
            const img = tex.image as any;
            const w = img.width || img.naturalWidth || 0;
            const h = img.height || img.naturalHeight || 0;
            if (w > 0 && h > 0) {
              const size = Math.max(w, h);
              maxTextureSize = Math.max(maxTextureSize, size);
              textureSizes.push({ name: tex.name || prop, width: w, height: h });
            }
          }
        }
      }
    }
  });

  // Generate warnings
  if (totalPolygons > 100000) {
    warnings.push(`High polygon count (${Math.round(totalPolygons).toLocaleString()}). For mobile AR, recommended max is 100K polygons. Consider using mesh decimation.`);
  } else if (totalPolygons > 50000) {
    warnings.push(`Moderate polygon count (${Math.round(totalPolygons).toLocaleString()}). May affect performance on older mobile devices.`);
  }

  if (maxTextureSize > 2048) {
    warnings.push(`Textures exceed 2K (${maxTextureSize}px). For mobile AR, recommended max is 2048x2048. Consider resizing textures.`);
  }

  if (totalPolygons > 500000) {
    warnings.push("Very high polygon count. USDZ export may fail or produce a very large file. Consider simplifying the mesh first.");
  }

  if (meshCount === 0) {
    warnings.push("No meshes found in the scene. Nothing to export.");
  }

  return { totalPolygons, totalVertices, meshCount, textureCount, maxTextureSize, textureSizes, warnings };
}

/**
 * Export a Three.js scene or object to the specified format.
 * Returns a Blob that can be downloaded.
 */
export async function exportModel(
  target: THREE.Object3D | THREE.Scene,
  format: ExportFormat,
  renderer?: THREE.WebGLRenderer,
  camera?: THREE.PerspectiveCamera
): Promise<Blob> {
  switch (format) {
    case "obj": {
      const exporter = new OBJExporter();
      const result = exporter.parse(target);
      return new Blob([result], { type: "text/plain" });
    }
    case "stl": {
      const exporter = new STLExporter();
      const result = exporter.parse(target, { binary: true });
      return new Blob([result], { type: "application/octet-stream" });
    }
    case "glb": {
      const exporter = new GLTFExporter();
      const result = await new Promise<ArrayBuffer>((resolve, reject) => {
        exporter.parse(
          target,
          (gltf) => resolve(gltf as ArrayBuffer),
          reject,
          { binary: true }
        );
      });
      return new Blob([result], { type: "model/gltf-binary" });
    }
    case "gltf": {
      const exporter = new GLTFExporter();
      const result = await new Promise<object>((resolve, reject) => {
        exporter.parse(
          target,
          (gltf) => resolve(gltf as object),
          reject,
          { binary: false }
        );
      });
      return new Blob([JSON.stringify(result, null, 2)], { type: "model/gltf+json" });
    }
    case "usdz": {
      const exporter = new USDZExporter();
      const blob = await (exporter as any).parse(target);
      if (blob instanceof Blob) return blob;
      if (blob instanceof ArrayBuffer) return new Blob([blob], { type: "model/vnd.usdz+zip" });
      // If it returns a Uint8Array or similar
      return new Blob([blob], { type: "model/vnd.usdz+zip" });
    }
    case "png": {
      if (!renderer || !camera) throw new Error("Renderer and camera required for PNG export");
      renderer.render(target as THREE.Scene, camera);
      const dataUrl = renderer.domElement.toDataURL("image/png");
      const response = await fetch(dataUrl);
      return response.blob();
    }
    default:
      throw new Error(`Unsupported export format: ${format}`);
  }
}

/**
 * Trigger a file download in the browser
 */
export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
