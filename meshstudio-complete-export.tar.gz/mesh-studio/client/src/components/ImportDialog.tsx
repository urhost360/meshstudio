import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Upload, FileBox, X, AlertCircle } from "lucide-react";
import { useState, useRef, useCallback } from "react";
import { getAcceptString, getSupportedExtensions } from "@/lib/fileLoader";
import { toast } from "sonner";

interface ImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFilesSelected: (files: File[]) => void;
  loading?: boolean;
}

const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500MB per file
const MAX_TOTAL_SIZE = 1024 * 1024 * 1024; // 1GB total
const MAX_FILES = 50;

export default function ImportDialog({ open, onOpenChange, onFilesSelected, loading }: ImportDialogProps) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const validateFiles = useCallback((files: File[]): { valid: File[]; errors: string[] } => {
    const validFiles: File[] = [];
    const newErrors: string[] = [];
    const supportedExts = getSupportedExtensions().map(e => e.toLowerCase());
    let totalSize = selectedFiles.reduce((sum, f) => sum + f.size, 0);

    // Check total file count
    if (selectedFiles.length + files.length > MAX_FILES) {
      newErrors.push(`Cannot add more than ${MAX_FILES} files total`);
      return { valid: [], errors: newErrors };
    }

    for (const file of files) {
      // Validate file exists and has a name
      if (!file || !file.name) {
        newErrors.push("Invalid file detected");
        continue;
      }

      // Validate file size
      if (file.size === 0) {
        newErrors.push(`${file.name}: File is empty`);
        continue;
      }

      if (file.size > MAX_FILE_SIZE) {
        newErrors.push(`${file.name}: Exceeds 500MB limit (${(file.size / 1024 / 1024).toFixed(1)}MB)`);
        continue;
      }

      totalSize += file.size;
      if (totalSize > MAX_TOTAL_SIZE) {
        newErrors.push(`Total size exceeds 1GB limit`);
        break;
      }

      // Validate file extension
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (!ext || !supportedExts.includes(`.${ext}`)) {
        newErrors.push(`${file.name}: Unsupported format (.${ext})`);
        continue;
      }

      // Validate MIME type for common formats
      const validMimes = [
        "application/octet-stream",
        "model/obj",
        "model/stl",
        "model/gltf+json",
        "model/gltf-binary",
        "application/zip",
        "application/x-zip-compressed",
        "text/plain", // OBJ files
      ];
      if (file.type && !validMimes.includes(file.type) && !file.type.startsWith("model/")) {
        newErrors.push(`${file.name}: Invalid MIME type (${file.type})`);
        continue;
      }

      validFiles.push(file);
    }

    return { valid: validFiles, errors: newErrors };
  }, [selectedFiles]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    if (!e.dataTransfer.files || e.dataTransfer.files.length === 0) {
      toast.error("No files detected in drop");
      return;
    }

    const files = Array.from(e.dataTransfer.files);
    const { valid, errors } = validateFiles(files);

    if (errors.length > 0) {
      setErrors(errors);
      errors.forEach(err => toast.error(err));
    }

    if (valid.length > 0) {
      setSelectedFiles(prev => [...prev, ...valid]);
      setErrors([]);
    }
  }, [validateFiles]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      toast.error("No files selected");
      return;
    }

    const files = Array.from(e.target.files);
    const { valid, errors } = validateFiles(files);

    if (errors.length > 0) {
      setErrors(errors);
      errors.forEach(err => toast.error(err));
    }

    if (valid.length > 0) {
      setSelectedFiles(prev => [...prev, ...valid]);
      setErrors([]);
    }

    // Reset input so same file can be selected again
    e.target.value = "";
  }, [validateFiles]);

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    setErrors([]);
  };

  const handleImport = () => {
    if (selectedFiles.length === 0) {
      toast.error("No files selected");
      return;
    }

    // Final validation before import
    const { valid, errors } = validateFiles(selectedFiles);
    if (errors.length > 0) {
      setErrors(errors);
      errors.forEach(err => toast.error(err));
      return;
    }

    onFilesSelected(valid);
    setSelectedFiles([]);
    setErrors([]);
  };

  const handleClose = (open: boolean) => {
    if (!open) {
      setSelectedFiles([]);
      setErrors([]);
    }
    onOpenChange(open);
  };

  const totalSize = selectedFiles.reduce((sum, f) => sum + f.size, 0);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground">Import 3D Assets</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Upload OBJ, STL, FBX, GLTF, GLB files or ZIP bundles (OBJ + MTL + textures)
          </DialogDescription>
        </DialogHeader>

        {/* Drop zone */}
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            dragOver
              ? "border-primary bg-primary/10"
              : "border-border hover:border-muted-foreground/50"
          }`}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
        >
          <Upload className={`h-10 w-10 mx-auto mb-3 ${dragOver ? "text-primary" : "text-muted-foreground/50"}`} />
          <p className="text-sm text-foreground font-medium">
            Drag & drop files here or click to browse
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Max 500MB per file, 1GB total, {MAX_FILES} files max
          </p>
          <p className="text-xs text-muted-foreground">
            Supported: {getSupportedExtensions().join(", ")}
          </p>
          <input
            ref={inputRef}
            type="file"
            multiple
            accept={getAcceptString()}
            className="hidden"
            onChange={handleFileInput}
            disabled={loading}
          />
        </div>

        {/* Error messages */}
        {errors.length > 0 && (
          <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 space-y-1">
            {errors.map((err, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <AlertCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                <span className="text-destructive text-xs">{err}</span>
              </div>
            ))}
          </div>
        )}

        {/* Selected files list */}
        {selectedFiles.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-muted-foreground">
                {selectedFiles.length} file{selectedFiles.length !== 1 ? "s" : ""} selected
              </span>
              <span className="text-xs text-muted-foreground">
                {(totalSize / 1024 / 1024).toFixed(1)}MB / 1GB
              </span>
            </div>
            <div className="max-h-40 overflow-y-auto space-y-1">
              {selectedFiles.map((file, i) => (
                <div key={i} className="flex items-center gap-2 px-3 py-2 bg-secondary rounded-md">
                  <FileBox className="h-4 w-4 text-primary shrink-0" />
                  <span className="text-xs text-foreground flex-1 truncate">{file.name}</span>
                  <span className="text-[10px] text-muted-foreground shrink-0">
                    {(file.size / 1024).toFixed(0)} KB
                  </span>
                  <button
                    onClick={() => removeFile(i)}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    disabled={loading}
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end gap-2">
          <Button
            variant="ghost"
            onClick={() => handleClose(false)}
            className="text-muted-foreground"
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleImport}
            disabled={selectedFiles.length === 0 || loading || errors.length > 0}
          >
            {loading ? "Importing..." : `Import ${selectedFiles.length} file${selectedFiles.length !== 1 ? "s" : ""}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
