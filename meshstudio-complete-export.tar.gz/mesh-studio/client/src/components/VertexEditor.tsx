import * as THREE from "three";
import type { ViewportRef, EditMode } from "./ThreeViewport";

/**
 * Manages vertex/face/edge visualization overlays for polygon editing.
 * Supports individual click selection and bulk lasso/box selection.
 * Selected elements are highlighted in orange; unselected in blue.
 */
export class VertexEditorManager {
  private scene: THREE.Scene;
  private vertexPoints: THREE.Points | null = null;
  private edgeLines: THREE.LineSegments | null = null;
  private faceHighlights: THREE.Mesh | null = null;
  private selectedVertices: Set<number> = new Set();
  private selectedFaces: Set<number> = new Set();
  private selectedEdges: Set<number> = new Set();
  private currentMesh: THREE.Mesh | null = null;
  private currentMode: EditMode = "object";

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  /** Show edit helpers for the given object and mode */
  showEditHelpers(object: THREE.Object3D | null, mode: EditMode) {
    this.clearHelpers();
    this.currentMode = mode;
    if (!object || mode === "object") {
      this.currentMesh = null;
      return;
    }

    let targetMesh: THREE.Mesh | null = null;
    if ((object as any).isMesh) {
      targetMesh = object as THREE.Mesh;
    } else {
      object.traverse((child) => {
        if (!targetMesh && (child as any).isMesh) targetMesh = child as THREE.Mesh;
      });
    }
    if (!targetMesh) return;

    this.currentMesh = targetMesh;
    const geometry = targetMesh.geometry;
    if (!geometry) return;

    const worldMatrix = targetMesh.matrixWorld;

    if (mode === "vertex") {
      this.showVertices(geometry, worldMatrix);
    } else if (mode === "edge") {
      this.showEdges(geometry, worldMatrix);
    } else if (mode === "face") {
      this.showFaces(geometry, worldMatrix);
    }
  }

  /** Refresh the helpers to reflect current selection state */
  refreshHelpers() {
    if (!this.currentMesh || this.currentMode === "object") return;
    this.clearHelpers();
    const geometry = this.currentMesh.geometry;
    if (!geometry) return;
    const worldMatrix = this.currentMesh.matrixWorld;

    if (this.currentMode === "vertex") {
      this.showVertices(geometry, worldMatrix);
    } else if (this.currentMode === "edge") {
      this.showEdges(geometry, worldMatrix);
    } else if (this.currentMode === "face") {
      this.showFaces(geometry, worldMatrix);
    }
  }

  /** Set selection from lasso/box tool */
  setSelection(indices: Set<number>, mode: EditMode) {
    if (mode === "vertex") {
      this.selectedVertices = new Set(indices);
    } else if (mode === "face") {
      this.selectedFaces = new Set(indices);
    } else if (mode === "edge") {
      this.selectedEdges = new Set(indices);
    }
    this.refreshHelpers();
  }

  /** Add to existing selection (shift-lasso) */
  addToSelection(indices: Set<number>, mode: EditMode) {
    if (mode === "vertex") {
      indices.forEach((i) => this.selectedVertices.add(i));
    } else if (mode === "face") {
      indices.forEach((i) => this.selectedFaces.add(i));
    } else if (mode === "edge") {
      indices.forEach((i) => this.selectedEdges.add(i));
    }
    this.refreshHelpers();
  }

  /** Get current selection counts */
  getSelectionCount(): number {
    if (this.currentMode === "vertex") return this.selectedVertices.size;
    if (this.currentMode === "face") return this.selectedFaces.size;
    if (this.currentMode === "edge") return this.selectedEdges.size;
    return 0;
  }

  /** Delete selected faces from the mesh geometry */
  deleteSelected(): boolean {
    if (!this.currentMesh) return false;
    const geometry = this.currentMesh.geometry;
    if (!geometry || !geometry.attributes.position) return false;

    if (this.currentMode === "face" && this.selectedFaces.size > 0) {
      return this.deleteFaces(geometry);
    } else if (this.currentMode === "vertex" && this.selectedVertices.size > 0) {
      return this.deleteVertices(geometry);
    }
    return false;
  }

  private deleteFaces(geometry: THREE.BufferGeometry): boolean {
    const positions = geometry.attributes.position;
    const indexAttr = geometry.index;
    const faceCount = indexAttr ? indexAttr.count / 3 : positions.count / 3;

    if (this.selectedFaces.size === 0) return false;

    if (indexAttr) {
      // Indexed geometry — remove selected face indices
      const newIndices: number[] = [];
      for (let f = 0; f < faceCount; f++) {
        if (!this.selectedFaces.has(f)) {
          newIndices.push(
            indexAttr.getX(f * 3),
            indexAttr.getX(f * 3 + 1),
            indexAttr.getX(f * 3 + 2)
          );
        }
      }
      geometry.setIndex(newIndices);
    } else {
      // Non-indexed geometry — rebuild position buffer without selected faces
      const oldPositions = positions.array as Float32Array;
      const newPositions: number[] = [];
      const oldNormals = geometry.attributes.normal?.array as Float32Array | undefined;
      const newNormals: number[] = [];
      const oldUvs = geometry.attributes.uv?.array as Float32Array | undefined;
      const newUvs: number[] = [];

      for (let f = 0; f < faceCount; f++) {
        if (!this.selectedFaces.has(f)) {
          for (let v = 0; v < 3; v++) {
            const idx = f * 3 + v;
            newPositions.push(oldPositions[idx * 3], oldPositions[idx * 3 + 1], oldPositions[idx * 3 + 2]);
            if (oldNormals) {
              newNormals.push(oldNormals[idx * 3], oldNormals[idx * 3 + 1], oldNormals[idx * 3 + 2]);
            }
            if (oldUvs) {
              newUvs.push(oldUvs[idx * 2], oldUvs[idx * 2 + 1]);
            }
          }
        }
      }

      geometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(newPositions), 3));
      if (newNormals.length > 0) {
        geometry.setAttribute("normal", new THREE.BufferAttribute(new Float32Array(newNormals), 3));
      }
      if (newUvs.length > 0) {
        geometry.setAttribute("uv", new THREE.BufferAttribute(new Float32Array(newUvs), 2));
      }
    }

    geometry.computeBoundingSphere();
    geometry.computeBoundingBox();
    this.selectedFaces.clear();
    return true;
  }

  private deleteVertices(geometry: THREE.BufferGeometry): boolean {
    const positions = geometry.attributes.position;
    const indexAttr = geometry.index;

    if (this.selectedVertices.size === 0) return false;

    if (indexAttr) {
      // Remove faces that reference any selected vertex
      const faceCount = indexAttr.count / 3;
      const newIndices: number[] = [];
      for (let f = 0; f < faceCount; f++) {
        const i0 = indexAttr.getX(f * 3);
        const i1 = indexAttr.getX(f * 3 + 1);
        const i2 = indexAttr.getX(f * 3 + 2);
        if (!this.selectedVertices.has(i0) && !this.selectedVertices.has(i1) && !this.selectedVertices.has(i2)) {
          newIndices.push(i0, i1, i2);
        }
      }
      geometry.setIndex(newIndices);
    } else {
      // Non-indexed: remove faces that contain any selected vertex
      const faceCount = positions.count / 3;
      const oldPositions = positions.array as Float32Array;
      const newPositions: number[] = [];
      const oldNormals = geometry.attributes.normal?.array as Float32Array | undefined;
      const newNormals: number[] = [];

      for (let f = 0; f < faceCount; f++) {
        const i0 = f * 3;
        const i1 = f * 3 + 1;
        const i2 = f * 3 + 2;
        if (!this.selectedVertices.has(i0) && !this.selectedVertices.has(i1) && !this.selectedVertices.has(i2)) {
          for (let v = 0; v < 3; v++) {
            const idx = f * 3 + v;
            newPositions.push(oldPositions[idx * 3], oldPositions[idx * 3 + 1], oldPositions[idx * 3 + 2]);
            if (oldNormals) newNormals.push(oldNormals[idx * 3], oldNormals[idx * 3 + 1], oldNormals[idx * 3 + 2]);
          }
        }
      }

      geometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(newPositions), 3));
      if (newNormals.length > 0) {
        geometry.setAttribute("normal", new THREE.BufferAttribute(new Float32Array(newNormals), 3));
      }
    }

    geometry.computeBoundingSphere();
    geometry.computeBoundingBox();
    this.selectedVertices.clear();
    return true;
  }

  private showVertices(geometry: THREE.BufferGeometry, worldMatrix: THREE.Matrix4) {
    const positions = geometry.attributes.position;
    if (!positions) return;

    const pointsGeometry = new THREE.BufferGeometry();
    const vertices = new Float32Array(positions.count * 3);
    const colors = new Float32Array(positions.count * 3);

    for (let i = 0; i < positions.count; i++) {
      const v = new THREE.Vector3(positions.getX(i), positions.getY(i), positions.getZ(i));
      v.applyMatrix4(worldMatrix);
      vertices[i * 3] = v.x;
      vertices[i * 3 + 1] = v.y;
      vertices[i * 3 + 2] = v.z;

      if (this.selectedVertices.has(i)) {
        // Orange for selected
        colors[i * 3] = 1; colors[i * 3 + 1] = 0.55; colors[i * 3 + 2] = 0;
      } else {
        // Blue for unselected
        colors[i * 3] = 0.3; colors[i * 3 + 1] = 0.7; colors[i * 3 + 2] = 1;
      }
    }

    pointsGeometry.setAttribute("position", new THREE.BufferAttribute(vertices, 3));
    pointsGeometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 5,
      sizeAttenuation: false,
      vertexColors: true,
      depthTest: false,
    });

    this.vertexPoints = new THREE.Points(pointsGeometry, material);
    this.vertexPoints.name = "__vertexHelper";
    this.vertexPoints.renderOrder = 999;
    this.scene.add(this.vertexPoints);
  }

  private showEdges(geometry: THREE.BufferGeometry, worldMatrix: THREE.Matrix4) {
    const edgesGeometry = new THREE.EdgesGeometry(geometry, 15);
    const positions = edgesGeometry.attributes.position;
    const transformedPositions = new Float32Array(positions.count * 3);

    for (let i = 0; i < positions.count; i++) {
      const v = new THREE.Vector3(positions.getX(i), positions.getY(i), positions.getZ(i));
      v.applyMatrix4(worldMatrix);
      transformedPositions[i * 3] = v.x;
      transformedPositions[i * 3 + 1] = v.y;
      transformedPositions[i * 3 + 2] = v.z;
    }

    const transformedGeometry = new THREE.BufferGeometry();
    transformedGeometry.setAttribute("position", new THREE.BufferAttribute(transformedPositions, 3));

    const material = new THREE.LineBasicMaterial({
      color: 0x44aaff,
      depthTest: false,
      linewidth: 1,
    });

    this.edgeLines = new THREE.LineSegments(transformedGeometry, material);
    this.edgeLines.name = "__edgeHelper";
    this.edgeLines.renderOrder = 999;
    this.scene.add(this.edgeLines);
  }

  private showFaces(geometry: THREE.BufferGeometry, worldMatrix: THREE.Matrix4) {
    if (this.selectedFaces.size > 0) {
      // Show selected faces in orange, unselected in blue
      this.showFacesWithSelection(geometry, worldMatrix);
    } else {
      const clonedGeo = geometry.clone();
      clonedGeo.applyMatrix4(worldMatrix);

      const material = new THREE.MeshBasicMaterial({
        color: 0x4488ff,
        opacity: 0.15,
        transparent: true,
        side: THREE.DoubleSide,
        depthTest: false,
      });

      this.faceHighlights = new THREE.Mesh(clonedGeo, material);
      this.faceHighlights.name = "__faceHelper";
      this.faceHighlights.renderOrder = 998;
      this.scene.add(this.faceHighlights);
    }

    // Also show edges
    this.showEdges(geometry, worldMatrix);
  }

  private showFacesWithSelection(geometry: THREE.BufferGeometry, worldMatrix: THREE.Matrix4) {
    const positions = geometry.attributes.position;
    const indexAttr = geometry.index;
    const faceCount = indexAttr ? indexAttr.count / 3 : positions.count / 3;

    // Build colored face geometry
    const facePositions: number[] = [];
    const faceColors: number[] = [];

    for (let f = 0; f < faceCount; f++) {
      const i0 = indexAttr ? indexAttr.getX(f * 3) : f * 3;
      const i1 = indexAttr ? indexAttr.getX(f * 3 + 1) : f * 3 + 1;
      const i2 = indexAttr ? indexAttr.getX(f * 3 + 2) : f * 3 + 2;

      for (const idx of [i0, i1, i2]) {
        const v = new THREE.Vector3(
          positions.getX(idx), positions.getY(idx), positions.getZ(idx)
        ).applyMatrix4(worldMatrix);
        facePositions.push(v.x, v.y, v.z);

        if (this.selectedFaces.has(f)) {
          faceColors.push(1, 0.5, 0); // Orange
        } else {
          faceColors.push(0.27, 0.53, 1); // Blue
        }
      }
    }

    const faceGeo = new THREE.BufferGeometry();
    faceGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(facePositions), 3));
    faceGeo.setAttribute("color", new THREE.BufferAttribute(new Float32Array(faceColors), 3));

    const material = new THREE.MeshBasicMaterial({
      vertexColors: true,
      opacity: 0.25,
      transparent: true,
      side: THREE.DoubleSide,
      depthTest: false,
    });

    this.faceHighlights = new THREE.Mesh(faceGeo, material);
    this.faceHighlights.name = "__faceHelper";
    this.faceHighlights.renderOrder = 998;
    this.scene.add(this.faceHighlights);
  }

  clearHelpers() {
    if (this.vertexPoints) {
      this.scene.remove(this.vertexPoints);
      this.vertexPoints.geometry.dispose();
      (this.vertexPoints.material as THREE.Material).dispose();
      this.vertexPoints = null;
    }
    if (this.edgeLines) {
      this.scene.remove(this.edgeLines);
      this.edgeLines.geometry.dispose();
      (this.edgeLines.material as THREE.Material).dispose();
      this.edgeLines = null;
    }
    if (this.faceHighlights) {
      this.scene.remove(this.faceHighlights);
      this.faceHighlights.geometry.dispose();
      (this.faceHighlights.material as THREE.Material).dispose();
      this.faceHighlights = null;
    }
  }

  toggleVertexSelection(index: number) {
    if (this.selectedVertices.has(index)) {
      this.selectedVertices.delete(index);
    } else {
      this.selectedVertices.add(index);
    }
  }

  clearSelection() {
    this.selectedVertices.clear();
    this.selectedFaces.clear();
    this.selectedEdges.clear();
  }

  dispose() {
    this.clearHelpers();
    this.clearSelection();
  }
}
