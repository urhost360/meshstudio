import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Keyboard } from "lucide-react";

interface KeyboardHelpDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function KeyboardHelpDialog({ open, onOpenChange }: KeyboardHelpDialogProps) {
  const shortcuts = [
    { category: "File Operations", items: [
      { key: "I", description: "Import file" },
      { key: "Ctrl+S", description: "Save project" },
      { key: "E", description: "Export model" },
    ]},
    { category: "Transform Tools", items: [
      { key: "G", description: "Move (translate)" },
      { key: "R", description: "Rotate" },
      { key: "S", description: "Scale" },
      { key: "F", description: "Focus selected object" },
    ]},
    { category: "Edit Modes", items: [
      { key: "V", description: "Vertex edit mode" },
      { key: "F", description: "Face edit mode" },
      { key: "E", description: "Edge edit mode" },
      { key: "O", description: "Object mode" },
    ]},
    { category: "Selection Tools", items: [
      { key: "L", description: "Toggle lasso selection" },
      { key: "B", description: "Toggle box selection" },
      { key: "Double-click", description: "Select object" },
      { key: "Single-click", description: "Show properties" },
    ]},
    { category: "Mesh Operations", items: [
      { key: "Delete/Backspace", description: "Delete selected elements" },
      { key: "D", description: "Duplicate object" },
      { key: "M", description: "Merge selected objects" },
    ]},
    { category: "History", items: [
      { key: "Ctrl+Z", description: "Undo" },
      { key: "Ctrl+Y", description: "Redo" },
      { key: "Ctrl+Shift+Z", description: "Redo (alternative)" },
    ]},
    { category: "Viewport", items: [
      { key: "Middle-click + Drag", description: "Pan camera" },
      { key: "Right-click + Drag", description: "Orbit camera" },
      { key: "Scroll", description: "Zoom in/out" },
      { key: "Home", description: "Reset camera" },
    ]},
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Keyboard className="h-5 w-5" />
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
          </div>
          <DialogDescription>
            All available keyboard shortcuts and controls in MeshStudio
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[60vh] pr-4">
          <div className="space-y-6">
            {shortcuts.map((group) => (
              <div key={group.category}>
                <h3 className="font-semibold text-sm text-foreground mb-3">{group.category}</h3>
                <div className="space-y-2">
                  {group.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between gap-4 text-sm">
                      <span className="text-muted-foreground">{item.description}</span>
                      <kbd className="px-2 py-1 bg-muted border border-border rounded text-xs font-mono font-semibold text-foreground whitespace-nowrap">
                        {item.key}
                      </kbd>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
