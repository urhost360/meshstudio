import { useRef, useState, useCallback, useEffect } from "react";
import * as THREE from "three";
import type { ViewportRef, EditMode } from "./ThreeViewport";

export type SelectionTool = "click" | "lasso" | "box";

interface LassoSelectorProps {
  viewportRef: ViewportRef | null;
  editMode: EditMode;
  tool: SelectionTool;
  onSelectionComplete?: (selectedIndices: Set<number>, mode: EditMode) => void;
  enabled: boolean;
}

interface Point {
  x: number;
  y: number;
}

/**
 * LassoSelector renders an SVG overlay on top of the 3D viewport.
 * In "lasso" mode the user draws a freeform shape; in "box" mode they drag a rectangle.
 * Once the shape is closed, all vertices/faces/edges whose screen-space projections
 * fall inside the shape are reported via onSelectionComplete.
 */
export default function LassoSelector({
  viewportRef,
  editMode,
  tool,
  onSelectionComplete,
  enabled,
}: LassoSelectorProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [lassoPoints, setLassoPoints] = useState<Point[]>([]);
  const [boxStart, setBoxStart] = useState<Point | null>(null);
  const [boxEnd, setBoxEnd] = useState<Point | null>(null);

  const isActive = enabled && editMode !== "object" && (tool === "lasso" || tool === "box");

  // Project a 3D world position to 2D screen coordinates
  const projectToScreen = useCallback(
    (worldPos: THREE.Vector3): Point | null => {
      if (!viewportRef) return null;
      const { camera, renderer } = viewportRef;
      const vec = worldPos.clone().project(camera);
      const rect = renderer.domElement.getBoundingClientRect();
      return {
        x: ((vec.x + 1) / 2) * rect.width,
        y: ((-vec.y + 1) / 2) * rect.height,
      };
    },
    [viewportRef]
  );

  // Check if a 2D point is inside a polygon (lasso path)
  const pointInPolygon = useCallback((point: Point, polygon: Point[]): boolean => {
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].x, yi = polygon[i].y;
      const xj = polygon[j].x, yj = polygon[j].y;
      const intersect =
        yi > point.y !== yj > point.y &&
        point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi;
      if (intersect) inside = !inside;
    }
    return inside;
  }, []);

  // Check if a 2D point is inside a rectangle
  const pointInBox = useCallback((point: Point, start: Point, end: Point): boolean => {
    const minX = Math.min(start.x, end.x);
    const maxX = Math.max(start.x, end.x);
    const minY = Math.min(start.y, end.y);
    const maxY = Math.max(start.y, end.y);
    return point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY;
  }, []);

  // Find the selected mesh from the scene
  const getTargetMesh = useCallback((): THREE.Mesh | null => {
    if (!viewportRef) return null;
    let target: THREE.Mesh | null = null;
    viewportRef.scene.traverse((child) => {
      if (!target && (child as any).isMesh && child.name && !child.name.startsWith("__")) {
        target = child as THREE.Mesh;
      }
    });
    // If there's a selected object, prefer meshes within it
    const selected = viewportRef.getSelectedObject();
    if (selected) {
      target = null;
      if ((selected as any).isMesh) {
        target = selected as THREE.Mesh;
      } else {
        selected.traverse((child) => {
          if (!target && (child as any).isMesh) target = child as THREE.Mesh;
        });
      }
    }
    return target;
  }, [viewportRef]);

  // Perform the selection test
  const performSelection = useCallback(
    (shape: "lasso" | "box") => {
      if (!viewportRef) return;
      const mesh = getTargetMesh();
      if (!mesh) return;

      const geometry = mesh.geometry;
      if (!geometry || !geometry.attributes.position) return;

      const positions = geometry.attributes.position;
      const worldMatrix = mesh.matrixWorld;
      const selectedIndices = new Set<number>();

      if (editMode === "vertex") {
        for (let i = 0; i < positions.count; i++) {
          const worldPos = new THREE.Vector3(
            positions.getX(i),
            positions.getY(i),
            positions.getZ(i)
          ).applyMatrix4(worldMatrix);

          const screenPos = projectToScreen(worldPos);
          if (!screenPos) continue;

          let isInside = false;
          if (shape === "lasso" && lassoPoints.length >= 3) {
            isInside = pointInPolygon(screenPos, lassoPoints);
          } else if (shape === "box" && boxStart && boxEnd) {
            isInside = pointInBox(screenPos, boxStart, boxEnd);
          }

          if (isInside) selectedIndices.add(i);
        }
      } else if (editMode === "face") {
        // Select faces whose centroid falls inside the selection shape
        const indexAttr = geometry.index;
        const faceCount = indexAttr
          ? indexAttr.count / 3
          : positions.count / 3;

        for (let f = 0; f < faceCount; f++) {
          const i0 = indexAttr ? indexAttr.getX(f * 3) : f * 3;
          const i1 = indexAttr ? indexAttr.getX(f * 3 + 1) : f * 3 + 1;
          const i2 = indexAttr ? indexAttr.getX(f * 3 + 2) : f * 3 + 2;

          const centroid = new THREE.Vector3(
            (positions.getX(i0) + positions.getX(i1) + positions.getX(i2)) / 3,
            (positions.getY(i0) + positions.getY(i1) + positions.getY(i2)) / 3,
            (positions.getZ(i0) + positions.getZ(i1) + positions.getZ(i2)) / 3
          ).applyMatrix4(worldMatrix);

          const screenPos = projectToScreen(centroid);
          if (!screenPos) continue;

          let isInside = false;
          if (shape === "lasso" && lassoPoints.length >= 3) {
            isInside = pointInPolygon(screenPos, lassoPoints);
          } else if (shape === "box" && boxStart && boxEnd) {
            isInside = pointInBox(screenPos, boxStart, boxEnd);
          }

          if (isInside) selectedIndices.add(f);
        }
      } else if (editMode === "edge") {
        // Select edges whose midpoint falls inside
        const indexAttr = geometry.index;
        const edgeSet = new Set<string>();
        const faceCount = indexAttr
          ? indexAttr.count / 3
          : positions.count / 3;

        let edgeIdx = 0;
        for (let f = 0; f < faceCount; f++) {
          const i0 = indexAttr ? indexAttr.getX(f * 3) : f * 3;
          const i1 = indexAttr ? indexAttr.getX(f * 3 + 1) : f * 3 + 1;
          const i2 = indexAttr ? indexAttr.getX(f * 3 + 2) : f * 3 + 2;

          const edges = [
            [Math.min(i0, i1), Math.max(i0, i1)],
            [Math.min(i1, i2), Math.max(i1, i2)],
            [Math.min(i0, i2), Math.max(i0, i2)],
          ];

          for (const [a, b] of edges) {
            const key = `${a}-${b}`;
            if (edgeSet.has(key)) continue;
            edgeSet.add(key);

            const midpoint = new THREE.Vector3(
              (positions.getX(a) + positions.getX(b)) / 2,
              (positions.getY(a) + positions.getY(b)) / 2,
              (positions.getZ(a) + positions.getZ(b)) / 2
            ).applyMatrix4(worldMatrix);

            const screenPos = projectToScreen(midpoint);
            if (!screenPos) continue;

            let isInside = false;
            if (shape === "lasso" && lassoPoints.length >= 3) {
              isInside = pointInPolygon(screenPos, lassoPoints);
            } else if (shape === "box" && boxStart && boxEnd) {
              isInside = pointInBox(screenPos, boxStart, boxEnd);
            }

            if (isInside) selectedIndices.add(edgeIdx);
            edgeIdx++;
          }
        }
      }

      onSelectionComplete?.(selectedIndices, editMode);
    },
    [
      viewportRef,
      editMode,
      lassoPoints,
      boxStart,
      boxEnd,
      getTargetMesh,
      projectToScreen,
      pointInPolygon,
      pointInBox,
      onSelectionComplete,
    ]
  );

  // Mouse handlers
  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      // Allow right-click for orbit controls, only use left-click for selection
      if (e.button !== 0) return; // 0 = left click, 1 = middle, 2 = right
      if (!isActive) return;
      e.preventDefault();
      e.stopPropagation();

      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const point = { x: e.clientX - rect.left, y: e.clientY - rect.top };

      if (tool === "lasso") {
        setIsDrawing(true);
        setLassoPoints([point]);
      } else if (tool === "box") {
        setIsDrawing(true);
        setBoxStart(point);
        setBoxEnd(point);
      }

      // Disable orbit controls while drawing
      if (viewportRef) {
        viewportRef.orbitControls.enabled = false;
      }
    },
    [isActive, tool, viewportRef]
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isDrawing || !isActive) return;
      e.preventDefault();

      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const point = { x: e.clientX - rect.left, y: e.clientY - rect.top };

      if (tool === "lasso") {
        setLassoPoints((prev) => [...prev, point]);
      } else if (tool === "box") {
        setBoxEnd(point);
      }
    },
    [isDrawing, isActive, tool]
  );

  const handleMouseUp = useCallback(
    (e: React.MouseEvent) => {
      if (!isDrawing || !isActive) return;
      e.preventDefault();

      setIsDrawing(false);

      // Re-enable orbit controls
      if (viewportRef) {
        viewportRef.orbitControls.enabled = true;
      }

      // Perform selection
      if (tool === "lasso" && lassoPoints.length >= 3) {
        performSelection("lasso");
      } else if (tool === "box" && boxStart && boxEnd) {
        performSelection("box");
      }

      // Clear drawing
      setTimeout(() => {
        setLassoPoints([]);
        setBoxStart(null);
        setBoxEnd(null);
      }, 150);
    },
    [isDrawing, isActive, tool, lassoPoints, boxStart, boxEnd, performSelection, viewportRef]
  );

  // Ensure orbit controls are re-enabled when lasso mode is deactivated
  useEffect(() => {
    if (!isActive && viewportRef) {
      viewportRef.orbitControls.enabled = true;
    }
  }, [isActive, viewportRef]);

  // Build SVG path for lasso
  const lassoPath =
    lassoPoints.length > 1
      ? `M ${lassoPoints.map((p) => `${p.x},${p.y}`).join(" L ")}${isDrawing ? "" : " Z"}`
      : "";

  // Build box rect
  const boxRect =
    boxStart && boxEnd
      ? {
          x: Math.min(boxStart.x, boxEnd.x),
          y: Math.min(boxStart.y, boxEnd.y),
          width: Math.abs(boxEnd.x - boxStart.x),
          height: Math.abs(boxEnd.y - boxStart.y),
        }
      : null;

  if (!isActive) return null;

  return (
    <svg
      ref={svgRef}
      className="absolute inset-0 w-full h-full z-10"
      style={{ cursor: tool === "lasso" ? "crosshair" : "crosshair" }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Lasso path */}
      {tool === "lasso" && lassoPath && (
        <path
          d={lassoPath}
          fill="rgba(59, 130, 246, 0.12)"
          stroke="rgba(59, 130, 246, 0.8)"
          strokeWidth="1.5"
          strokeDasharray="6 3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}

      {/* Box rectangle */}
      {tool === "box" && boxRect && (
        <rect
          x={boxRect.x}
          y={boxRect.y}
          width={boxRect.width}
          height={boxRect.height}
          fill="rgba(59, 130, 246, 0.12)"
          stroke="rgba(59, 130, 246, 0.8)"
          strokeWidth="1.5"
          strokeDasharray="6 3"
        />
      )}
    </svg>
  );
}
