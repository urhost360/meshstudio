import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Download, FileBox, Image, AlertTriangle, CheckCircle2, Smartphone, Monitor, Info } from "lucide-react";
import { useState, useMemo } from "react";
import type { ExportFormat, SceneStats } from "@/lib/exporters";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onExport: (format: ExportFormat) => void;
  loading?: boolean;
  hasObjects: boolean;
  sceneStats?: SceneStats | null;
}

const formats: { value: ExportFormat; label: string; description: string; icon: any; arReady?: boolean; platform?: string }[] = [
  { value: "glb", label: "GLB", description: "Binary glTF — primary format for Web AR", icon: FileBox, arReady: true, platform: "Web / Android" },
  { value: "gltf", label: "GLTF", description: "JSON-based glTF — editable, AR-compatible", icon: FileBox, arReady: true, platform: "Web / Android" },
  { value: "usdz", label: "USDZ", description: "Apple AR Quick Look — iOS/iPadOS/visionOS", icon: Smartphone, arReady: true, platform: "iOS / macOS" },
  { value: "obj", label: "OBJ", description: "Wavefront OBJ — widely supported legacy format", icon: FileBox },
  { value: "stl", label: "STL (Binary)", description: "Stereolithography — for 3D printing", icon: FileBox },
  { value: "png", label: "Screenshot (PNG)", description: "Current viewport as image", icon: Image },
];

export default function ExportDialog({ open, onOpenChange, onExport, loading, hasObjects, sceneStats }: ExportDialogProps) {
  const [format, setFormat] = useState<ExportFormat>("glb");

  const isArFormat = format === "glb" || format === "gltf" || format === "usdz";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg bg-card border-border max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-foreground flex items-center gap-2">
            <Download className="h-5 w-5 text-primary" />
            Export Model
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Choose a format to export. AR-compatible formats are marked with a badge.
          </DialogDescription>
        </DialogHeader>

        {/* Scene Stats Summary */}
        {sceneStats && sceneStats.meshCount > 0 && (
          <div className="bg-secondary/50 rounded-lg border border-border p-3 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
              <Info className="h-3.5 w-3.5 text-primary" />
              Scene Analysis
            </div>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div>
                <div className="text-lg font-bold text-foreground">{Math.round(sceneStats.totalPolygons).toLocaleString()}</div>
                <div className="text-[10px] text-muted-foreground">Polygons</div>
              </div>
              <div>
                <div className="text-lg font-bold text-foreground">{sceneStats.totalVertices.toLocaleString()}</div>
                <div className="text-[10px] text-muted-foreground">Vertices</div>
              </div>
              <div>
                <div className="text-lg font-bold text-foreground">{sceneStats.meshCount}</div>
                <div className="text-[10px] text-muted-foreground">Meshes</div>
              </div>
              <div>
                <div className="text-lg font-bold text-foreground">{sceneStats.textureCount}</div>
                <div className="text-[10px] text-muted-foreground">Textures</div>
              </div>
            </div>

            {/* Warnings */}
            {sceneStats.warnings.length > 0 && (
              <div className="space-y-1 mt-1">
                {sceneStats.warnings.map((w, i) => (
                  <div key={i} className="flex items-start gap-1.5 text-[11px] text-yellow-400 bg-yellow-500/10 rounded px-2 py-1.5">
                    <AlertTriangle className="h-3 w-3 shrink-0 mt-0.5" />
                    <span>{w}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Texture details */}
            {sceneStats.textureSizes.length > 0 && (
              <div className="space-y-1">
                <div className="text-[10px] text-muted-foreground font-medium">Texture Sizes:</div>
                {sceneStats.textureSizes.map((t, i) => {
                  const maxDim = Math.max(t.width, t.height);
                  const isOversized = maxDim > 2048;
                  return (
                    <div key={i} className={`flex items-center justify-between text-[10px] px-2 py-0.5 rounded ${isOversized ? "text-yellow-400 bg-yellow-500/5" : "text-muted-foreground"}`}>
                      <span>{t.name}</span>
                      <span className="font-mono">{t.width}x{t.height}{isOversized ? " ⚠ >2K" : " ✓"}</span>
                    </div>
                  );
                })}
              </div>
            )}

            {/* AR readiness indicator */}
            {sceneStats.warnings.length === 0 && (
              <div className="flex items-center gap-1.5 text-[11px] text-green-400 bg-green-500/10 rounded px-2 py-1.5">
                <CheckCircle2 className="h-3 w-3" />
                Scene is optimized for AR viewing
              </div>
            )}
          </div>
        )}

        {/* Format Selection */}
        <RadioGroup value={format} onValueChange={(v) => setFormat(v as ExportFormat)} className="space-y-1.5">
          {formats.map((f) => (
            <label
              key={f.value}
              className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                format === f.value
                  ? "border-primary bg-primary/10"
                  : "border-border hover:bg-accent"
              }`}
            >
              <RadioGroupItem value={f.value} />
              <f.icon className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-foreground">{f.label}</span>
                  {f.arReady && (
                    <span className="text-[9px] font-medium bg-primary/20 text-primary px-1.5 py-0.5 rounded-full">
                      AR Ready
                    </span>
                  )}
                  {f.platform && (
                    <span className="text-[9px] text-muted-foreground/60">{f.platform}</span>
                  )}
                </div>
                <span className="block text-xs text-muted-foreground">{f.description}</span>
              </div>
            </label>
          ))}
        </RadioGroup>

        {/* AR tip */}
        {isArFormat && (
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-2.5 text-[11px] text-muted-foreground">
            <span className="font-medium text-primary">AR Tip:</span>{" "}
            {format === "usdz"
              ? "USDZ files can be opened directly on iPhone/iPad for AR Quick Look. Share the link and tap on iOS to view in AR."
              : "GLB/GLTF files work with Google's model-viewer, AR.js, and most WebXR frameworks. Ideal for embedding 3D on the web."}
          </div>
        )}

        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="text-muted-foreground">
            Cancel
          </Button>
          <Button
            onClick={() => onExport(format)}
            disabled={loading || (!hasObjects && format !== "png")}
          >
            <Download className="h-4 w-4 mr-1.5" />
            {loading ? "Exporting..." : "Export"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
