import { ScrollArea } from "@/components/ui/scroll-area";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Sun, Lightbulb, Sparkles, RotateCw } from "lucide-react";
import * as THREE from "three";
import { useState, useEffect, useCallback } from "react";
import type { ViewportRef } from "./ThreeViewport";

interface LightConfig {
  name: string;
  icon: typeof Sun;
  description: string;
  color: string;
  intensity: number;
  position: [number, number, number];
  castShadow: boolean;
  enabled: boolean;
}

interface LightingPanelProps {
  viewportRef: ViewportRef | null;
}

// Preset configurations
const PRESETS: Record<string, { name: string; ambient: number; lights: Omit<LightConfig, "icon" | "description">[] }> = {
  studio: {
    name: "Studio",
    ambient: 0.4,
    lights: [
      { name: "Key Light", color: "#fff5e6", intensity: 1.4, position: [6, 10, 6], castShadow: true, enabled: true },
      { name: "Fill Light", color: "#e6f0ff", intensity: 0.5, position: [-6, 4, -2], castShadow: false, enabled: true },
      { name: "Back Light", color: "#ffe6f0", intensity: 0.7, position: [-2, 8, -8], castShadow: false, enabled: true },
    ],
  },
  outdoor: {
    name: "Outdoor Daylight",
    ambient: 0.6,
    lights: [
      { name: "Key Light", color: "#fffbe6", intensity: 1.8, position: [10, 15, 5], castShadow: true, enabled: true },
      { name: "Fill Light", color: "#cce5ff", intensity: 0.3, position: [-8, 3, 4], castShadow: false, enabled: true },
      { name: "Back Light", color: "#fff0cc", intensity: 0.4, position: [0, 6, -10], castShadow: false, enabled: true },
    ],
  },
  dramatic: {
    name: "Dramatic",
    ambient: 0.15,
    lights: [
      { name: "Key Light", color: "#ffcc88", intensity: 2.0, position: [4, 8, 3], castShadow: true, enabled: true },
      { name: "Fill Light", color: "#4466aa", intensity: 0.2, position: [-6, 2, -4], castShadow: false, enabled: true },
      { name: "Back Light", color: "#ff8844", intensity: 1.0, position: [-3, 10, -6], castShadow: true, enabled: true },
    ],
  },
  soft: {
    name: "Soft Ambient",
    ambient: 0.8,
    lights: [
      { name: "Key Light", color: "#ffffff", intensity: 0.8, position: [5, 8, 5], castShadow: true, enabled: true },
      { name: "Fill Light", color: "#eeeeff", intensity: 0.6, position: [-5, 6, 3], castShadow: false, enabled: true },
      { name: "Back Light", color: "#ffeeff", intensity: 0.5, position: [0, 5, -7], castShadow: false, enabled: true },
    ],
  },
};

const LIGHT_META: { icon: typeof Sun; description: string }[] = [
  { icon: Sun, description: "Primary light source — strongest, defines main shadows" },
  { icon: Lightbulb, description: "Softens shadows from key light — lower intensity" },
  { icon: Sparkles, description: "Rim/separation light — creates depth behind subject" },
];

export default function LightingPanel({ viewportRef }: LightingPanelProps) {
  const [ambientIntensity, setAmbientIntensity] = useState(0.4);
  const [lights, setLights] = useState<LightConfig[]>([
    { name: "Key Light", icon: Sun, description: LIGHT_META[0].description, color: "#fff5e6", intensity: 1.4, position: [6, 10, 6], castShadow: true, enabled: true },
    { name: "Fill Light", icon: Lightbulb, description: LIGHT_META[1].description, color: "#e6f0ff", intensity: 0.5, position: [-6, 4, -2], castShadow: false, enabled: true },
    { name: "Back Light", icon: Sparkles, description: LIGHT_META[2].description, color: "#ffe6f0", intensity: 0.7, position: [-2, 8, -8], castShadow: false, enabled: true },
  ]);

  // Apply lighting to the Three.js scene
  const applyLighting = useCallback(() => {
    if (!viewportRef) return;
    const scene = viewportRef.scene;

    // Update ambient light
    const ambient = scene.getObjectByName("__ambientLight") as THREE.AmbientLight | undefined;
    if (ambient) {
      ambient.intensity = ambientIntensity;
    }

    // Light name mapping to scene names
    const sceneNames = ["__dirLight", "__fillLight", "__backLight"];

    lights.forEach((config, idx) => {
      const sceneName = sceneNames[idx];
      let light = scene.getObjectByName(sceneName) as THREE.DirectionalLight | undefined;

      if (!light && idx === 2) {
        // Create back light if it doesn't exist
        light = new THREE.DirectionalLight(0xffffff, config.intensity);
        light.name = "__backLight";
        scene.add(light);
      }

      if (light) {
        light.visible = config.enabled;
        light.color.set(config.color);
        light.intensity = config.intensity;
        light.position.set(...config.position);
        light.castShadow = config.castShadow;

        if (config.castShadow) {
          light.shadow.mapSize.width = 2048;
          light.shadow.mapSize.height = 2048;
          light.shadow.camera.near = 0.5;
          light.shadow.camera.far = 50;
          light.shadow.camera.left = -15;
          light.shadow.camera.right = 15;
          light.shadow.camera.top = 15;
          light.shadow.camera.bottom = -15;
        }
      }
    });
  }, [viewportRef, ambientIntensity, lights]);

  // Apply whenever config changes
  useEffect(() => {
    applyLighting();
  }, [applyLighting]);

  // Initialize back light on mount
  useEffect(() => {
    if (!viewportRef) return;
    const scene = viewportRef.scene;
    if (!scene.getObjectByName("__backLight")) {
      const backLight = new THREE.DirectionalLight(0xffe6f0, 0.7);
      backLight.name = "__backLight";
      backLight.position.set(-2, 8, -8);
      scene.add(backLight);
    }
  }, [viewportRef]);

  const updateLight = (index: number, updates: Partial<LightConfig>) => {
    setLights((prev) =>
      prev.map((l, i) => (i === index ? { ...l, ...updates } : l))
    );
  };

  const applyPreset = (presetKey: string) => {
    const preset = PRESETS[presetKey];
    if (!preset) return;
    setAmbientIntensity(preset.ambient);
    setLights((prev) =>
      prev.map((l, i) => ({
        ...l,
        ...preset.lights[i],
      }))
    );
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b border-border">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Lighting
        </h3>
      </div>
      <ScrollArea className="flex-1 editor-panel">
        <div className="p-3 space-y-4">
          {/* Presets */}
          <div>
            <Label className="text-[10px] text-muted-foreground mb-2 block">Presets</Label>
            <div className="grid grid-cols-2 gap-1.5">
              {Object.entries(PRESETS).map(([key, preset]) => (
                <Button
                  key={key}
                  variant="outline"
                  size="sm"
                  className="h-7 text-[10px] border-border hover:bg-accent"
                  onClick={() => applyPreset(key)}
                >
                  {preset.name}
                </Button>
              ))}
            </div>
          </div>

          <Separator />

          {/* Ambient */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium">Ambient Light</span>
              <span className="text-[10px] font-mono text-muted-foreground">
                {ambientIntensity.toFixed(2)}
              </span>
            </div>
            <Slider
              min={0}
              max={2}
              step={0.05}
              value={[ambientIntensity]}
              onValueChange={([v]) => setAmbientIntensity(v)}
            />
            <p className="text-[9px] text-muted-foreground mt-1">
              Base illumination — fills shadows uniformly
            </p>
          </div>

          <Separator />

          {/* 3-Point Lights */}
          {lights.map((light, idx) => {
            const Icon = light.icon;
            return (
              <div key={idx}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="text-xs font-medium">{light.name}</span>
                  </div>
                  <Switch
                    checked={light.enabled}
                    onCheckedChange={(checked) => updateLight(idx, { enabled: checked })}
                  />
                </div>
                <p className="text-[9px] text-muted-foreground mb-2">{light.description}</p>

                {light.enabled && (
                  <div className="space-y-2.5 pl-1">
                    {/* Color */}
                    <div className="flex items-center gap-2">
                      <Label className="text-[10px] text-muted-foreground w-14">Color</Label>
                      <input
                        type="color"
                        className="h-6 w-8 rounded border border-border bg-secondary cursor-pointer"
                        value={light.color}
                        onChange={(e) => updateLight(idx, { color: e.target.value })}
                      />
                      <span className="text-[10px] font-mono text-muted-foreground">{light.color}</span>
                    </div>

                    {/* Intensity */}
                    <div>
                      <div className="flex items-center justify-between">
                        <Label className="text-[10px] text-muted-foreground">Intensity</Label>
                        <span className="text-[10px] font-mono text-muted-foreground">
                          {light.intensity.toFixed(2)}
                        </span>
                      </div>
                      <Slider
                        min={0}
                        max={3}
                        step={0.05}
                        value={[light.intensity]}
                        onValueChange={([v]) => updateLight(idx, { intensity: v })}
                      />
                    </div>

                    {/* Position */}
                    <div>
                      <Label className="text-[10px] text-muted-foreground mb-1 block">Position</Label>
                      <div className="grid grid-cols-3 gap-1">
                        {(["X", "Y", "Z"] as const).map((axis, ai) => (
                          <div key={axis}>
                            <Label className="text-[9px] text-muted-foreground">{axis}</Label>
                            <Input
                              type="number"
                              step="0.5"
                              className="h-6 text-[10px] bg-secondary border-border"
                              value={light.position[ai]}
                              onChange={(e) => {
                                const newPos = [...light.position] as [number, number, number];
                                newPos[ai] = parseFloat(e.target.value) || 0;
                                updateLight(idx, { position: newPos });
                              }}
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Cast Shadow */}
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] text-muted-foreground">Cast Shadow</Label>
                      <Switch
                        checked={light.castShadow}
                        onCheckedChange={(checked) => updateLight(idx, { castShadow: checked })}
                      />
                    </div>
                  </div>
                )}

                {idx < lights.length - 1 && <Separator className="mt-3" />}
              </div>
            );
          })}

          <Separator />

          {/* Reset */}
          <Button
            variant="outline"
            size="sm"
            className="w-full h-7 text-xs border-border"
            onClick={() => applyPreset("studio")}
          >
            <RotateCw className="h-3 w-3 mr-1.5" />
            Reset to Studio Default
          </Button>
        </div>
      </ScrollArea>
    </div>
  );
}
