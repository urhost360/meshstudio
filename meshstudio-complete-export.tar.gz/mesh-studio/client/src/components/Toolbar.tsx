import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Separator } from "@/components/ui/separator";
import {
  Move, RotateCcw, Maximize, MousePointer, Focus, RotateCw,
  Upload, Download, Save, Share2, Box, Combine, Trash2, Copy, Grid3x3,
  Lasso, Square, Crosshair, Undo2, Redo2
} from "lucide-react";
import type { TransformMode, EditMode } from "./ThreeViewport";
import type { SelectionTool } from "./LassoSelector";

interface ToolbarProps {
  transformMode: TransformMode;
  editMode: EditMode;
  selectionTool: SelectionTool;
  onTransformModeChange: (mode: TransformMode) => void;
  onEditModeChange: (mode: EditMode) => void;
  onSelectionToolChange: (tool: SelectionTool) => void;
  onFocusSelected: () => void;
  onResetCamera: () => void;
  onUpload: () => void;
  onSave: () => void;
  onExport: () => void;
  onShare: () => void;
  hasSelection: boolean;
  onDelete: () => void;
  onDuplicate: () => void;
  onMerge: () => void;
  projectName?: string;
  selectionCount: number;
  onUndo?: () => void;
  onRedo?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
}

function ToolBtn({ icon: Icon, label, shortcut, active, onClick, disabled, highlight }: {
  icon: any; label: string; shortcut?: string; active?: boolean; onClick: () => void; disabled?: boolean; highlight?: boolean;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant={active ? "default" : "ghost"}
          size="sm"
          className={`h-8 px-2 gap-1 text-xs ${
            active
              ? "bg-primary text-primary-foreground shadow-sm"
              : highlight
              ? "bg-orange-500/20 text-orange-400 hover:bg-orange-500/30"
              : "text-muted-foreground hover:text-foreground hover:bg-accent"
          } ${disabled ? "opacity-40" : ""}`}
          onClick={onClick}
          disabled={disabled}
        >
          <Icon className="h-4 w-4" />
        </Button>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="text-xs">
        <span>{label}</span>
        {shortcut && <span className="ml-1.5 text-muted-foreground font-mono">({shortcut})</span>}
      </TooltipContent>
    </Tooltip>
  );
}

function ToolGroup({ children, label }: { children: React.ReactNode; label?: string }) {
  return (
    <div className="flex items-center gap-0.5">
      {label && <span className="text-[9px] text-muted-foreground/60 uppercase tracking-wider mr-1 hidden xl:inline">{label}</span>}
      {children}
    </div>
  );
}

export default function Toolbar({
  transformMode, editMode, selectionTool, onTransformModeChange, onEditModeChange,
  onSelectionToolChange, onFocusSelected, onResetCamera, onUpload, onSave, onExport, onShare,
  hasSelection, onDelete, onDuplicate, onMerge, projectName, selectionCount, onUndo, onRedo, canUndo, canRedo
}: ToolbarProps) {
  const inEditMode = editMode !== "object";

  return (
    <div className="flex items-center h-11 px-3 bg-card border-b border-border gap-2 shrink-0">
      {/* Project name */}
      <div className="flex items-center gap-2 mr-1">
        <div className="h-6 w-6 rounded bg-primary/15 flex items-center justify-center">
          <Box className="h-3.5 w-3.5 text-primary" />
        </div>
        <span className="text-sm font-medium text-foreground truncate max-w-[140px]">
          {projectName || "Untitled"}
        </span>
      </div>

      <Separator orientation="vertical" className="h-6" />

      {/* File operations */}
      <ToolGroup label="File">
        <ToolBtn icon={Upload} label="Import File" shortcut="I" onClick={onUpload} />
        <ToolBtn icon={Save} label="Save Project" shortcut="Ctrl+S" onClick={onSave} />
        <ToolBtn icon={Download} label="Export" onClick={onExport} />
        <ToolBtn icon={Share2} label="Share" onClick={onShare} />
      </ToolGroup>

      <Separator orientation="vertical" className="h-6" />

      {/* Undo/Redo */}
      <ToolGroup label="Edit">
        <ToolBtn icon={Undo2} label="Undo" shortcut="Ctrl+Z" onClick={onUndo || (() => {})} disabled={!canUndo} />
        <ToolBtn icon={Redo2} label="Redo" shortcut="Ctrl+Y" onClick={onRedo || (() => {})} disabled={!canRedo} />
      </ToolGroup>

      <Separator orientation="vertical" className="h-6" />

      {/* Edit modes */}
      <ToolGroup label="Mode">
        <ToolBtn icon={MousePointer} label="Object Mode" active={editMode === "object"} onClick={() => onEditModeChange("object")} />
        <ToolBtn icon={Grid3x3} label="Vertex Mode" active={editMode === "vertex"} onClick={() => onEditModeChange("vertex")} />
        <ToolBtn icon={Box} label="Face Mode" active={editMode === "face"} onClick={() => onEditModeChange("face")} />
      </ToolGroup>

      <Separator orientation="vertical" className="h-6" />

      {/* Transform tools */}
      <ToolGroup label="Transform">
        <ToolBtn icon={Move} label="Move" shortcut="G" active={transformMode === "translate"} onClick={() => onTransformModeChange("translate")} />
        <ToolBtn icon={RotateCcw} label="Rotate" shortcut="R" active={transformMode === "rotate"} onClick={() => onTransformModeChange("rotate")} />
        <ToolBtn icon={Maximize} label="Scale" shortcut="S" active={transformMode === "scale"} onClick={() => onTransformModeChange("scale")} />
      </ToolGroup>

      {/* Selection tools (only visible in edit modes) */}
      {inEditMode && (
        <>
          <Separator orientation="vertical" className="h-6" />
          <ToolGroup label="Select">
            <ToolBtn
              icon={Crosshair}
              label="Click Select"
              active={selectionTool === "click"}
              onClick={() => onSelectionToolChange("click")}
            />
            <ToolBtn
              icon={Lasso}
              label="Lasso Select"
              shortcut="L"
              active={selectionTool === "lasso"}
              highlight={selectionTool === "lasso"}
              onClick={() => onSelectionToolChange(selectionTool === "lasso" ? "click" : "lasso")}
            />
            <ToolBtn
              icon={Square}
              label="Box Select"
              shortcut="B"
              active={selectionTool === "box"}
              highlight={selectionTool === "box"}
              onClick={() => onSelectionToolChange(selectionTool === "box" ? "click" : "box")}
            />
          </ToolGroup>
        </>
      )}

      <Separator orientation="vertical" className="h-6" />

      {/* Object operations */}
      <ToolGroup label="Edit">
        <ToolBtn icon={Copy} label="Duplicate" onClick={onDuplicate} disabled={!hasSelection} />
        <ToolBtn icon={Combine} label="Merge All" onClick={onMerge} disabled={!hasSelection} />
        <ToolBtn
          icon={Trash2}
          label={selectionCount > 0 ? `Delete ${selectionCount} selected` : "Delete"}
          shortcut="Del"
          onClick={onDelete}
          disabled={!hasSelection && selectionCount === 0}
          highlight={selectionCount > 0}
        />
      </ToolGroup>

      <div className="flex-1" />

      {/* Selection count badge */}
      {selectionCount > 0 && (
        <div className="px-2 py-0.5 bg-orange-500/20 text-orange-400 rounded text-[10px] font-medium">
          {selectionCount} selected
        </div>
      )}

      {/* View */}
      <ToolGroup label="View">
        <ToolBtn icon={Focus} label="Focus Selected" shortcut="F" onClick={onFocusSelected} disabled={!hasSelection} />
        <ToolBtn icon={RotateCw} label="Reset Camera" onClick={onResetCamera} />
      </ToolGroup>
    </div>
  );
}
