import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Box, Eye, EyeOff, Trash2, ChevronRight, ChevronDown } from "lucide-react";
import * as THREE from "three";
import { useState } from "react";

interface SceneHierarchyProps {
  objects: THREE.Object3D[];
  selectedObject: THREE.Object3D | null;
  onSelect: (obj: THREE.Object3D) => void;
  onDelete: (obj: THREE.Object3D) => void;
  onToggleVisibility: (obj: THREE.Object3D) => void;
}

export default function SceneHierarchy({
  objects, selectedObject, onSelect, onDelete, onToggleVisibility
}: SceneHierarchyProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b border-border">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Scene Hierarchy</h3>
      </div>
      <ScrollArea className="flex-1 editor-panel">
        <div className="p-1">
          {objects.length === 0 ? (
            <div className="px-3 py-8 text-center">
              <Box className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
              <p className="text-xs text-muted-foreground">No objects in scene</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Import a 3D file to get started</p>
            </div>
          ) : (
            objects.map((obj, i) => {
              const isSelected = selectedObject === obj;
              const meshCount = countMeshes(obj);
              const vertexCount = countVertices(obj);
              return (
                <button
                  key={obj.uuid}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-left text-sm transition-colors ${
                    isSelected
                      ? "bg-primary/20 text-primary-foreground"
                      : "text-foreground hover:bg-accent"
                  }`}
                  onClick={() => onSelect(obj)}
                >
                  <Box className={`h-3.5 w-3.5 shrink-0 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                  <div className="flex-1 min-w-0">
                    <span className="block truncate text-xs font-medium">
                      {obj.userData.displayName || obj.name || `Object ${i + 1}`}
                    </span>
                    <span className="block text-[10px] text-muted-foreground">
                      {meshCount} mesh{meshCount !== 1 ? "es" : ""} · {formatNumber(vertexCount)} verts
                    </span>
                  </div>
                  <div className="flex items-center gap-0.5 shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-muted-foreground hover:text-foreground"
                      onClick={(e) => { e.stopPropagation(); onToggleVisibility(obj); }}
                    >
                      {obj.visible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-muted-foreground hover:text-destructive"
                      onClick={(e) => { e.stopPropagation(); onDelete(obj); }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

function countMeshes(obj: THREE.Object3D): number {
  let count = 0;
  obj.traverse((child) => { if ((child as any).isMesh) count++; });
  return count;
}

function countVertices(obj: THREE.Object3D): number {
  let count = 0;
  obj.traverse((child) => {
    if ((child as any).isMesh) {
      const mesh = child as THREE.Mesh;
      const geo = mesh.geometry;
      if (geo && geo.attributes.position) {
        count += geo.attributes.position.count;
      }
    }
  });
  return count;
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return n.toString();
}
