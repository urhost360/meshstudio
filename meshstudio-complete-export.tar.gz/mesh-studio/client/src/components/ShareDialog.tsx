import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Copy, Check, Link2, Trash2, ExternalLink, QrCode, Code2, Share2,
  Lock, Globe, KeyRound, MessageSquare, Eye, Plus, Image
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { QRCodeSVG } from "qrcode.react";

interface ShareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  projectId: number | null;
  thumbnailUrl?: string | null;
}

export default function ShareDialog({ open, onOpenChange, projectId, thumbnailUrl }: ShareDialogProps) {
  const [copied, setCopied] = useState<string | null>(null);
  const [newLinkPrivacy, setNewLinkPrivacy] = useState<"public" | "private" | "password">("public");
  const [newLinkPassword, setNewLinkPassword] = useState("");
  const [newLinkComments, setNewLinkComments] = useState(true);
  const [showQR, setShowQR] = useState<string | null>(null);
  const [editingPassword, setEditingPassword] = useState<number | null>(null);
  const [editPasswordValue, setEditPasswordValue] = useState("");

  const { data: links, refetch } = trpc.share.listByProject.useQuery(
    { projectId: projectId! },
    { enabled: !!projectId && open }
  );

  const createLink = trpc.share.create.useMutation({
    onSuccess: () => {
      refetch();
      toast.success("Share link created");
      setNewLinkPassword("");
    },
    onError: (e) => toast.error(e.message),
  });

  const updateLink = trpc.share.update.useMutation({
    onSuccess: () => { refetch(); toast.success("Link updated"); },
    onError: (e) => toast.error(e.message),
  });

  const deleteLink = trpc.share.delete.useMutation({
    onSuccess: () => { refetch(); toast.success("Link deleted"); },
    onError: (e) => toast.error(e.message),
  });

  const getShareUrl = (token: string) => `${window.location.origin}/view/${token}`;

  const copyToClipboard = async (text: string, label: string = "Link") => {
    await navigator.clipboard.writeText(text);
    setCopied(text);
    toast.success(`${label} copied to clipboard`);
    setTimeout(() => setCopied(null), 2000);
  };

  const getEmbedCode = (token: string) => {
    const url = getShareUrl(token);
    return `<iframe src="${url}" width="800" height="600" frameborder="0" allowfullscreen style="border-radius:8px;"></iframe>`;
  };

  const shareToSocial = (platform: string, token: string) => {
    const url = encodeURIComponent(getShareUrl(token));
    const text = encodeURIComponent("Check out this 3D model on MeshStudio!");
    const urls: Record<string, string> = {
      twitter: `https://twitter.com/intent/tweet?url=${url}&text=${text}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`,
      reddit: `https://www.reddit.com/submit?url=${url}&title=${text}`,
    };
    if (urls[platform]) window.open(urls[platform], "_blank", "width=600,height=400");
  };

  const privacyIcon = (privacy: string) => {
    switch (privacy) {
      case "public": return <Globe className="h-3.5 w-3.5 text-green-400" />;
      case "private": return <Lock className="h-3.5 w-3.5 text-yellow-400" />;
      case "password": return <KeyRound className="h-3.5 w-3.5 text-orange-400" />;
      default: return <Globe className="h-3.5 w-3.5" />;
    }
  };

  const handleCreateLink = () => {
    if (!projectId) return;
    createLink.mutate({
      projectId,
      privacy: newLinkPrivacy,
      password: newLinkPrivacy === "password" ? newLinkPassword : undefined,
      commentsEnabled: newLinkComments,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-card border-border max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-foreground flex items-center gap-2">
            <Share2 className="h-5 w-5 text-primary" />
            Share Project
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Create AR-ready shareable links with QR codes, embed options, and privacy controls
          </DialogDescription>
        </DialogHeader>

        {/* AR Preview Thumbnail */}
        {thumbnailUrl && (
          <div className="relative rounded-lg overflow-hidden border border-border bg-secondary h-32 flex items-center justify-center">
            <img src={thumbnailUrl} alt="Project preview" className="h-full w-auto object-contain" />
            <div className="absolute top-2 left-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
              <Image className="h-3 w-3" />
              AR Preview
            </div>
          </div>
        )}
        {!thumbnailUrl && (
          <div className="rounded-lg border border-dashed border-border bg-secondary/50 h-24 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <Image className="h-6 w-6 mx-auto mb-1 opacity-40" />
              <p className="text-xs">Save project to generate AR preview thumbnail</p>
            </div>
          </div>
        )}

        {/* Create New Link Section */}
        <div className="space-y-3 p-3 bg-secondary/50 rounded-lg border border-border">
          <h3 className="text-sm font-medium text-foreground flex items-center gap-1.5">
            <Plus className="h-4 w-4" />
            Create New Share Link
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Privacy</Label>
              <Select value={newLinkPrivacy} onValueChange={(v: any) => setNewLinkPrivacy(v)}>
                <SelectTrigger className="h-8 text-xs bg-background border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">
                    <span className="flex items-center gap-1.5"><Globe className="h-3 w-3 text-green-400" /> Public</span>
                  </SelectItem>
                  <SelectItem value="private">
                    <span className="flex items-center gap-1.5"><Lock className="h-3 w-3 text-yellow-400" /> Private (link only)</span>
                  </SelectItem>
                  <SelectItem value="password">
                    <span className="flex items-center gap-1.5"><KeyRound className="h-3 w-3 text-orange-400" /> Password Protected</span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <MessageSquare className="h-3 w-3" /> Comments
              </Label>
              <div className="flex items-center gap-2 h-8">
                <Switch checked={newLinkComments} onCheckedChange={setNewLinkComments} />
                <span className="text-xs text-muted-foreground">{newLinkComments ? "Enabled" : "Disabled"}</span>
              </div>
            </div>
          </div>
          {newLinkPrivacy === "password" && (
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Password</Label>
              <Input
                type="password"
                value={newLinkPassword}
                onChange={(e) => setNewLinkPassword(e.target.value)}
                placeholder="Enter password for this link"
                className="h-8 text-xs bg-background border-border"
              />
            </div>
          )}
          <Button
            onClick={handleCreateLink}
            disabled={!projectId || createLink.isPending || (newLinkPrivacy === "password" && !newLinkPassword)}
            className="w-full h-8 text-xs"
          >
            <Link2 className="h-3.5 w-3.5 mr-1.5" />
            {createLink.isPending ? "Creating..." : "Generate Share Link"}
          </Button>
        </div>

        <Separator />

        {/* Existing Links */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-foreground">Active Links ({links?.length ?? 0})</h3>

          {links && links.length > 0 ? (
            links.map((link) => {
              const shareUrl = getShareUrl(link.shareToken);
              return (
                <div key={link.id} className="border border-border rounded-lg bg-secondary/30 overflow-hidden">
                  {/* Link header */}
                  <div className="flex items-center gap-2 p-3">
                    {privacyIcon(link.privacy)}
                    <div className="flex-1 min-w-0">
                      <Input
                        readOnly
                        value={shareUrl}
                        className="h-7 text-xs bg-background border-border font-mono"
                      />
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Switch
                        checked={link.isActive}
                        onCheckedChange={(checked) => updateLink.mutate({ id: link.id, isActive: checked })}
                      />
                    </div>
                  </div>

                  {/* Action tabs */}
                  <Tabs defaultValue="actions" className="px-3 pb-3">
                    <TabsList className="h-7 bg-secondary">
                      <TabsTrigger value="actions" className="text-[10px] h-5 px-2">Actions</TabsTrigger>
                      <TabsTrigger value="qr" className="text-[10px] h-5 px-2">QR Code</TabsTrigger>
                      <TabsTrigger value="embed" className="text-[10px] h-5 px-2">Embed</TabsTrigger>
                      <TabsTrigger value="social" className="text-[10px] h-5 px-2">Social</TabsTrigger>
                      <TabsTrigger value="settings" className="text-[10px] h-5 px-2">Settings</TabsTrigger>
                    </TabsList>

                    {/* Actions tab */}
                    <TabsContent value="actions" className="mt-2">
                      <div className="flex flex-wrap gap-1.5">
                        <Button variant="outline" size="sm" className="h-7 text-[11px] border-border"
                          onClick={() => copyToClipboard(shareUrl)}>
                          {copied === shareUrl ? <Check className="h-3 w-3 mr-1 text-green-500" /> : <Copy className="h-3 w-3 mr-1" />}
                          Copy Link
                        </Button>
                        <Button variant="outline" size="sm" className="h-7 text-[11px] border-border"
                          onClick={() => window.open(shareUrl, "_blank")}>
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Open
                        </Button>
                        <Button variant="outline" size="sm" className="h-7 text-[11px] border-border"
                          onClick={() => setShowQR(showQR === link.shareToken ? null : link.shareToken)}>
                          <QrCode className="h-3 w-3 mr-1" />
                          QR Code
                        </Button>
                        <Button variant="outline" size="sm" className="h-7 text-[11px] border-border text-destructive hover:text-destructive"
                          onClick={() => deleteLink.mutate({ id: link.id })}>
                          <Trash2 className="h-3 w-3 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TabsContent>

                    {/* QR Code tab */}
                    <TabsContent value="qr" className="mt-2">
                      <div className="flex flex-col items-center gap-3 py-2">
                        <div className="bg-white p-3 rounded-lg">
                          <QRCodeSVG
                            value={shareUrl}
                            size={160}
                            level="H"
                            includeMargin={false}
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground">Scan with mobile device to view in AR</p>
                        <Button variant="outline" size="sm" className="h-7 text-[11px] border-border"
                          onClick={() => {
                            const svg = document.querySelector(`[data-qr="${link.shareToken}"]`)?.parentElement?.querySelector("svg");
                            if (!svg) {
                              // Fallback: copy link
                              copyToClipboard(shareUrl, "Link");
                              return;
                            }
                          }}>
                          <Copy className="h-3 w-3 mr-1" />
                          Copy QR as Image
                        </Button>
                      </div>
                    </TabsContent>

                    {/* Embed tab */}
                    <TabsContent value="embed" className="mt-2">
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground">Embed Code</Label>
                        <div className="relative">
                          <pre className="bg-background border border-border rounded p-2 text-[10px] text-muted-foreground font-mono overflow-x-auto whitespace-pre-wrap break-all">
                            {getEmbedCode(link.shareToken)}
                          </pre>
                          <Button variant="ghost" size="sm" className="absolute top-1 right-1 h-6 w-6 p-0"
                            onClick={() => copyToClipboard(getEmbedCode(link.shareToken), "Embed code")}>
                            {copied === getEmbedCode(link.shareToken) ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
                          </Button>
                        </div>
                        <p className="text-[10px] text-muted-foreground">Paste this code into any website to embed the 3D viewer</p>
                      </div>
                    </TabsContent>

                    {/* Social sharing tab */}
                    <TabsContent value="social" className="mt-2">
                      <div className="flex flex-wrap gap-2">
                        <Button variant="outline" size="sm" className="h-8 text-[11px] border-border"
                          onClick={() => shareToSocial("twitter", link.shareToken)}>
                          <svg className="h-3.5 w-3.5 mr-1.5" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                          Twitter / X
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 text-[11px] border-border"
                          onClick={() => shareToSocial("facebook", link.shareToken)}>
                          <svg className="h-3.5 w-3.5 mr-1.5" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                          Facebook
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 text-[11px] border-border"
                          onClick={() => shareToSocial("linkedin", link.shareToken)}>
                          <svg className="h-3.5 w-3.5 mr-1.5" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                          LinkedIn
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 text-[11px] border-border"
                          onClick={() => shareToSocial("reddit", link.shareToken)}>
                          <svg className="h-3.5 w-3.5 mr-1.5" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/></svg>
                          Reddit
                        </Button>
                      </div>
                    </TabsContent>

                    {/* Settings tab */}
                    <TabsContent value="settings" className="mt-2 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground">Privacy</Label>
                          <Select
                            value={link.privacy}
                            onValueChange={(v: any) => {
                              if (v === "password") {
                                setEditingPassword(link.id);
                              } else {
                                updateLink.mutate({ id: link.id, privacy: v });
                              }
                            }}
                          >
                            <SelectTrigger className="h-7 text-[11px] bg-background border-border">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="public">Public</SelectItem>
                              <SelectItem value="private">Private</SelectItem>
                              <SelectItem value="password">Password</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs text-muted-foreground">Comments</Label>
                          <div className="flex items-center gap-2 h-7">
                            <Switch
                              checked={link.commentsEnabled}
                              onCheckedChange={(checked) => updateLink.mutate({ id: link.id, commentsEnabled: checked })}
                            />
                            <span className="text-[11px] text-muted-foreground">{link.commentsEnabled ? "On" : "Off"}</span>
                          </div>
                        </div>
                      </div>
                      {editingPassword === link.id && (
                        <div className="flex gap-2">
                          <Input
                            type="password"
                            value={editPasswordValue}
                            onChange={(e) => setEditPasswordValue(e.target.value)}
                            placeholder="Set password"
                            className="h-7 text-xs bg-background border-border flex-1"
                          />
                          <Button size="sm" className="h-7 text-[11px]"
                            onClick={() => {
                              updateLink.mutate({ id: link.id, privacy: "password", password: editPasswordValue });
                              setEditingPassword(null);
                              setEditPasswordValue("");
                            }}
                            disabled={!editPasswordValue}
                          >
                            Set
                          </Button>
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8">
              <Link2 className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
              <p className="text-sm text-muted-foreground">No share links yet</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Create a link above to share your 3D project</p>
            </div>
          )}
        </div>

        <div className="flex justify-end">
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="text-muted-foreground">
            Done
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
