import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import * as THREE from "three";
import { batchTransform, getBatchCenter } from "@/lib/meshOps";
import { Copy, Trash2, AlignCenter } from "lucide-react";

interface BatchTransformPanelProps {
  selectedObjects: Set<THREE.Object3D>;
  scene: THREE.Scene;
  onTransform?: () => void;
}

export default function BatchTransformPanel({ selectedObjects, scene, onTransform }: BatchTransformPanelProps) {
  const [posX, setPosX] = useState(0);
  const [posY, setPosY] = useState(0);
  const [posZ, setPosZ] = useState(0);
  const [rotX, setRotX] = useState(0);
  const [rotY, setRotY] = useState(0);
  const [rotZ, setRotZ] = useState(0);
  const [scaleX, setScaleX] = useState(1);
  const [scaleY, setScaleY] = useState(1);
  const [scaleZ, setScaleZ] = useState(1);

  if (selectedObjects.size === 0) {
    return null;
  }

  const objects = Array.from(selectedObjects);
  const center = getBatchCenter(objects);

  const handleApplyTransform = () => {
    batchTransform(objects, [posX, posY, posZ], [rotX, rotY, rotZ], [scaleX, scaleY, scaleZ]);
    onTransform?.();
    // Reset values
    setPosX(0);
    setPosY(0);
    setPosZ(0);
    setRotX(0);
    setRotY(0);
    setRotZ(0);
    setScaleX(1);
    setScaleY(1);
    setScaleZ(1);
  };

  const handleAlignCenter = () => {
    // Align all objects to the center of the group
    objects.forEach((obj) => {
      const offset = new THREE.Vector3().subVectors(center, obj.position);
      obj.position.copy(center);
    });
    onTransform?.();
  };

  const handleDistribute = (axis: "x" | "y" | "z") => {
    if (objects.length < 2) return;

    const sorted = [...objects].sort((a, b) => {
      const aPos = a.position[axis];
      const bPos = b.position[axis];
      return aPos - bPos;
    });

    const min = sorted[0].position[axis];
    const max = sorted[sorted.length - 1].position[axis];
    const spacing = (max - min) / (sorted.length - 1);

    sorted.forEach((obj, idx) => {
      obj.position[axis] = min + spacing * idx;
    });

    onTransform?.();
  };

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-sm">Batch Transform</CardTitle>
        <CardDescription>{selectedObjects.size} objects selected</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Position */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold">Position Offset</Label>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-[10px] text-muted-foreground">X</Label>
              <Input
                type="number"
                value={posX}
                onChange={(e) => setPosX(parseFloat(e.target.value) || 0)}
                className="h-8 text-xs"
                step="0.1"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Y</Label>
              <Input
                type="number"
                value={posY}
                onChange={(e) => setPosY(parseFloat(e.target.value) || 0)}
                className="h-8 text-xs"
                step="0.1"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Z</Label>
              <Input
                type="number"
                value={posZ}
                onChange={(e) => setPosZ(parseFloat(e.target.value) || 0)}
                className="h-8 text-xs"
                step="0.1"
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Rotation */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold">Rotation (radians)</Label>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-[10px] text-muted-foreground">X</Label>
              <Input
                type="number"
                value={rotX}
                onChange={(e) => setRotX(parseFloat(e.target.value) || 0)}
                className="h-8 text-xs"
                step="0.1"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Y</Label>
              <Input
                type="number"
                value={rotY}
                onChange={(e) => setRotY(parseFloat(e.target.value) || 0)}
                className="h-8 text-xs"
                step="0.1"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Z</Label>
              <Input
                type="number"
                value={rotZ}
                onChange={(e) => setRotZ(parseFloat(e.target.value) || 0)}
                className="h-8 text-xs"
                step="0.1"
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Scale */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold">Scale Multiplier</Label>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-[10px] text-muted-foreground">X</Label>
              <Input
                type="number"
                value={scaleX}
                onChange={(e) => setScaleX(parseFloat(e.target.value) || 1)}
                className="h-8 text-xs"
                step="0.1"
                min="0.1"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Y</Label>
              <Input
                type="number"
                value={scaleY}
                onChange={(e) => setScaleY(parseFloat(e.target.value) || 1)}
                className="h-8 text-xs"
                step="0.1"
                min="0.1"
              />
            </div>
            <div>
              <Label className="text-[10px] text-muted-foreground">Z</Label>
              <Input
                type="number"
                value={scaleZ}
                onChange={(e) => setScaleZ(parseFloat(e.target.value) || 1)}
                className="h-8 text-xs"
                step="0.1"
                min="0.1"
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Alignment Options */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold">Alignment</Label>
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleAlignCenter}
              className="h-8 text-xs"
            >
              <AlignCenter className="h-3 w-3 mr-1" />
              Align Center
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleDistribute("x")}
              className="h-8 text-xs"
            >
              Distribute X
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleDistribute("y")}
              className="h-8 text-xs"
            >
              Distribute Y
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleDistribute("z")}
              className="h-8 text-xs"
            >
              Distribute Z
            </Button>
          </div>
        </div>

        {/* Apply Button */}
        <Button
          onClick={handleApplyTransform}
          className="w-full h-8 text-xs"
          disabled={posX === 0 && posY === 0 && posZ === 0 && rotX === 0 && rotY === 0 && rotZ === 0 && scaleX === 1 && scaleY === 1 && scaleZ === 1}
        >
          <Copy className="h-3 w-3 mr-1" />
          Apply Transform
        </Button>
      </CardContent>
    </Card>
  );
}
