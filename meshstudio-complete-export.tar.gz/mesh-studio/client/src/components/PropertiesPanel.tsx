import { ScrollArea } from "@/components/ui/scroll-area";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Settings2, Palette, Move, RotateCcw, Maximize } from "lucide-react";
import * as THREE from "three";
import { useState, useEffect, useCallback } from "react";

interface PropertiesPanelProps {
  selectedObject: THREE.Object3D | null;
  onPropertyChange: () => void;
}

export default function PropertiesPanel({ selectedObject, onPropertyChange }: PropertiesPanelProps) {
  const [, forceUpdate] = useState(0);
  const refresh = useCallback(() => { forceUpdate(v => v + 1); onPropertyChange(); }, [onPropertyChange]);

  // Force re-render when selection changes
  useEffect(() => { forceUpdate(v => v + 1); }, [selectedObject]);

  if (!selectedObject) {
    return (
      <div className="flex flex-col h-full">
        <div className="px-3 py-2 border-b border-border">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Properties</h3>
        </div>
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <Settings2 className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
            <p className="text-xs text-muted-foreground">Select an object to view properties</p>
          </div>
        </div>
      </div>
    );
  }

  const pos = selectedObject.position;
  const rot = selectedObject.rotation;
  const scl = selectedObject.scale;

  // Find the first mesh for material editing
  let targetMesh: THREE.Mesh | null = null;
  if ((selectedObject as any).isMesh) {
    targetMesh = selectedObject as THREE.Mesh;
  } else {
    selectedObject.traverse((child) => {
      if (!targetMesh && (child as any).isMesh) targetMesh = child as THREE.Mesh;
    });
  }

  const mat = targetMesh?.material as THREE.MeshStandardMaterial | undefined;

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b border-border">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Properties</h3>
      </div>
      <ScrollArea className="flex-1 editor-panel">
        <div className="p-3 space-y-4">
          {/* Name */}
          <div>
            <Label className="text-xs text-muted-foreground">Name</Label>
            <Input
              className="h-7 text-xs mt-1 bg-secondary border-border"
              value={selectedObject.userData.displayName || selectedObject.name || ""}
              onChange={(e) => {
                selectedObject.userData.displayName = e.target.value;
                refresh();
              }}
            />
          </div>

          <Separator />

          {/* Transform */}
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Move className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs font-medium">Position</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(["x", "y", "z"] as const).map((axis) => (
                <div key={axis}>
                  <Label className="text-[10px] text-muted-foreground uppercase">{axis}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    className="h-7 text-xs bg-secondary border-border"
                    value={Number(pos[axis].toFixed(3))}
                    onChange={(e) => { pos[axis] = parseFloat(e.target.value) || 0; refresh(); }}
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <RotateCcw className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs font-medium">Rotation</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(["x", "y", "z"] as const).map((axis) => (
                <div key={axis}>
                  <Label className="text-[10px] text-muted-foreground uppercase">{axis}</Label>
                  <Input
                    type="number"
                    step="1"
                    className="h-7 text-xs bg-secondary border-border"
                    value={Number(THREE.MathUtils.radToDeg(rot[axis]).toFixed(1))}
                    onChange={(e) => { rot[axis] = THREE.MathUtils.degToRad(parseFloat(e.target.value) || 0); refresh(); }}
                  />
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Maximize className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs font-medium">Scale</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(["x", "y", "z"] as const).map((axis) => (
                <div key={axis}>
                  <Label className="text-[10px] text-muted-foreground uppercase">{axis}</Label>
                  <Input
                    type="number"
                    step="0.1"
                    className="h-7 text-xs bg-secondary border-border"
                    value={Number(scl[axis].toFixed(3))}
                    onChange={(e) => { scl[axis] = parseFloat(e.target.value) || 1; refresh(); }}
                  />
                </div>
              ))}
            </div>
          </div>

          {mat && (
            <>
              <Separator />

              {/* Material */}
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Palette className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium">Material</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <Label className="text-[10px] text-muted-foreground">Color</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="color"
                        className="h-7 w-10 rounded border border-border bg-secondary cursor-pointer"
                        value={`#${mat.color.getHexString()}`}
                        onChange={(e) => { mat.color.set(e.target.value); refresh(); }}
                      />
                      <Input
                        className="h-7 text-xs flex-1 bg-secondary border-border font-mono"
                        value={`#${mat.color.getHexString()}`}
                        onChange={(e) => { try { mat.color.set(e.target.value); refresh(); } catch {} }}
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-[10px] text-muted-foreground">Metalness</Label>
                    <Slider
                      className="mt-1"
                      min={0} max={1} step={0.01}
                      value={[mat.metalness]}
                      onValueChange={([v]) => { mat.metalness = v; refresh(); }}
                    />
                  </div>

                  <div>
                    <Label className="text-[10px] text-muted-foreground">Roughness</Label>
                    <Slider
                      className="mt-1"
                      min={0} max={1} step={0.01}
                      value={[mat.roughness]}
                      onValueChange={([v]) => { mat.roughness = v; refresh(); }}
                    />
                  </div>

                  <div>
                    <Label className="text-[10px] text-muted-foreground">Opacity</Label>
                    <Slider
                      className="mt-1"
                      min={0} max={1} step={0.01}
                      value={[mat.opacity]}
                      onValueChange={([v]) => {
                        mat.opacity = v;
                        mat.transparent = v < 1;
                        refresh();
                      }}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-[10px] text-muted-foreground">Wireframe</Label>
                    <Switch
                      checked={mat.wireframe}
                      onCheckedChange={(checked) => { mat.wireframe = checked; refresh(); }}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-[10px] text-muted-foreground">Flat Shading</Label>
                    <Switch
                      checked={mat.flatShading}
                      onCheckedChange={(checked) => {
                        mat.flatShading = checked;
                        mat.needsUpdate = true;
                        refresh();
                      }}
                    />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
