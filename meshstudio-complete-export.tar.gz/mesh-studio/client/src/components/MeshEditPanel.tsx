import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Layers, Minimize2, Maximize2, Grid3x3, Box, Scissors } from "lucide-react";
import * as THREE from "three";
import { subdivideMesh, decimateMesh } from "@/lib/meshOps";
import { useState } from "react";
import { toast } from "sonner";

interface MeshEditPanelProps {
  selectedObject: THREE.Object3D | null;
  onMeshModified: () => void;
}

export default function MeshEditPanel({ selectedObject, onMeshModified }: MeshEditPanelProps) {
  const [decimateRatio, setDecimateRatio] = useState(0.5);

  const getMeshInfo = () => {
    if (!selectedObject) return null;
    let vertices = 0, faces = 0, meshes = 0;
    selectedObject.traverse((child) => {
      if ((child as any).isMesh) {
        meshes++;
        const mesh = child as THREE.Mesh;
        const geo = mesh.geometry;
        if (geo.attributes.position) vertices += geo.attributes.position.count;
        if (geo.index) faces += geo.index.count / 3;
        else if (geo.attributes.position) faces += geo.attributes.position.count / 3;
      }
    });
    return { vertices, faces, meshes };
  };

  const info = getMeshInfo();

  const handleSubdivide = () => {
    if (!selectedObject) return;
    try {
      subdivideMesh(selectedObject);
      onMeshModified();
      toast.success("Mesh subdivided");
    } catch (e: any) {
      toast.error(e.message || "Subdivision failed");
    }
  };

  const handleDecimate = () => {
    if (!selectedObject) return;
    try {
      decimateMesh(selectedObject, decimateRatio);
      onMeshModified();
      toast.success(`Mesh decimated to ${Math.round(decimateRatio * 100)}%`);
    } catch (e: any) {
      toast.error(e.message || "Decimation failed");
    }
  };

  if (!selectedObject) {
    return (
      <div className="flex flex-col h-full">
        <div className="px-3 py-2 border-b border-border">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Mesh Tools</h3>
        </div>
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <Grid3x3 className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
            <p className="text-xs text-muted-foreground">Select a mesh to edit</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-3 py-2 border-b border-border">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Mesh Tools</h3>
      </div>
      <ScrollArea className="flex-1 editor-panel">
        <div className="p-3 space-y-4">
          {/* Mesh info */}
          {info && (
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-secondary rounded-md p-2 text-center">
                <p className="text-lg font-semibold text-foreground">{formatNumber(info.vertices)}</p>
                <p className="text-[10px] text-muted-foreground">Vertices</p>
              </div>
              <div className="bg-secondary rounded-md p-2 text-center">
                <p className="text-lg font-semibold text-foreground">{formatNumber(info.faces)}</p>
                <p className="text-[10px] text-muted-foreground">Faces</p>
              </div>
              <div className="bg-secondary rounded-md p-2 text-center">
                <p className="text-lg font-semibold text-foreground">{info.meshes}</p>
                <p className="text-[10px] text-muted-foreground">Meshes</p>
              </div>
            </div>
          )}

          <Separator />

          {/* Subdivision */}
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Maximize2 className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs font-medium">Subdivide</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-2">
              Split each triangle into 4 for smoother geometry
            </p>
            <Button size="sm" className="w-full h-7 text-xs" onClick={handleSubdivide}>
              Subdivide Mesh
            </Button>
          </div>

          <Separator />

          {/* Decimation */}
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Minimize2 className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs font-medium">Decimate</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-2">
              Reduce polygon count while preserving shape
            </p>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-[10px] text-muted-foreground">Ratio</Label>
                <span className="text-xs font-mono text-foreground">{Math.round(decimateRatio * 100)}%</span>
              </div>
              <Slider
                min={0.1} max={0.9} step={0.05}
                value={[decimateRatio]}
                onValueChange={([v]) => setDecimateRatio(v)}
              />
              <Button size="sm" variant="outline" className="w-full h-7 text-xs border-border" onClick={handleDecimate}>
                Decimate Mesh
              </Button>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}

function formatNumber(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return n.toString();
}
