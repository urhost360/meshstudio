import { useEffect, useRef, useCallback, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";

export type TransformMode = "translate" | "rotate" | "scale";
export type EditMode = "object" | "vertex" | "face" | "edge";

export interface ViewportRef {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  orbitControls: OrbitControls;
  transformControls: TransformControls;
  addObject: (obj: THREE.Object3D) => void;
  removeObject: (obj: THREE.Object3D) => void;
  selectObject: (obj: THREE.Object3D | null) => void;
  getSelectedObject: () => THREE.Object3D | null;
  setTransformMode: (mode: TransformMode) => void;
  focusSelected: () => void;
  resetCamera: () => void;
  captureScreenshot: () => string;
}

interface ThreeViewportProps {
  onReady?: (ref: ViewportRef) => void;
  onObjectSelected?: (obj: THREE.Object3D | null) => void;
  editMode?: EditMode;
}

export default function ThreeViewport({ onReady, onObjectSelected, editMode = "object" }: ThreeViewportProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<ViewportRef | null>(null);
  const selectedRef = useRef<THREE.Object3D | null>(null);
  const animFrameRef = useRef<number>(0);
  const editModeRef = useRef<EditMode>(editMode);

  // Keep editMode ref in sync
  useEffect(() => {
    editModeRef.current = editMode;
  }, [editMode]);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);

    // Camera
    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 10000);
    camera.position.set(5, 4, 5);
    camera.lookAt(0, 0, 0);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Grid
    const gridHelper = new THREE.GridHelper(20, 20, 0x444466, 0x2a2a3e);
    gridHelper.name = "__grid";
    scene.add(gridHelper);

    // Axes
    const axesHelper = new THREE.AxesHelper(3);
    axesHelper.name = "__axes";
    scene.add(axesHelper);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    ambientLight.name = "__ambientLight";
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(8, 12, 8);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.name = "__dirLight";
    scene.add(dirLight);

    const fillLight = new THREE.DirectionalLight(0x8888ff, 0.3);
    fillLight.position.set(-5, 3, -5);
    fillLight.name = "__fillLight";
    scene.add(fillLight);

    // Orbit Controls
    const orbitControls = new OrbitControls(camera, renderer.domElement);
    orbitControls.enableDamping = true;
    orbitControls.dampingFactor = 0.08;
    orbitControls.minDistance = 0.5;
    orbitControls.maxDistance = 500;

    // Transform Controls
    const transformControls = new TransformControls(camera, renderer.domElement);
    const tcHelper = transformControls.getHelper();
    tcHelper.name = "__transformControls";
    scene.add(tcHelper);

    transformControls.addEventListener("dragging-changed", (event: any) => {
      // In edit modes, always keep orbit controls enabled for camera movement
      if (editModeRef.current !== "object") {
        orbitControls.enabled = true;
      } else {
        orbitControls.enabled = !event.value;
      }
    });

    // Raycaster for selection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const getUserObjects = (): THREE.Object3D[] => {
      const objs: THREE.Object3D[] = [];
      scene.traverse((child) => {
        if (child.name && !child.name.startsWith("__") && child !== scene && (child as any).isMesh) {
          objs.push(child);
        }
      });
      return objs;
    };

    const getObjectAtMouse = (event: MouseEvent): THREE.Object3D | null => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(getUserObjects(), true);
      if (intersects.length > 0) {
        let target = intersects[0].object;
        // Walk up to find the user-level parent
        while (target.parent && target.parent !== scene && target.parent.name && !target.parent.name.startsWith("__")) {
          target = target.parent;
        }
        return target;
      }
      return null;
    };

    const selectObject = (obj: THREE.Object3D | null) => {
      selectedRef.current = obj;
      if (obj) {
        transformControls.attach(obj);
      } else {
        transformControls.detach();
      }
      onObjectSelected?.(obj);
    };

    const handleClick = (event: MouseEvent) => {
      if (editModeRef.current !== "object") return;
      const target = getObjectAtMouse(event);
      // Single click: show properties only (don't select for transform)
      onObjectSelected?.(target);
    };

    const handleDoubleClick = (event: MouseEvent) => {
      if (editModeRef.current !== "object") return;
      const target = getObjectAtMouse(event);
      // Double click: select for transform
      selectObject(target);
    };

    renderer.domElement.addEventListener("click", handleClick);
    renderer.domElement.addEventListener("dblclick", handleDoubleClick);

    // Prevent context menu in vertex and face modes to allow right-click panning
    const handleContextMenu = (event: MouseEvent) => {
      if (editModeRef.current === "vertex" || editModeRef.current === "face" || editModeRef.current === "edge") {
        event.preventDefault();
      }
    };
    renderer.domElement.addEventListener("contextmenu", handleContextMenu);

    // Animation loop
    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      orbitControls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // Build ref
    const vRef: ViewportRef = {
      scene,
      camera,
      renderer,
      orbitControls,
      transformControls,
      addObject: (obj) => { scene.add(obj); },
      removeObject: (obj) => {
        if (selectedRef.current === obj) selectObject(null);
        scene.remove(obj);
      },
      selectObject,
      getSelectedObject: () => selectedRef.current,
      setTransformMode: (mode) => { transformControls.setMode(mode); },
      focusSelected: () => {
        const obj = selectedRef.current;
        if (!obj) return;
        const box = new THREE.Box3().setFromObject(obj);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3()).length();
        orbitControls.target.copy(center);
        camera.position.copy(center).add(new THREE.Vector3(size, size * 0.7, size));
        orbitControls.update();
      },
      resetCamera: () => {
        camera.position.set(5, 4, 5);
        orbitControls.target.set(0, 0, 0);
        orbitControls.update();
      },
      captureScreenshot: () => {
        renderer.render(scene, camera);
        return renderer.domElement.toDataURL("image/png");
      },
    };
    viewportRef.current = vRef;
    onReady?.(vRef);

    return () => {
      cancelAnimationFrame(animFrameRef.current);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener("click", handleClick);
      renderer.domElement.removeEventListener("dblclick", handleDoubleClick);
      renderer.domElement.removeEventListener("contextmenu", handleContextMenu);
      transformControls.dispose();
      orbitControls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full h-full viewport-canvas" style={{ minHeight: 200 }} />
  );
}
