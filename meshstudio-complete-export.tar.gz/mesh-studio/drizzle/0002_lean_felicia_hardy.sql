CREATE TABLE `comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sharedLinkId` int NOT NULL,
	`userId` int,
	`authorName` varchar(128) NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `comments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `shared_links` ADD `privacy` enum('public','private','password') DEFAULT 'public' NOT NULL;--> statement-breakpoint
ALTER TABLE `shared_links` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `shared_links` ADD `commentsEnabled` boolean DEFAULT true NOT NULL;