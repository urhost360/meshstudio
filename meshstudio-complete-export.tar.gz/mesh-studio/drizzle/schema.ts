import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Projects table - stores scene metadata */
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  /** JSON blob storing Three.js scene graph (camera, lights, object transforms, materials) */
  sceneData: json("sceneData"),
  /** S3 URL for project thumbnail */
  thumbnailUrl: text("thumbnailUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

/** Assets table - individual 3D files uploaded by users */
export const assets = mysqlTable("assets", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  originalName: varchar("originalName", { length: 255 }).notNull(),
  format: varchar("format", { length: 32 }).notNull(),
  fileKey: text("fileKey").notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileSize: int("fileSize"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Asset = typeof assets.$inferSelect;
export type InsertAsset = typeof assets.$inferInsert;

/** Shared links table - public URLs for viewing projects */
export const sharedLinks = mysqlTable("shared_links", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  /** Unique share token used in URL */
  shareToken: varchar("shareToken", { length: 64 }).notNull().unique(),
  /** Whether the link is currently active */
  isActive: boolean("isActive").default(true).notNull(),
  /** Privacy: public (anyone), private (only with link), password (requires password) */
  privacy: mysqlEnum("privacy", ["public", "private", "password"]).default("public").notNull(),
  /** Hashed password for password-protected links */
  passwordHash: varchar("passwordHash", { length: 255 }),
  /** Whether comments are enabled on this shared view */
  commentsEnabled: boolean("commentsEnabled").default(true).notNull(),
  /** Optional expiration */
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SharedLink = typeof sharedLinks.$inferSelect;
export type InsertSharedLink = typeof sharedLinks.$inferInsert;

/** Comments table - viewer comments on shared projects */
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  sharedLinkId: int("sharedLinkId").notNull(),
  /** If the commenter is logged in, store their userId */
  userId: int("userId"),
  /** Display name for anonymous commenters */
  authorName: varchar("authorName", { length: 128 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;
